import { redirect } from "next/navigation"

import { createClient } from "@/lib/supabase/server"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { isAdvisor } from "@/lib/auth/roles"
import { Toaster } from "@/components/ui/sonner"
import { SidebarNav, SidebarNavProvider, SidebarNavTrigger } from "./sidebar-nav"
import { SignOutButton } from "./sign-out-button"

function getInitials(email: string) {
  const local = email.split("@")[0] ?? ""
  const parts = local.split(/[._-]/).filter(Boolean)
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase()
  }
  return (local.slice(0, 2) || "??").toUpperCase()
}

export default async function AppLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: partner } = await supabase
    .from("partners")
    .select("*")
    .eq("auth_user_id", user.id)
    .maybeSingle()

  const advisor = await isAdvisor(supabase)

  // Asesores "puros" no tienen fila en `partners`: su home es /clientes. Solo
  // mostramos el error de "cuenta no encontrada" a quien no es aliado ni asesor.
  if (!partner && !advisor) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
        <div className="max-w-[420px] w-full text-center">
          <h1 className="font-heading text-lg font-medium mb-2">
            No encontramos tu cuenta
          </h1>
          <p className="text-sm text-muted-foreground">
            No encontramos tu cuenta de aliado. Contacta soporte.
          </p>
        </div>
      </div>
    )
  }

  if (partner?.portal_status === "suspended") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
        <div className="max-w-[420px] w-full text-center">
          <h1 className="font-heading text-lg font-medium mb-2">
            Cuenta suspendida
          </h1>
          <p className="text-sm text-muted-foreground">
            Tu cuenta está suspendida. Contacta a soporte:{" "}
            <a
              href="mailto:hola@trol.mx"
              className="text-primary hover:underline"
            >
              hola@trol.mx
            </a>
          </p>
        </div>
      </div>
    )
  }

  const email = user.email ?? ""
  const initials = getInitials(email)

  return (
    <SidebarNavProvider>
    <div className="flex flex-col h-screen">
      <header className="sticky top-0 z-30 h-14 border-b bg-background flex items-center justify-between gap-2 px-4 md:px-6">
        <div className="flex items-center gap-2 min-w-0">
          <SidebarNavTrigger />
          <div className="font-semibold truncate">El Trol — Portal de Aliados</div>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              type="button"
              className="flex items-center gap-2 rounded-full focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-ring/30"
            >
              <Avatar size="sm">
                <AvatarFallback>{initials}</AvatarFallback>
              </Avatar>
              <span className="text-sm text-muted-foreground hidden sm:inline">
                {email}
              </span>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="min-w-56">
            <DropdownMenuLabel>{email}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <SignOutButton />
          </DropdownMenuContent>
        </DropdownMenu>
      </header>

      <div className="flex flex-1 overflow-hidden">
        <SidebarNav isAdvisor={advisor} />

        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <div className="max-w-[1280px] mx-auto">{children}</div>
        </main>
      </div>
      <Toaster />
    </div>
    </SidebarNavProvider>
  )
}
