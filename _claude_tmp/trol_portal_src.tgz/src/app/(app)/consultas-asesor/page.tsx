export const dynamic = "force-dynamic"

import { redirect } from "next/navigation"
import Link from "next/link"
import { ClipboardList } from "lucide-react"

import { createClient } from "@/lib/supabase/server"
import { isAdvisor } from "@/lib/auth/roles"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  getStatusInfo,
  getStatusBadgeClasses,
  DOC_PREVIO_STATUS,
} from "@/lib/consulta-status"
import {
  LiberadoBadge,
  LiberarDiagnosticoButton,
} from "@/components/liberar-diagnostico"
import SearchBox from "../consultas/search-box"
import AliadoFilter, { type AliadoOption } from "./aliado-filter"

import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Consultas (Asesor)",
  description: "Consultas de todos los aliados, en vista de asesor.",
}

const PAGE_SIZE = 50

type ProductRef = { code: string | null; name: string | null }

type ConsultaRow = {
  id: string
  created_at: string
  status: string | null
  nombre: string | null
  apellidos: string | null
  curp: string | null
  partner_id: string | null
  price_credits: number | null
  documento_diagnostico_url: string | null
  documento_diagnostico_avanzado_url: string | null
  documento_checkup_url: string | null
  documento_sisec_url: string | null
  doc_liberado_at: string | null
  products: ProductRef | ProductRef[] | null
}

function formatFecha(iso: string) {
  return new Intl.DateTimeFormat("es-MX", {
    day: "numeric",
    month: "short",
    year: "numeric",
  })
    .format(new Date(iso))
    .replace(/\./g, "")
}

function pickProduct(p: ConsultaRow["products"]): ProductRef | null {
  if (!p) return null
  return Array.isArray(p) ? p[0] ?? null : p
}

export default async function ConsultasAsesorPage({
  searchParams,
}: {
  searchParams: { q?: string; aliado?: string; page?: string }
}) {
  const supabase = await createClient()

  if (!(await isAdvisor(supabase))) {
    redirect("/dashboard")
  }

  const { data: aliadosData } = await supabase.rpc("list_aliados")
  const aliados = (aliadosData ?? []) as AliadoOption[]
  const aliadoMap = new Map(aliados.map((a) => [a.partner_id, a.name]))

  const q = (searchParams.q ?? "").trim()
  const aliadoId = (searchParams.aliado ?? "").trim() || null
  const page = Math.max(0, parseInt(searchParams.page ?? "0", 10) || 0)
  const from = page * PAGE_SIZE
  const to = from + PAGE_SIZE - 1

  let query = supabase
    .from("partner_transactions")
    .select(
      "id, created_at, status, nombre, apellidos, curp, partner_id, price_credits, documento_diagnostico_url, documento_diagnostico_avanzado_url, documento_checkup_url, documento_sisec_url, doc_liberado_at, products(code, name)",
      { count: "exact" }
    )
    .order("created_at", { ascending: false })
    .range(from, to)

  if (aliadoId) {
    query = query.eq("partner_id", aliadoId)
  }

  if (q) {
    query = query.or(
      `curp.ilike.%${q}%,nombre.ilike.%${q}%,apellidos.ilike.%${q}%`
    )
  }

  const { data, count } = await query
  const rows = (data ?? []) as ConsultaRow[]
  const total = count ?? 0
  const isEmpty = rows.length === 0
  const hasPrev = page > 0
  const hasNext = from + rows.length < total

  const pageHref = (p: number) => {
    const params = new URLSearchParams()
    if (q) params.set("q", q)
    if (aliadoId) params.set("aliado", aliadoId)
    if (p > 0) params.set("page", String(p))
    const qs = params.toString()
    return qs ? `/consultas-asesor?${qs}` : "/consultas-asesor"
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-medium">
          Consultas
          <span className="ml-2 inline-flex items-center rounded-full bg-amber-100 text-amber-900 px-2 py-0.5 text-xs font-semibold uppercase tracking-wide align-middle">
            Asesor
          </span>
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Consultas B2B de todos los aliados — vista de asesoría (solo lectura)
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1">
          <SearchBox placeholder="Buscar por CURP, nombre o apellidos..." />
        </div>
        <AliadoFilter aliados={aliados} selected={aliadoId} />
      </div>

      {isEmpty ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center text-center py-16 gap-4">
            <div className="rounded-full bg-muted p-4">
              <ClipboardList className="size-8 text-muted-foreground" />
            </div>
            <h2 className="font-heading text-lg font-medium">
              Sin consultas para los filtros actuales
            </h2>
            <Button asChild variant="outline" size="lg">
              <Link href="/consultas-asesor">Limpiar filtros</Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="px-0">
            <div className="px-6 pt-4 pb-2 text-xs text-muted-foreground">
              {total.toLocaleString("es-MX")} consulta{total === 1 ? "" : "s"}
              {aliadoId ? ` · ${aliadoMap.get(aliadoId) ?? "aliado"}` : ""}
              {q ? ` · «${q}»` : ""}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="px-6 py-3 font-medium">Fecha</th>
                    <th className="px-6 py-3 font-medium">Cliente</th>
                    <th className="px-6 py-3 font-medium">CURP</th>
                    <th className="px-6 py-3 font-medium">Aliado</th>
                    <th className="px-6 py-3 font-medium">Producto</th>
                    <th className="px-6 py-3 font-medium">Status</th>
                    <th className="px-6 py-3 font-medium text-right">Acción</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => {
                    const product = pickProduct(row.products)
                    const cliente = [row.nombre, row.apellidos]
                      .filter(Boolean)
                      .join(" ")
                      .trim()
                    const info = getStatusInfo(row.status ?? "")
                    const cls = getStatusBadgeClasses(info.variant)
                    return (
                      <tr
                        key={row.id}
                        className="border-b last:border-b-0 hover:bg-muted/40 transition-colors"
                      >
                        <td className="px-6 py-3 whitespace-nowrap">
                          {formatFecha(row.created_at)}
                        </td>
                        <td className="px-6 py-3 font-medium">
                          <Link
                            href={`/consultas/${row.id}`}
                            className="text-primary hover:underline"
                          >
                            {cliente || "—"}
                          </Link>
                        </td>
                        <td className="px-6 py-3 font-mono text-xs text-muted-foreground">
                          {row.curp ?? "—"}
                        </td>
                        <td className="px-6 py-3 whitespace-nowrap">
                          {row.partner_id
                            ? aliadoMap.get(row.partner_id) ?? "—"
                            : "—"}
                        </td>
                        <td className="px-6 py-3">
                          {product?.name ?? product?.code ?? "—"}
                        </td>
                        <td className="px-6 py-3">
                          <div className="flex flex-col items-start gap-1">
                            <span
                              className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${cls}`}
                            >
                              {info.label}
                            </span>
                            {row.doc_liberado_at && (
                              <LiberadoBadge liberadoAt={row.doc_liberado_at} />
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-3 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-3">
                            {row.status === DOC_PREVIO_STATUS &&
                              !row.doc_liberado_at && (
                                <LiberarDiagnosticoButton
                                  consultaId={row.id}
                                  label="Liberar"
                                />
                              )}
                            <Link
                              href={`/consultas/${row.id}`}
                              className="text-primary hover:underline text-sm"
                            >
                              Ver detalle →
                            </Link>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-between gap-4 px-6 py-4 border-t">
              <span className="text-xs text-muted-foreground">
                Mostrando {from + 1}–{from + rows.length} de{" "}
                {total.toLocaleString("es-MX")}
              </span>
              <div className="flex gap-2">
                <Button
                  asChild={hasPrev}
                  variant="outline"
                  size="sm"
                  disabled={!hasPrev}
                >
                  {hasPrev ? (
                    <Link href={pageHref(page - 1)}>← Anteriores</Link>
                  ) : (
                    <span>← Anteriores</span>
                  )}
                </Button>
                <Button
                  asChild={hasNext}
                  variant="outline"
                  size="sm"
                  disabled={!hasNext}
                >
                  {hasNext ? (
                    <Link href={pageHref(page + 1)}>Siguientes →</Link>
                  ) : (
                    <span>Siguientes →</span>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
