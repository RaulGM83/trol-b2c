"use client"

import { useRouter, useSearchParams, usePathname } from "next/navigation"

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

export type AliadoOption = {
  partner_id: string
  name: string
  total_consultas: number
}

const ALL = "__all__"

export default function AliadoFilter({
  aliados,
  selected,
}: {
  aliados: AliadoOption[]
  selected: string | null
}) {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  const onChange = (value: string) => {
    const params = new URLSearchParams(searchParams.toString())
    if (value === ALL) {
      params.delete("aliado")
    } else {
      params.set("aliado", value)
    }
    // Cambiar de aliado siempre vuelve a la primera página.
    params.delete("page")
    const qs = params.toString()
    router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false })
  }

  return (
    <Select value={selected ?? ALL} onValueChange={onChange}>
      <SelectTrigger className="w-full sm:w-72">
        <SelectValue placeholder="Filtrar por aliado" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value={ALL}>Todos los aliados</SelectItem>
        {aliados.map((a) => (
          <SelectItem key={a.partner_id} value={a.partner_id}>
            {a.name} ({a.total_consultas})
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}
