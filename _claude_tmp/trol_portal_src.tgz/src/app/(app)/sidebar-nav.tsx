"use client"

import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, X } from "lucide-react"

import { Button } from "@/components/ui/button"

type NavItem = {
  label: string
  href: string
  match: "exact" | "prefix"
}

const NAV_ITEMS: NavItem[] = [
  { label: "Dashboard", href: "/dashboard", match: "exact" },
  { label: "Consultas", href: "/consultas", match: "prefix" },
  { label: "Delegaciones", href: "/delegaciones", match: "prefix" },
  { label: "Saldo", href: "/saldo", match: "prefix" },
]

const SETTINGS_ITEM: NavItem = {
  label: "Configuración",
  href: "/configuracion",
  match: "prefix",
}

const ADVISOR_ITEMS: NavItem[] = [
  { label: "Clientes", href: "/clientes", match: "prefix" },
  { label: "Ruteo", href: "/ruteo", match: "prefix" },
  { label: "Consultas (asesor)", href: "/consultas-asesor", match: "prefix" },
]

function isActive(pathname: string, item: NavItem) {
  if (item.match === "exact") return pathname === item.href
  return pathname === item.href || pathname.startsWith(`${item.href}/`)
}

// ----------------------------------------------------------------------------
// Estado del cajón móvil compartido entre el botón hamburguesa (en el header)
// y el propio cajón (en la barra lateral).
// ----------------------------------------------------------------------------

const MobileNavContext = createContext<{
  open: boolean
  setOpen: (v: boolean) => void
}>({ open: false, setOpen: () => {} })

export function SidebarNavProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false)
  return (
    <MobileNavContext.Provider value={{ open, setOpen }}>
      {children}
    </MobileNavContext.Provider>
  )
}

/** Botón hamburguesa para el header. Solo visible en móvil. */
export function SidebarNavTrigger() {
  const { setOpen } = useContext(MobileNavContext)
  return (
    <button
      type="button"
      onClick={() => setOpen(true)}
      aria-label="Abrir menú"
      className="md:hidden inline-flex h-9 w-9 items-center justify-center rounded-md text-[#0f172a] hover:bg-muted focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-[#a3e635]/40"
    >
      <Menu className="h-5 w-5" />
    </button>
  )
}

function NavLink({
  item,
  pathname,
  onNavigate,
}: {
  item: NavItem
  pathname: string
  onNavigate?: () => void
}) {
  const active = isActive(pathname, item)
  return (
    <Button
      asChild
      variant={active ? "secondary" : "ghost"}
      className="justify-start"
    >
      <Link
        href={item.href}
        onClick={onNavigate}
        className={active ? "" : "text-muted-foreground"}
      >
        {item.label}
      </Link>
    </Button>
  )
}

function NavList({
  pathname,
  isAdvisor,
  onNavigate,
}: {
  pathname: string
  isAdvisor: boolean
  onNavigate?: () => void
}) {
  return (
    <nav className="flex flex-col gap-1">
      {NAV_ITEMS.map((item) => (
        <NavLink
          key={item.href}
          item={item}
          pathname={pathname}
          onNavigate={onNavigate}
        />
      ))}

      {isAdvisor && (
        <>
          <div className="mt-4 mb-1 px-3 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            Asesoría
          </div>
          {ADVISOR_ITEMS.map((item) => (
            <NavLink
              key={item.href}
              item={item}
              pathname={pathname}
              onNavigate={onNavigate}
            />
          ))}
        </>
      )}

      <NavLink item={SETTINGS_ITEM} pathname={pathname} onNavigate={onNavigate} />
    </nav>
  )
}

export function SidebarNav({ isAdvisor = false }: { isAdvisor?: boolean }) {
  const pathname = usePathname() ?? ""
  const { open, setOpen } = useContext(MobileNavContext)

  // Cierra el cajón al cambiar de ruta.
  useEffect(() => {
    setOpen(false)
  }, [pathname, setOpen])

  const close = () => setOpen(false)

  return (
    <>
      {/* Desktop: barra lateral fija (igual que antes). */}
      <aside className="hidden md:block w-60 border-r p-4 shrink-0 overflow-y-auto">
        <NavList pathname={pathname} isAdvisor={isAdvisor} />
      </aside>

      {/* Móvil: backdrop semitransparente. */}
      <div
        onClick={close}
        aria-hidden="true"
        className={`md:hidden fixed inset-0 z-40 bg-black/50 transition-opacity duration-200 ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      />

      {/* Móvil: cajón deslizable desde la izquierda. */}
      <aside
        role="dialog"
        aria-modal="true"
        aria-label="Menú de navegación"
        className={`md:hidden fixed inset-y-0 left-0 z-50 w-64 max-w-[80%] border-r bg-background shadow-xl transition-transform duration-200 ease-out flex flex-col ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between gap-2 h-14 px-4 border-b">
          <span className="font-semibold text-[#0f172a]">
            El Trol{" "}
            <span className="text-[#a3e635]">·</span> Portal
          </span>
          <button
            type="button"
            onClick={close}
            aria-label="Cerrar menú"
            className="inline-flex h-9 w-9 items-center justify-center rounded-md text-[#0f172a] hover:bg-muted focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-[#a3e635]/40"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          <NavList pathname={pathname} isAdvisor={isAdvisor} onNavigate={close} />
        </div>
      </aside>
    </>
  )
}
