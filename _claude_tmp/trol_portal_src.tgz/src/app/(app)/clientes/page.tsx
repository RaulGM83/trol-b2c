export const dynamic = "force-dynamic"

import { redirect } from "next/navigation"
import Link from "next/link"
import { Users, ArrowUp, ArrowDown, ArrowUpDown } from "lucide-react"

import { createClient } from "@/lib/supabase/server"
import { isAdvisor } from "@/lib/auth/roles"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import SearchBox from "../consultas/search-box"

import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Clientes",
  description: "Tus clientes y su estatus pensional.",
}

const PAGE_SIZE = 50

type ClienteRow = {
  id: string
  nombre: string | null
  apellidos: string | null
  curp: string | null
  telefono: string | null
  mod40_retro_hoy: string | null
  mod40_retro_futuro: string | null
  Solucion_hogar: string | null
  Mejoravit_activo: string | null
  oportunidad_infonavit: string | null
  Ley_imss: string | null
  semanas_cotizadas: string | null
  puntaje_total: string | null
  pension_base: string | null
  pension_maxima: string | null
  sub_estado: string | null
  "última_fecha_sisec": string | null
  created_at: string | null
}

function dash(v: string | null | undefined) {
  const s = (v ?? "").toString().trim()
  return s.length ? s : "—"
}

function money(v: string | null | undefined): string | null {
  if (v === null || v === undefined) return null
  const n = parseFloat(String(v).replace(/[^0-9.-]/g, ""))
  if (!Number.isFinite(n)) return null
  return new Intl.NumberFormat("es-MX", {
    style: "currency",
    currency: "MXN",
    maximumFractionDigits: 0,
  }).format(n)
}

function fechaSisec(iso: string | null): string {
  if (!iso) return "—"
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return "—"
  return new Intl.DateTimeFormat("es-MX", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    timeZone: "America/Mexico_City",
  }).format(d)
}

function fechaHoraCDMX(iso: string | null): string {
  if (!iso) return "—"
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return "—"
  return new Intl.DateTimeFormat("es-MX", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZone: "America/Mexico_City",
  })
    .format(d)
    .replace(",", "")
}

type Tono = "alto" | "lima" | "neutral"

// Producto Infonavit/Mejoravit top, desde la semilla (distingue activo/inactivo).
function infonavitLabel(top: string | null | undefined): string | null {
  if (!top) return null
  const k = top.trim().toUpperCase()
  if (k === "SOLUCIÓN HOGAR" || k === "SOLUCION HOGAR") return "Infonavit"
  if (k === "MEJORAVIT ACTIVO") return "Mejoravit activo"
  if (k === "MEJORAVIT INACTIVO") return "Mejoravit inactivo"
  return null
}

// Oportunidad principal por prioridad: Mod 40 (hoy/futura) → producto Infonavit
// → fallback "Diagnóstico Avanzado".
function oportunidad(row: ClienteRow): { label: string; tono: Tono } {
  if (row.mod40_retro_hoy === "true")
    return { label: "Mod 40 (hoy)", tono: "alto" }
  if (row.mod40_retro_futuro === "true")
    return { label: "Mod 40 (futura)", tono: "lima" }
  const inf = infonavitLabel(row.oportunidad_infonavit)
  if (inf) return { label: inf, tono: "neutral" }
  return { label: "Diagnóstico Avanzado", tono: "neutral" }
}

const TONO_CLASSES: Record<Tono, string> = {
  // Alto valor: lima sólida sobre navy.
  alto: "bg-lime-400 text-slate-900",
  // Lima suave.
  lima: "bg-lime-400/20 text-lime-700 dark:text-lime-300",
  // Neutro.
  neutral: "bg-muted text-muted-foreground",
}

export default async function ClientesPage({
  searchParams,
}: {
  searchParams: { q?: string; page?: string; sort?: string }
}) {
  const supabase = await createClient()

  if (!(await isAdvisor(supabase))) {
    redirect("/dashboard")
  }

  const q = (searchParams.q ?? "").trim()
  const sort = searchParams.sort ?? ""
  const page = Math.max(0, parseInt(searchParams.page ?? "0", 10) || 0)
  const from = page * PAGE_SIZE
  const to = from + PAGE_SIZE - 1

  let query = supabase
    .from("clientes")
    .select(
      'id, nombre, apellidos, curp, telefono, mod40_retro_hoy, mod40_retro_futuro, Solucion_hogar, Mejoravit_activo, oportunidad_infonavit:calculo_pensional->diagnostico->>oportunidad_infonavit, Ley_imss, semanas_cotizadas, puntaje_total, pension_base, pension_maxima, sub_estado, "última_fecha_sisec", created_at',
      { count: "exact" }
    )

  // Orden: por puntaje (numérico via columna generada puntaje_num) si se pide;
  // por defecto, los más recientes primero.
  if (sort === "puntaje.asc") {
    query = query.order("puntaje_num", { ascending: true, nullsFirst: false })
  } else if (sort === "puntaje.desc") {
    query = query.order("puntaje_num", { ascending: false, nullsFirst: false })
  } else {
    query = query.order("created_at", { ascending: false })
  }

  query = query.range(from, to)

  if (q) {
    // Teléfono pegado con formato ("55 1687 5975", "+52 55-1687-5975") busca
    // contra telefono_normalizado (columna generada, solo dígitos, índice trigram).
    // Si el texto trae letras es CURP/nombre/email, no teléfono.
    const digits = q.replace(/\D/g, "")
    const esBusquedaTelefono = digits.length >= 7 && !/[a-zA-Z]/.test(q)

    if (esBusquedaTelefono) {
      query = query.ilike("telefono_normalizado", `%${digits}%`)
    } else {
      query = query.or(
        `curp.ilike.%${q}%,nombre.ilike.%${q}%,apellidos.ilike.%${q}%,telefono.ilike.%${q}%,email.ilike.%${q}%`
      )
    }
  }

  const { data, count } = await query
  const rows = (data ?? []) as ClienteRow[]
  const total = count ?? 0
  const isEmpty = rows.length === 0
  const hasQuery = q.length > 0
  const hasPrev = page > 0
  const hasNext = from + rows.length < total

  const hrefWith = (overrides: { page?: number; sort?: string }) => {
    const params = new URLSearchParams()
    if (q) params.set("q", q)
    const nextSort = overrides.sort !== undefined ? overrides.sort : sort
    if (nextSort) params.set("sort", nextSort)
    const nextPage = overrides.page !== undefined ? overrides.page : page
    if (nextPage > 0) params.set("page", String(nextPage))
    const qs = params.toString()
    return qs ? `/clientes?${qs}` : "/clientes"
  }

  const pageHref = (p: number) => hrefWith({ page: p })
  // Al cambiar el orden, volvemos a la primera página.
  const nextPuntajeSort = sort === "puntaje.desc" ? "puntaje.asc" : "puntaje.desc"
  const puntajeSortHref = hrefWith({ sort: nextPuntajeSort, page: 0 })
  const PuntajeSortIcon =
    sort === "puntaje.desc"
      ? ArrowDown
      : sort === "puntaje.asc"
        ? ArrowUp
        : ArrowUpDown

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-medium flex items-center gap-2 text-slate-900 dark:text-slate-100">
          <span className="inline-block h-6 w-1 rounded-full bg-lime-400" />
          Clientes
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Cartera B2C — vista de asesoría (solo lectura)
        </p>
      </div>

      <div className="mb-2">
        <SearchBox placeholder="Buscar por CURP, nombre, teléfono o email..." />
      </div>

      {isEmpty ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center text-center py-16 gap-4">
            <div className="rounded-full bg-muted p-4">
              <Users className="size-8 text-muted-foreground" />
            </div>
            <div className="flex flex-col gap-1">
              <h2 className="font-heading text-lg font-medium">
                {hasQuery ? `Sin resultados para «${q}»` : "Aún no hay clientes"}
              </h2>
              <p className="text-sm text-muted-foreground">
                {hasQuery
                  ? "Prueba con un CURP, nombre, teléfono o email distinto"
                  : "Cuando se registren clientes, aparecerán aquí"}
              </p>
            </div>
            {hasQuery && (
              <Button asChild variant="outline" size="lg" className="mt-2">
                <Link href="/clientes">Limpiar búsqueda</Link>
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="px-0">
            <div className="px-6 pt-4 pb-2 text-xs text-muted-foreground">
              {total.toLocaleString("es-MX")} cliente{total === 1 ? "" : "s"}
              {hasQuery ? ` para «${q}»` : ""}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-lime-400/30 bg-lime-400/[0.06] text-left text-xs uppercase tracking-wide text-slate-700 dark:text-slate-300">
                    <th className="px-6 py-3 font-medium">Nombre</th>
                    <th className="px-6 py-3 font-medium">Teléfono</th>
                    <th className="px-6 py-3 font-medium">Oportunidad</th>
                    <th className="px-6 py-3 font-medium">Ley · semanas</th>
                    <th className="px-6 py-3 font-medium">
                      <Link
                        href={puntajeSortHref}
                        scroll={false}
                        className="inline-flex items-center gap-1 hover:text-foreground transition-colors"
                      >
                        Puntaje
                        <PuntajeSortIcon className="size-3.5" />
                      </Link>
                    </th>
                    <th className="px-6 py-3 font-medium">Pensión</th>
                    <th className="px-6 py-3 font-medium hidden xl:table-cell">
                      Sub-estado
                    </th>
                    <th className="px-6 py-3 font-medium hidden xl:table-cell">
                      Última SISEC
                    </th>
                    <th className="px-6 py-3 font-medium">Creación</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => {
                    const op = oportunidad(row)
                    const tel = (row.telefono ?? "").trim()
                    const pensionBase = money(row.pension_base)
                    const pensionMax = money(row.pension_maxima)
                    const tienePension = pensionBase || pensionMax
                    return (
                      <tr
                        key={row.id}
                        className="border-b last:border-b-0 hover:bg-lime-400/[0.06] transition-colors"
                      >
                        <td className="px-6 py-3">
                          <Link
                            href={`/clientes/${row.id}`}
                            className="font-medium text-primary hover:underline"
                          >
                            {[row.nombre, row.apellidos]
                              .filter(Boolean)
                              .join(" ")
                              .trim() || "—"}
                          </Link>
                          <div className="font-mono text-xs text-muted-foreground mt-0.5">
                            {dash(row.curp)}
                          </div>
                        </td>
                        <td className="px-6 py-3 whitespace-nowrap">
                          {tel ? (
                            <a
                              href={`tel:${tel.replace(/[^0-9+]/g, "")}`}
                              className="text-primary hover:underline"
                            >
                              {tel}
                            </a>
                          ) : (
                            "—"
                          )}
                        </td>
                        <td className="px-6 py-3">
                          <span
                            className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium whitespace-nowrap ${TONO_CLASSES[op.tono]}`}
                          >
                            {op.label}
                          </span>
                        </td>
                        <td className="px-6 py-3 whitespace-nowrap">
                          <span>{dash(row.Ley_imss)}</span>
                          <span className="text-muted-foreground">
                            {" · "}
                            {dash(row.semanas_cotizadas)} sem
                          </span>
                        </td>
                        <td className="px-6 py-3 whitespace-nowrap tabular-nums">
                          {dash(row.puntaje_total)}
                        </td>
                        <td className="px-6 py-3 whitespace-nowrap tabular-nums">
                          {tienePension ? (
                            <>
                              {pensionBase ?? "—"}
                              <span className="text-muted-foreground">{" → "}</span>
                              {pensionMax ?? "—"}
                            </>
                          ) : (
                            "—"
                          )}
                        </td>
                        <td className="px-6 py-3 hidden xl:table-cell">
                          {dash(row.sub_estado)}
                        </td>
                        <td className="px-6 py-3 whitespace-nowrap hidden xl:table-cell">
                          {fechaSisec(row["última_fecha_sisec"])}
                        </td>
                        <td className="px-6 py-3 whitespace-nowrap text-muted-foreground">
                          {fechaHoraCDMX(row.created_at)}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-between gap-4 px-6 py-4 border-t">
              <span className="text-xs text-muted-foreground">
                Mostrando {from + 1}–{from + rows.length} de{" "}
                {total.toLocaleString("es-MX")}
              </span>
              <div className="flex gap-2">
                <Button
                  asChild={hasPrev}
                  variant="outline"
                  size="sm"
                  disabled={!hasPrev}
                >
                  {hasPrev ? (
                    <Link href={pageHref(page - 1)}>← Anteriores</Link>
                  ) : (
                    <span>← Anteriores</span>
                  )}
                </Button>
                <Button
                  asChild={hasNext}
                  variant="outline"
                  size="sm"
                  disabled={!hasNext}
                >
                  {hasNext ? (
                    <Link href={pageHref(page + 1)}>Siguientes →</Link>
                  ) : (
                    <span>Siguientes →</span>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
