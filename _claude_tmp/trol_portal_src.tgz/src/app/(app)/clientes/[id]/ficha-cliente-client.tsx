"use client"

import Link from "next/link"
import { ChevronLeft, Phone, Mail, Calculator } from "lucide-react"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import {
  SectionTitle,
  Stat,
  OportunidadCard,
  EscenarioCard,
  DocumentCard,
  pesos,
  dash,
} from "@/components/ficha/pension-ui"
import type { EmpleoHistorial } from "@/lib/imss/historia-laboral"
import { DiagnosticoAvanzadoCard } from "./diagnostico-avanzado-card"
import { EditarContactoDialog } from "./editar-contacto-dialog"
import { ActualizarImssButton } from "./actualizar-imss-button"

export type DocItem = {
  title: string
  audience: string
  description: string
  url: string
  label: string
  mode: "download" | "open"
}

export type FichaCliente = {
  id: string
  nombre: string | null
  apellidos: string | null
  curp: string | null
  telefono: string | null
  email: string | null
  Ley_imss: string | null
  sub_estado: string | null
  // Situación al corte
  ultima_fecha_sisec: string | null
  edad: string
  semanas_cotizadas: string | null
  semanas_descontadas: string
  semanas_recuperadas: string
  status_empleo: string | null
  conservacionLabel: string
  conservacionDetalle: string | null
  sisec_refresh_solicitado_at: string | null
  // Datos personales
  fecha_nacimiento: string | null
  edo_republica: string | null
  nss: string | null
  // Fondos de retiro
  rcv97: string | null
  sar92: string | null
  infonavit_estimado: string | null
  // Escenarios
  pension_base: string | null
  edad_base: string | null
  pension_maxima: string | null
  edad_maxima: string | null
  pensionMod40_retro_hoy: string | null
  pension_mod40_futuro: string | null
}

type Props = {
  cliente: FichaCliente
  asesoriaBasica: string | null
  tieneCalculadora: boolean
  oportunidad: { principal: string; otras: string[]; alto: boolean }
  historia: EmpleoHistorial[]
  docs: DocItem[]
  diagnosticoAvanzado: { url: string | null; solicitadoAt: string | null }
}

function fechaCorta(iso: string | null): string {
  if (!iso) return "—"
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  return new Intl.DateTimeFormat("es-MX", {
    day: "numeric",
    month: "short",
    year: "numeric",
    timeZone: "America/Mexico_City",
  })
    .format(d)
    .replace(/\./g, "")
}

export function FichaClienteClient({
  cliente,
  asesoriaBasica,
  tieneCalculadora,
  oportunidad,
  historia,
  docs,
  diagnosticoAvanzado,
}: Props) {
  const nombreCompleto =
    [cliente.nombre, cliente.apellidos].filter(Boolean).join(" ").trim() ||
    "Cliente sin nombre"
  const tel = (cliente.telefono ?? "").trim()
  const email = (cliente.email ?? "").trim()

  return (
    <div className="w-full max-w-[1200px] mx-auto py-6 px-4 flex flex-col gap-6">
      {/* Hero / header */}
      <div className="flex flex-col gap-4">
        <div>
          <Button asChild variant="ghost" size="sm">
            <Link href="/clientes">
              <ChevronLeft />
              Clientes
            </Link>
          </Button>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
          <div className="flex flex-col gap-2 min-w-0">
            <h1 className="font-heading font-bold text-2xl text-slate-900 dark:text-slate-100">
              {nombreCompleto}
            </h1>
            <p className="font-mono text-xs text-muted-foreground">
              {dash(cliente.curp)}
            </p>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="inline-flex items-center rounded-full bg-lime-400/20 px-3 py-1 text-xs font-semibold text-lime-700 dark:text-lime-300">
                {dash(cliente.Ley_imss)}
              </span>
              {cliente.sub_estado && cliente.sub_estado.trim() && (
                <span className="inline-flex items-center rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">
                  {cliente.sub_estado}
                </span>
              )}
            </div>
          </div>

          <div className="flex flex-col items-start sm:items-end gap-2">
            {tieneCalculadora && (
              <Button asChild>
                <Link href={`/clientes/${cliente.id}/calculadora`}>
                  <Calculator />
                  Abrir calculadora
                </Link>
              </Button>
            )}
            <div className="flex items-center gap-1.5 flex-wrap">
              {tel && (
                <Button asChild variant="outline" size="sm">
                  <a href={`tel:${tel.replace(/[^0-9+]/g, "")}`}>
                    <Phone />
                    Llamar
                  </a>
                </Button>
              )}
              {email && (
                <Button asChild variant="outline" size="sm">
                  <a href={`mailto:${email}`}>
                    <Mail />
                    Email
                  </a>
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>

      <Separator />

      <Tabs defaultValue="resumen" className="flex-col w-full">
        <TabsList className="!h-8 p-0.5 w-fit">
          <TabsTrigger value="resumen" className="!px-3 !py-1 text-sm">
            Resumen
          </TabsTrigger>
          <TabsTrigger value="personales" className="!px-3 !py-1 text-sm">
            Datos personales
          </TabsTrigger>
          <TabsTrigger value="documentos" className="!px-3 !py-1 text-sm">
            Documentos
          </TabsTrigger>
        </TabsList>

        {/* ----- Resumen ----- */}
        <TabsContent value="resumen" className="mt-2 w-full flex flex-col gap-4">
          {/* 1) Situación al corte */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between gap-3">
                <SectionTitle>Situación al corte</SectionTitle>
                <ActualizarImssButton
                  clienteId={cliente.id}
                  solicitadoAt={cliente.sisec_refresh_solicitado_at}
                />
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                <Stat
                  label="Fecha del corte"
                  value={fechaCorta(cliente.ultima_fecha_sisec)}
                />
                <Stat
                  label="Edad"
                  value={cliente.edad === "—" ? "—" : `${cliente.edad} años`}
                />
                <Stat
                  label="Semanas cotizadas"
                  value={dash(cliente.semanas_cotizadas)}
                />
                <Stat
                  label="Semanas descontadas"
                  value={dash(cliente.semanas_descontadas)}
                />
                <Stat
                  label="Semanas recuperadas"
                  value={dash(cliente.semanas_recuperadas)}
                />
                <Stat
                  label="Estatus de empleo"
                  value={dash(cliente.status_empleo)}
                />
                <Stat
                  label="Conservación de derechos"
                  value={
                    <>
                      {cliente.conservacionLabel}
                      {cliente.conservacionDetalle && (
                        <span className="block text-xs text-muted-foreground font-normal mt-0.5">
                          {cliente.conservacionDetalle}
                        </span>
                      )}
                    </>
                  }
                />
              </div>
            </CardContent>
          </Card>

          {/* 2) Fondos de retiro */}
          <Card>
            <CardHeader>
              <SectionTitle>Fondos de retiro</SectionTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Stat label="RCV 97" value={pesos(cliente.rcv97)} />
                <Stat label="SAR 92" value={pesos(cliente.sar92)} />
                <Stat
                  label="Infonavit estimado"
                  value={pesos(cliente.infonavit_estimado)}
                />
              </div>
            </CardContent>
          </Card>

          {/* 3) Escenarios de pensión */}
          <Card>
            <CardHeader>
              <SectionTitle>Escenarios de pensión</SectionTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <EscenarioCard
                  title="Escenario base"
                  subtitle="Si sigue como va"
                  monto={pesos(cliente.pension_base)}
                  edad={dash(cliente.edad_base)}
                />
                <EscenarioCard
                  title="Escenario máximo"
                  subtitle="Con estrategia Trol"
                  monto={pesos(cliente.pension_maxima)}
                  edad={dash(cliente.edad_maxima)}
                  highlight
                />
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <EscenarioCard
                  title="Modalidad 40 (hoy)"
                  subtitle="Pensión con Mod 40 retroactiva hoy"
                  monto={pesos(cliente.pensionMod40_retro_hoy)}
                  etiqueta="Estrategia"
                />
                <EscenarioCard
                  title="Modalidad 40 (futura)"
                  subtitle="Pensión con Mod 40 a futuro"
                  monto={pesos(cliente.pension_mod40_futuro)}
                  etiqueta="Estrategia"
                />
              </div>
            </CardContent>
          </Card>

          {/* 4) Historial laboral (acordeón, cerrado por defecto) */}
          <Card>
            <CardContent className="py-2">
              <details className="group">
                <summary className="flex items-center justify-between cursor-pointer list-none py-4">
                  <SectionTitle count={historia.length}>
                    Historial laboral
                  </SectionTitle>
                  <ChevronLeft className="size-4 -rotate-90 transition-transform group-open:rotate-90 text-muted-foreground" />
                </summary>
                <div className="pt-4 mt-2 border-t">
                  {historia.length === 0 ? (
                    <p className="text-sm text-muted-foreground">
                      Sin historia laboral disponible
                    </p>
                  ) : (
                    <ol className="relative flex flex-col gap-4 before:absolute before:bottom-3 before:left-[0.4375rem] before:top-3 before:w-px before:bg-border">
                      {historia.map((e, i) => {
                        const vigente = !e.fecha_fin
                        return (
                          <li key={i} className="relative pl-7">
                            <span
                              className={`absolute left-1 top-5 size-2.5 rounded-full ring-4 ring-background ${
                                vigente
                                  ? "bg-lime-400"
                                  : "bg-muted-foreground/30"
                              }`}
                            />
                            <div
                              className={`rounded-lg border bg-card p-4 transition-colors hover:border-lime-400/60 ${
                                vigente
                                  ? "border-lime-400/50 bg-lime-400/[0.04]"
                                  : "border-border"
                              }`}
                            >
                              <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-1">
                                <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                                  {dash(e.empleador)}
                                </h3>
                                <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground whitespace-nowrap">
                                  {fechaCorta(e.fecha_inicio)} —{" "}
                                  {vigente ? (
                                    <span className="inline-flex items-center rounded-full bg-lime-400 px-2 py-0.5 text-xs font-semibold text-slate-900">
                                      Vigente
                                    </span>
                                  ) : (
                                    fechaCorta(e.fecha_fin)
                                  )}
                                </span>
                              </div>
                              <dl className="mt-3 grid grid-cols-2 gap-x-6 gap-y-2 sm:grid-cols-3">
                                <Stat
                                  label="Salario base"
                                  value={pesos(e.salario_base)}
                                />
                                <Stat
                                  label="Entidad federativa"
                                  value={dash(e.entidad_federativa)}
                                />
                                <Stat
                                  label="Registro patronal"
                                  value={dash(e.registro_patronal)}
                                />
                              </dl>
                            </div>
                          </li>
                        )
                      })}
                    </ol>
                  )}
                </div>
              </details>
            </CardContent>
          </Card>

          {/* 5) Asesoría básica (solo si hay contenido) */}
          {asesoriaBasica && (
            <Card>
              <CardHeader>
                <SectionTitle>Asesoría básica</SectionTitle>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-wrap text-sm leading-relaxed text-slate-900 dark:text-slate-100">
                  {asesoriaBasica}
                </p>
              </CardContent>
            </Card>
          )}

          {/* 6) Oportunidades (al final) */}
          <div className="flex flex-col gap-3">
            <SectionTitle>Oportunidades</SectionTitle>
            <OportunidadCard label={oportunidad.principal} alto={oportunidad.alto} />
            {oportunidad.otras.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {oportunidad.otras.map((o) => (
                  <span
                    key={o}
                    className="inline-flex items-center rounded-full bg-lime-400/15 px-3 py-1 text-sm font-medium text-lime-700 dark:text-lime-300"
                  >
                    {o}
                  </span>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        {/* ----- Datos personales ----- */}
        <TabsContent value="personales" className="mt-2 w-full">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between gap-3">
                <SectionTitle>Datos personales</SectionTitle>
                <EditarContactoDialog
                  clienteId={cliente.id}
                  nombre={cliente.nombre}
                  apellidos={cliente.apellidos}
                  email={cliente.email}
                  telefono={cliente.telefono}
                  curp={cliente.curp}
                />
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                <Stat label="Nombre" value={dash(cliente.nombre)} />
                <Stat label="Apellidos" value={dash(cliente.apellidos)} />
                <Stat label="CURP" value={dash(cliente.curp)} />
                <Stat label="Teléfono" value={dash(cliente.telefono)} />
                <Stat
                  label="Fecha de nacimiento"
                  value={dash(cliente.fecha_nacimiento)}
                />
                <Stat label="Estado" value={dash(cliente.edo_republica)} />
                <Stat label="NSS" value={dash(cliente.nss)} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ----- Documentos ----- */}
        <TabsContent value="documentos" className="mt-2 w-full flex flex-col gap-4">
          <DiagnosticoAvanzadoCard
            clienteId={cliente.id}
            url={diagnosticoAvanzado.url}
            solicitadoAt={diagnosticoAvanzado.solicitadoAt}
            tieneSemilla={tieneCalculadora}
          />
          {docs.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center text-center py-16 gap-3">
                <p className="text-sm text-muted-foreground">
                  Este cliente aún no tiene documentos o links.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {docs.map((d) => (
                <DocumentCard key={d.title} {...d} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
