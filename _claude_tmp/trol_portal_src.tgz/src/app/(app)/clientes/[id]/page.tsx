export const dynamic = "force-dynamic"

import type { Metadata } from "next"
import { redirect, notFound } from "next/navigation"

import { createClient } from "@/lib/supabase/server"
import { isAdvisor } from "@/lib/auth/roles"
import { parseSemillaV2 } from "@/lib/imss/semilla"
import { getHistoriaLaboral } from "@/lib/imss/historia-laboral"
import {
  FichaClienteClient,
  type DocItem,
  type FichaCliente,
} from "./ficha-cliente-client"

const DRIVE_FOLDER_BASE = "https://drive.google.com/drive/folders/"

export async function generateMetadata({
  params,
}: {
  params: { id: string }
}): Promise<Metadata> {
  const supabase = await createClient()
  const { data } = await supabase
    .from("clientes")
    .select("nombre, apellidos")
    .eq("id", params.id)
    .maybeSingle()

  const nombre = [data?.nombre, data?.apellidos]
    .filter(Boolean)
    .join(" ")
    .trim()

  return { title: nombre || "Cliente" }
}

type ProcesoRow = {
  documento_final_url: string | null
  link_sisec: string | null
  conserva_derechos: string | null
  fecha_perdida_derechos: string | null
  semanas_descontadas: string | null
  semanas_recuperadas: string | null
}

// Semanas: prefiere la semilla; si no, procesos; si nada, "—".
function pickSemana(
  semVal: unknown,
  procVal: string | null | undefined
): string {
  if (semVal !== null && semVal !== undefined && String(semVal).trim() !== "") {
    return String(semVal)
  }
  const p = (procVal ?? "").toString().trim()
  return p || "—"
}

const MOD40_FLAGS = [
  { key: "mod40_retro_hoy", label: "Mod 40 (hoy)" },
  { key: "mod40_retro_futuro", label: "Mod 40 (futura)" },
] as const

// Producto Infonavit/Mejoravit top, tomado de la semilla (distingue activo/inactivo).
const INFONAVIT_LABELS: Record<string, string> = {
  "SOLUCIÓN HOGAR": "Infonavit / Solución hogar",
  "SOLUCION HOGAR": "Infonavit / Solución hogar",
  "MEJORAVIT ACTIVO": "Mejoravit activo",
  "MEJORAVIT INACTIVO": "Mejoravit inactivo",
}
function infonavitOportunidad(cp: unknown): string | null {
  const top = (cp as { diagnostico?: { oportunidad_infonavit?: string } } | null)
    ?.diagnostico?.oportunidad_infonavit
  if (!top) return null
  return INFONAVIT_LABELS[String(top).trim().toUpperCase()] ?? null
}

function calcEdad(fnac: string | null): string {
  if (!fnac) return "—"
  const d = new Date(fnac)
  if (Number.isNaN(d.getTime())) return "—"
  const now = new Date()
  let age = now.getFullYear() - d.getFullYear()
  const m = now.getMonth() - d.getMonth()
  if (m < 0 || (m === 0 && now.getDate() < d.getDate())) age--
  if (age < 0 || age > 120) return "—"
  return String(age)
}

// Conservación de derechos: primero de la semilla, luego de procesos, si no "—".
function deriveConservacion(
  cp: unknown,
  proc: ProcesoRow | null
): { label: string; detalle: string | null } {
  const perfil = (cp as { perfil?: Record<string, unknown> } | null)?.perfil
  if (perfil && typeof perfil.conserva_derechos === "boolean") {
    const fechas = perfil.fechas as { fin_conservacion_derechos?: string } | undefined
    const fin = fechas?.fin_conservacion_derechos ?? null
    const yes = perfil.conserva_derechos
    return {
      label: yes ? "Sí ✓" : "No ✗",
      detalle: fin ? `${yes ? "vence" : "venció"} ${fin}` : null,
    }
  }
  const raw = (proc?.conserva_derechos ?? "").toString().trim()
  if (raw) {
    const v = raw.toLowerCase()
    const yes = v === "true" || v === "sí" || v === "si" || v === "1"
    const fperd = (proc?.fecha_perdida_derechos ?? "").toString().trim()
    return {
      label: yes ? "Sí ✓" : "No ✗",
      detalle: fperd ? `${yes ? "vence" : "venció"} ${fperd}` : null,
    }
  }
  return { label: "—", detalle: null }
}

export default async function ClienteDetallePage({
  params,
}: {
  params: { id: string }
}) {
  const supabase = await createClient()

  if (!(await isAdvisor(supabase))) {
    redirect("/dashboard")
  }

  const { data: cliente } = await supabase
    .from("clientes")
    .select("*")
    .eq("id", params.id)
    .maybeSingle()

  if (!cliente) {
    notFound()
  }

  const { data: procesoData } = await supabase
    .from("procesos")
    .select(
      "documento_final_url, link_sisec, conserva_derechos, fecha_perdida_derechos, semanas_descontadas, semanas_recuperadas"
    )
    .eq("cliente_id", params.id)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle()

  const ultimoProceso = (procesoData ?? null) as ProcesoRow | null

  const historia = getHistoriaLaboral(cliente)
  const tieneCalculadora = parseSemillaV2(cliente.calculo_pensional) !== null

  // Oportunidades por prioridad: Mod 40 (hoy/futura) → producto Infonavit
  // (Solución hogar / Mejoravit activo / Mejoravit inactivo, de la semilla) →
  // fallback "Diagnóstico avanzado". La primera es la principal.
  const aplican: string[] = MOD40_FLAGS.filter(
    (f) => (cliente as Record<string, unknown>)[f.key] === "true"
  ).map((f) => f.label)
  const infLabel = infonavitOportunidad(cliente.calculo_pensional)
  if (infLabel) aplican.push(infLabel)
  const oportunidad = {
    principal: aplican[0] ?? "Diagnóstico avanzado",
    otras: aplican.slice(1),
    alto: aplican.length > 0,
  }

  const conservacion = deriveConservacion(cliente.calculo_pensional, ultimoProceso)

  const semSemanas = (
    cliente.calculo_pensional as {
      perfil?: { semanas?: { descontadas?: unknown; recuperadas?: unknown } }
    } | null
  )?.perfil?.semanas
  const semanasDescontadas = pickSemana(
    semSemanas?.descontadas,
    ultimoProceso?.semanas_descontadas
  )
  const semanasRecuperadas = pickSemana(
    semSemanas?.recuperadas,
    ultimoProceso?.semanas_recuperadas
  )

  const sar92Raw = (
    cliente.calculo_pensional as { saldos?: { sar92?: unknown } } | null
  )?.saldos?.sar92
  const sar92 =
    sar92Raw === null || sar92Raw === undefined ? null : String(sar92Raw)

  // Documentos: solo los que tienen valor.
  const docs = (
    [
      cliente.drive_folder_id
        ? {
            title: "Carpeta Drive",
            audience: "expediente del cliente",
            description: "Todos los documentos del cliente en Google Drive.",
            url: `${DRIVE_FOLDER_BASE}${cliente.drive_folder_id}`,
            label: "Abrir carpeta",
            mode: "open",
          }
        : null,
      cliente.link_diagnostico
        ? {
            title: "Diagnóstico básico",
            audience: "para el cliente",
            description: "Reporte conversacional en PDF, listo para compartir.",
            url: cliente.link_diagnostico,
            label: "Descargar diagnóstico básico",
            mode: "download",
          }
        : null,
      ultimoProceso?.documento_final_url
        ? {
            title: "Diagnóstico",
            audience: "documento generado",
            description: "Diagnóstico del último proceso, para ver en el visor.",
            url: ultimoProceso.documento_final_url,
            label: "Abrir diagnóstico",
            mode: "open",
          }
        : null,
      cliente.documento_diagnostico_avanzado_url
        ? {
            title: "Diagnóstico avanzado",
            audience: "para el asesor",
            description:
              "Reporte completo: escenarios por edad, estrategia, Infonavit y ahorro.",
            url: cliente.documento_diagnostico_avanzado_url,
            label: "Abrir diagnóstico avanzado",
            mode: "open",
          }
        : null,
      cliente.documento_checkup_url
        ? {
            title: "Checkup Pensional",
            audience: "para el asesor",
            description:
              "Ficha de perfilamiento con datos crudos del IMSS para preparar la conversación.",
            url: cliente.documento_checkup_url,
            label: "Abrir Checkup",
            mode: "open",
          }
        : null,
      cliente.documento_sisec_url
        ? {
            title: "Historial SISEC",
            audience: "documento oficial IMSS",
            description:
              "PDF del portal IMSS Digital con el historial laboral oficial.",
            url: cliente.documento_sisec_url,
            label: "Abrir SISEC",
            mode: "open",
          }
        : null,
      ultimoProceso?.link_sisec
        ? {
            title: "SISEC (último proceso)",
            audience: "documento oficial IMSS",
            description: "Historial SISEC asociado al último proceso.",
            url: ultimoProceso.link_sisec,
            label: "Abrir SISEC",
            mode: "open",
          }
        : null,
    ] as (DocItem | null)[]
  ).filter((d): d is DocItem => d !== null && !!d.url && d.url.trim().length > 0)

  const ficha: FichaCliente = {
    id: cliente.id,
    nombre: cliente.nombre,
    apellidos: cliente.apellidos,
    curp: cliente.curp,
    telefono: cliente.telefono,
    email: cliente.email,
    Ley_imss: cliente.Ley_imss,
    sub_estado: cliente.sub_estado,
    // Situación al corte
    ultima_fecha_sisec: cliente["última_fecha_sisec"] ?? null,
    edad: calcEdad(cliente.fecha_nacimiento),
    semanas_cotizadas: cliente.semanas_cotizadas,
    semanas_descontadas: semanasDescontadas,
    semanas_recuperadas: semanasRecuperadas,
    status_empleo: cliente.status_empleo,
    conservacionLabel: conservacion.label,
    conservacionDetalle: conservacion.detalle,
    sisec_refresh_solicitado_at: cliente.sisec_refresh_solicitado_at ?? null,
    // Datos personales
    fecha_nacimiento: cliente.fecha_nacimiento,
    edo_republica: cliente.edo_republica,
    nss: cliente.nss,
    // Fondos de retiro
    rcv97: cliente.rcv97,
    sar92,
    infonavit_estimado: cliente.infonavit_estimado,
    // Escenarios
    pension_base: cliente.pension_base,
    edad_base: cliente.edad_base,
    pension_maxima: cliente.pension_maxima,
    edad_maxima: cliente.edad_maxima,
    pensionMod40_retro_hoy: cliente.pensionMod40_retro_hoy,
    pension_mod40_futuro: cliente.pension_mod40_futuro,
  }

  return (
    <FichaClienteClient
      cliente={ficha}
      asesoriaBasica={(cliente.asesoria_basica_whatsapp ?? "").trim() || null}
      tieneCalculadora={tieneCalculadora}
      oportunidad={oportunidad}
      historia={historia}
      docs={docs}
      diagnosticoAvanzado={{
        url: cliente.documento_diagnostico_avanzado_url ?? null,
        solicitadoAt: cliente.diagnostico_avanzado_solicitado_at ?? null,
      }}
    />
  )
}
