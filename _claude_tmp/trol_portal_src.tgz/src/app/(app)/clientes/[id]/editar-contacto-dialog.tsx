"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { Pencil } from "lucide-react"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { createClient } from "@/lib/supabase/client"

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

export function EditarContactoDialog({
  clienteId,
  nombre,
  apellidos,
  email,
  telefono,
  curp,
}: {
  clienteId: string
  nombre: string | null
  apellidos: string | null
  email: string | null
  telefono: string | null
  curp: string | null
}) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    nombre: nombre ?? "",
    apellidos: apellidos ?? "",
    email: email ?? "",
    telefono: telefono ?? "",
  })

  function set(campo: keyof typeof form) {
    return (e: React.ChangeEvent<HTMLInputElement>) =>
      setForm((f) => ({ ...f, [campo]: e.target.value }))
  }

  async function guardar(e: React.FormEvent) {
    e.preventDefault()

    const nombreT = form.nombre.trim()
    const apellidosT = form.apellidos.trim()
    const emailT = form.email.trim()
    const telefonoT = form.telefono.trim()

    if (!nombreT || !apellidosT) {
      toast.error("Nombre y apellidos son obligatorios")
      return
    }
    if (emailT && !EMAIL_RE.test(emailT)) {
      toast.error("El email no tiene un formato válido")
      return
    }

    setLoading(true)
    const supabase = createClient()
    // Contrato RPC: null = no cambiar, '' = limpiar, valor = set.
    // En un form de edición mandamos lo que se ve: '' limpia el campo.
    const { data, error } = await supabase.rpc("actualizar_cliente_contacto", {
      p_cliente_id: clienteId,
      p_nombre: nombreT,
      p_apellidos: apellidosT,
      p_email: emailT,
      p_telefono: telefonoT,
    })
    if (error) {
      toast.error(error.message)
      setLoading(false)
      return
    }
    const dispatched = (data as { hubspot_dispatched?: boolean } | null)
      ?.hubspot_dispatched
    toast.success(
      dispatched
        ? "Contacto actualizado, sincronizando a HubSpot"
        : "Contacto actualizado"
    )
    setLoading(false)
    setOpen(false)
    router.refresh()
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button type="button" variant="outline" size="sm">
          <Pencil />
          Editar
        </Button>
      </DialogTrigger>
      <DialogContent>
        <form onSubmit={guardar} className="flex flex-col gap-4">
          <DialogHeader>
            <DialogTitle>Editar contacto</DialogTitle>
            <DialogDescription>
              Actualiza los datos de contacto del cliente.
            </DialogDescription>
          </DialogHeader>

          <div className="flex flex-col gap-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="contacto-nombre">Nombre</Label>
                <Input
                  id="contacto-nombre"
                  value={form.nombre}
                  onChange={set("nombre")}
                  autoComplete="off"
                  required
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="contacto-apellidos">Apellidos</Label>
                <Input
                  id="contacto-apellidos"
                  value={form.apellidos}
                  onChange={set("apellidos")}
                  autoComplete="off"
                  required
                />
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <Label htmlFor="contacto-email">Email</Label>
              <Input
                id="contacto-email"
                type="email"
                value={form.email}
                onChange={set("email")}
                autoComplete="off"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <Label htmlFor="contacto-telefono">Teléfono</Label>
              <Input
                id="contacto-telefono"
                type="tel"
                value={form.telefono}
                onChange={set("telefono")}
                autoComplete="off"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <Label htmlFor="contacto-curp">CURP</Label>
              <Input
                id="contacto-curp"
                value={curp ?? ""}
                disabled
                readOnly
                className="font-mono"
              />
              <p className="text-xs text-muted-foreground">No editable.</p>
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="ghost"
              onClick={() => setOpen(false)}
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Guardando…" : "Guardar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
