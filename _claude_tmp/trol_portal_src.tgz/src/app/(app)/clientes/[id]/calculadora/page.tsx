export const dynamic = "force-dynamic"

import type { Metadata } from "next"
import Link from "next/link"
import { notFound, redirect } from "next/navigation"

import { createClient } from "@/lib/supabase/server"
import { isAdvisor } from "@/lib/auth/roles"
import { parseSemillaV2 } from "@/lib/imss/semilla"
import {
  CalculadoraClient,
  type SaldosCorregidos,
} from "@/app/(app)/consultas/[id]/calculadora/calculadora-client"

export async function generateMetadata({
  params,
}: {
  params: { id: string }
}): Promise<Metadata> {
  const supabase = await createClient()
  const { data } = await supabase
    .from("clientes")
    .select("nombre, apellidos")
    .eq("id", params.id)
    .maybeSingle()

  const nombre = [data?.nombre, data?.apellidos]
    .filter(Boolean)
    .join(" ")
    .trim()

  return { title: nombre || "Cliente" }
}

function fmtFecha(value: unknown): string | null {
  if (!value) return null
  const raw = value.toString().trim()
  if (!raw) return null
  const d = new Date(raw)
  if (Number.isNaN(d.getTime())) return raw
  return new Intl.DateTimeFormat("es-MX", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(d)
}

export default async function ClienteCalculadoraPage({
  params,
}: {
  params: { id: string }
}) {
  const supabase = await createClient()

  if (!(await isAdvisor(supabase))) {
    redirect("/dashboard")
  }

  const { data: cliente } = await supabase
    .from("clientes")
    .select(
      'id, nombre, apellidos, curp, calculo_pensional, calculo_pensional_at, saldos_corregidos, "última_fecha_sisec", mod40_retro_hoy, mod40_retro_futuro'
    )
    .eq("id", params.id)
    .maybeSingle()

  if (!cliente) {
    notFound()
  }

  const semilla = parseSemillaV2(cliente.calculo_pensional)
  const backHref = `/clientes/${params.id}`

  if (!semilla) {
    return (
      <div className="flex flex-col gap-4 max-w-2xl">
        <Link
          href={backHref}
          className="text-sm text-muted-foreground hover:underline w-fit"
        >
          ← Volver al cliente
        </Link>
        <div className="rounded-lg border bg-muted/40 p-8 text-center flex flex-col gap-2">
          <h1 className="font-heading font-bold text-xl">
            Calculadora no disponible
          </h1>
          <p className="text-sm text-muted-foreground">
            La calculadora aún no está disponible para este cliente. Vuelve a
            procesar su SISEC para habilitarla.
          </p>
        </div>
      </div>
    )
  }

  const clienteNombre =
    [cliente.nombre, cliente.apellidos].filter(Boolean).join(" ") ||
    semilla.perfil.nombre

  // Fecha "al corte" que ve el cliente: la del reporte IMSS (fecha_sisec),
  // NO calculo_pensional_at (metadato interno de cuándo generamos el cálculo).
  const metaFechaSisec = (
    cliente.calculo_pensional as { meta?: { fecha_sisec?: unknown } } | null
  )?.meta?.fecha_sisec
  const fechaSisec =
    fmtFecha(metaFechaSisec) ?? fmtFecha(cliente["última_fecha_sisec"])
  const calculoGeneradoAt = fmtFecha(cliente.calculo_pensional_at)

  const mod40Aplica =
    cliente.mod40_retro_hoy === "true" || cliente.mod40_retro_futuro === "true"

  return (
    <CalculadoraClient
      consultaId={cliente.id}
      clienteNombre={clienteNombre}
      semilla={semilla}
      backHref={backHref}
      backLabel="← Volver al cliente"
      fechaSisec={fechaSisec}
      calculoGeneradoAt={calculoGeneradoAt}
      mod40Aplica={mod40Aplica}
      calculoPensional={cliente.calculo_pensional}
      saldosCorregidos={cliente.saldos_corregidos as SaldosCorregidos | null}
      guardarScope="cliente"
    />
  )
}
