"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { Loader2, RefreshCw } from "lucide-react"

import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"

export function ActualizarImssButton({
  clienteId,
  solicitadoAt,
}: {
  clienteId: string
  solicitadoAt: string | null
}) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const enProceso = solicitadoAt != null

  async function actualizar() {
    setLoading(true)
    const supabase = createClient()
    const { error } = await supabase.rpc("actualizar_sisec_cliente", {
      p_cliente_id: clienteId,
    })
    if (error) {
      toast.error(error.message)
      setLoading(false)
      return
    }
    toast.success("Consulta SISEC en proceso")
    router.refresh()
  }

  if (enProceso) {
    return (
      <div className="flex flex-col gap-1.5">
        <Button type="button" size="sm" variant="outline" disabled>
          <Loader2 className="animate-spin" />
          Actualizando…
        </Button>
        <p className="text-xs text-muted-foreground">
          Actualizando datos del IMSS… (unos minutos, recarga la página)
        </p>
      </div>
    )
  }

  return (
    <Button
      type="button"
      size="sm"
      variant="outline"
      onClick={actualizar}
      disabled={loading}
    >
      <RefreshCw />
      {loading ? "Solicitando…" : "Actualizar datos IMSS"}
    </Button>
  )
}
