"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { Loader2, RefreshCw, Sparkles } from "lucide-react"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { SectionTitle } from "@/components/ficha/pension-ui"
import { createClient } from "@/lib/supabase/client"

const SIN_SEMILLA_HINT = "Requiere SISEC/cálculo actualizado"

export function DiagnosticoAvanzadoCard({
  clienteId,
  url,
  solicitadoAt,
  tieneSemilla,
}: {
  clienteId: string
  url: string | null
  solicitadoAt: string | null
  tieneSemilla: boolean
}) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)

  // Un trigger en `clientes` limpia `diagnostico_avanzado_solicitado_at` cuando
  // n8n escribe la URL, así que "solicitado pendiente" equivale a que la
  // solicitud sea más reciente que el documento (o que no haya documento).
  const generando = solicitadoAt != null
  const listo = url != null && !generando

  async function solicitar() {
    setLoading(true)
    const supabase = createClient()
    const { error } = await supabase.rpc("solicitar_diagnostico_cliente", {
      p_cliente_id: clienteId,
    })

    if (error) {
      if (error.code === "42501") {
        toast.error("No tienes permiso")
      } else if (error.code === "P0001") {
        toast.error(SIN_SEMILLA_HINT)
      } else if (error.code === "P0002") {
        toast.error("Cliente no encontrado")
      } else {
        toast.error(error.message)
      }
      setLoading(false)
      return
    }

    toast.success("Generando, llegará en unos minutos")
    setLoading(false)
    setOpen(false)
    router.refresh()
  }

  return (
    <Card>
      <CardHeader>
        <SectionTitle>Diagnóstico avanzado</SectionTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex items-start gap-3">
          <div className="rounded-full bg-lime-400/15 p-3">
            <Sparkles className="size-5 text-lime-700 dark:text-lime-300" />
          </div>
          <p className="text-sm text-muted-foreground">
            Reporte completo en PDF: escenarios por edad, estrategia, Infonavit y
            ahorro. Uso interno, sin costo.
          </p>
        </div>

        {!tieneSemilla ? (
          /* Sin semilla v2 → botón deshabilitado con el motivo. */
          <div className="flex flex-col items-start gap-1.5">
            <Button type="button" disabled>
              <Sparkles />
              Generar diagnóstico avanzado
            </Button>
            <p className="text-xs text-muted-foreground">{SIN_SEMILLA_HINT}</p>
          </div>
        ) : generando ? (
          <div className="flex flex-col items-start gap-1.5">
            <Button type="button" disabled>
              <Loader2 className="animate-spin" />
              Generando…
            </Button>
            <p className="text-xs text-muted-foreground">
              Llega en unos minutos; recarga la página para verlo.
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-start gap-1.5">
            <Button type="button" onClick={() => setOpen(true)}>
              {listo ? <RefreshCw /> : <Sparkles />}
              {listo ? "Regenerar" : "Generar diagnóstico avanzado"}
            </Button>
            {listo && (
              <p className="text-xs text-muted-foreground">
                El documento está listo abajo, en Documentos del cliente.
              </p>
            )}
          </div>
        )}
      </CardContent>

      <Dialog open={open} onOpenChange={(next) => !loading && setOpen(next)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {listo ? "Regenerar diagnóstico avanzado" : "Generar diagnóstico avanzado"}
            </DialogTitle>
            <DialogDescription>
              Se generará el reporte completo con la información más reciente del
              cliente. Tarda unos minutos y llega solo.
              {listo && " El documento actual será reemplazado."}
            </DialogDescription>
          </DialogHeader>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button type="button" onClick={solicitar} disabled={loading}>
              {loading ? "Solicitando…" : listo ? "Regenerar" : "Generar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}
