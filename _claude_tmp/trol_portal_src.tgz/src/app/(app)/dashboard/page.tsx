export const dynamic = "force-dynamic"

import Link from "next/link"
import { redirect } from "next/navigation"

import { createClient } from "@/lib/supabase/server"
import { isAdvisor } from "@/lib/auth/roles"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Dashboard",
  description: "Resumen de tu actividad, saldo y consultas recientes.",
}

export default async function DashboardPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: partner } = await supabase
    .from("partners")
    .select("*")
    .eq("auth_user_id", user.id)
    .maybeSingle()

  // Asesores "puros" (sin partner) aterrizan en su home: /clientes. Admin es
  // partner + admin, así que conserva el dashboard.
  if (!partner) {
    if (await isAdvisor(supabase)) {
      redirect("/clientes")
    }
    redirect("/login")
  }

  if (partner.portal_status === "pending_onboarding") {
    redirect("/onboarding")
  }

  const displayName = partner.business_name || user.email || "aliado"
  const balance = Number(partner.balance_credits ?? 0)
  const approxMxn = balance * 20

  const monthStart = new Date()
  monthStart.setDate(1)
  monthStart.setHours(0, 0, 0, 0)

  const { count: consultasEsteMes } = await supabase
    .from("partner_transactions")
    .select("id", { count: "exact", head: true })
    .eq("partner_id", partner.id)
    .gte("created_at", monthStart.toISOString())

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-medium">Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Bienvenido, {displayName}
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader>
            <CardTitle>Saldo de créditos</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{balance} créditos</p>
            <p className="text-xs text-muted-foreground mt-1">
              ≈ ${approxMxn.toLocaleString("es-MX")} MXN al precio base
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Consultas este mes</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{consultasEsteMes ?? 0}</p>
            <p className="text-xs text-muted-foreground mt-1">
              Cuando crees consultas, aparecerán aquí
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Última consulta</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Ninguna todavía
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Próxima entrega</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Sin consultas en proceso
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col gap-4 mt-2">
        <p className="text-sm text-muted-foreground max-w-prose">
          Aquí verás tus consultas, podrás crear nuevas y dar seguimiento a las
          que estén en proceso. En las próximas semanas iremos habilitando más
          funcionalidad.
        </p>

        <div>
          <Button asChild size="lg">
            <Link href="/consultas/nueva">+ Nueva consulta</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
