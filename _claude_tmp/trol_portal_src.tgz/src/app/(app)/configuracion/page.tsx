import { redirect } from "next/navigation"

import { createClient } from "@/lib/supabase/server"
import { isAdvisor } from "@/lib/auth/roles"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { CambiarPasswordForm } from "./cambiar-password-form"
import { OrganizacionForm } from "./organizacion-form"
import { BrandingForm } from "./branding-form"

import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Configuración",
  description: "Datos de tu cuenta, seguridad y organización.",
}

export const dynamic = "force-dynamic"

const ROLE_LABEL: Record<string, string> = {
  admin: "Administrador",
  asesor: "Asesor",
  aliado: "Aliado",
}

type BrandingJson = {
  color_primario?: unknown
  color_acento?: unknown
  logo_url?: unknown
}

function readBranding(raw: unknown) {
  const b = (raw && typeof raw === "object" ? raw : {}) as BrandingJson
  return {
    colorPrimario: typeof b.color_primario === "string" ? b.color_primario : null,
    colorAcento: typeof b.color_acento === "string" ? b.color_acento : null,
    logoUrl: typeof b.logo_url === "string" ? b.logo_url : null,
  }
}

export default async function ConfiguracionPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) redirect("/login")

  // El usuario es aliado si tiene fila en `partners` ligada a su auth_user_id.
  const { data: partner } = await supabase
    .from("partners")
    .select(
      "id, name, business_name, contact_name, contact_email, balance_credits, branding, is_admin",
    )
    .eq("auth_user_id", user.id)
    .maybeSingle()

  const advisor = await isAdvisor(supabase)

  // admin > asesor > aliado (los admins son asesores implícitos).
  let role: "admin" | "asesor" | "aliado" = "aliado"
  if (partner?.is_admin) {
    role = "admin"
  } else if (advisor) {
    role = "asesor"
  }

  // Solo aliados (no admin, no asesor) ven organización y branding.
  const esAliado = role === "aliado" && !!partner

  // Nombre a mostrar: para asesores viene de su fila en `asesores`.
  let nombre =
    partner?.business_name || partner?.name || partner?.contact_name || null
  if (!nombre && advisor) {
    const { data: asesor } = await supabase
      .from("asesores")
      .select("nombre")
      .eq("auth_user_id", user.id)
      .maybeSingle()
    nombre = asesor?.nombre ?? null
  }

  const email = user.email ?? "—"
  const branding = readBranding(partner?.branding ?? null)

  return (
    <div className="w-full max-w-[720px] mx-auto px-4 py-6 flex flex-col gap-6">
      <div className="border-l-4 border-[#a3e635] pl-4">
        <h1 className="font-heading text-2xl font-bold text-[#0f172a]">
          Configuración
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Datos de tu cuenta, seguridad{esAliado ? " y tu organización" : ""}.
        </p>
      </div>

      {/* 1) Mi cuenta */}
      <Card>
        <CardHeader>
          <CardTitle>Mi cuenta</CardTitle>
          <CardDescription>
            Información asociada a tu sesión actual.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-[120px_1fr] gap-x-4 gap-y-3 text-sm">
            <span className="text-muted-foreground">Nombre</span>
            <span className="font-medium break-words">{nombre ?? "—"}</span>

            <span className="text-muted-foreground">Correo</span>
            <span className="font-medium break-all">{email}</span>

            <span className="text-muted-foreground">Rol</span>
            <span>
              <span className="inline-flex items-center rounded-full bg-[#0f172a] text-[#a3e635] px-3 py-0.5 text-xs font-semibold tracking-wide">
                {ROLE_LABEL[role]}
              </span>
            </span>
          </div>
        </CardContent>
      </Card>

      {/* 2) Cambiar contraseña */}
      <Card>
        <CardHeader>
          <CardTitle>Cambiar contraseña</CardTitle>
          <CardDescription>
            Elige una nueva contraseña de al menos 8 caracteres.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <CambiarPasswordForm />
        </CardContent>
      </Card>

      {/* 3) Datos de la organización (solo aliados) */}
      {esAliado && partner && (
        <Card>
          <CardHeader>
            <CardTitle>Datos de la organización</CardTitle>
            <CardDescription>
              Información de tu cuenta de aliado en el portal.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <OrganizacionForm
              partnerId={partner.id}
              name={partner.business_name || partner.name || "—"}
              contactEmail={partner.contact_email ?? ""}
              balanceCredits={Number(partner.balance_credits ?? 0)}
            />
          </CardContent>
        </Card>
      )}

      {/* 4) Branding del aliado (solo aliados) */}
      {esAliado && partner && (
        <Card>
          <CardHeader>
            <CardTitle>Branding</CardTitle>
            <CardDescription>
              Personaliza los colores y el logo que ven tus clientes en la
              calculadora.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <BrandingForm
              partnerId={partner.id}
              initialPrimario={branding.colorPrimario}
              initialAcento={branding.colorAcento}
              initialLogoUrl={branding.logoUrl}
            />
          </CardContent>
        </Card>
      )}
    </div>
  )
}
