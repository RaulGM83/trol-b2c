"use client"

import { useState } from "react"
import { toast } from "sonner"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

// Paleta Trol por defecto: navy + lima.
const DEFAULT_PRIMARIO = "#0f172a"
const DEFAULT_ACENTO = "#a3e635"

const HEX_RE = /^#[0-9a-fA-F]{6}$/

export function BrandingForm({
  partnerId,
  initialPrimario,
  initialAcento,
  initialLogoUrl,
}: {
  partnerId: string
  initialPrimario: string | null
  initialAcento: string | null
  initialLogoUrl: string | null
}) {
  const [primario, setPrimario] = useState(initialPrimario ?? DEFAULT_PRIMARIO)
  const [acento, setAcento] = useState(initialAcento ?? DEFAULT_ACENTO)
  const [logoUrl, setLogoUrl] = useState(initialLogoUrl ?? "")
  const [saving, setSaving] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (saving) return

    if (!HEX_RE.test(primario) || !HEX_RE.test(acento)) {
      toast.error("Los colores deben ser hex de 6 dígitos (ej. #0f172a).")
      return
    }
    const logo = logoUrl.trim()
    if (logo && !logo.startsWith("https://")) {
      toast.error("La URL del logo debe iniciar con https://")
      return
    }

    setSaving(true)
    const supabase = createClient()
    const { error } = await supabase
      .from("partners")
      .update({
        branding: {
          color_primario: primario,
          color_acento: acento,
          logo_url: logo || null,
        },
      })
      .eq("id", partnerId)
    setSaving(false)

    if (error) {
      toast.error(error.message)
      return
    }
    toast.success("Branding guardado.")
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6">
      <div className="grid gap-5 sm:grid-cols-2">
        <ColorField
          id="color-primario"
          label="Color primario"
          value={primario}
          onChange={setPrimario}
        />
        <ColorField
          id="color-acento"
          label="Color de acento"
          value={acento}
          onChange={setAcento}
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <Label htmlFor="logo-url">Logo (URL)</Label>
        <Input
          id="logo-url"
          type="url"
          value={logoUrl}
          onChange={(e) => setLogoUrl(e.target.value)}
          placeholder="https://…/logo.png"
        />
        <p className="text-xs text-muted-foreground">
          Por ahora una URL pública (https). La subida de archivo llegará después.
        </p>
      </div>

      {/* Vista previa */}
      <div className="flex flex-col gap-2">
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          Vista previa
        </span>
        <div
          className="rounded-lg border overflow-hidden"
          style={{ backgroundColor: HEX_RE.test(primario) ? primario : DEFAULT_PRIMARIO }}
        >
          <div className="flex items-center justify-between gap-3 px-5 py-4">
            <div className="flex items-center gap-3">
              {logoUrl.trim() ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={logoUrl.trim()}
                  alt="Logo"
                  className="h-8 w-auto object-contain"
                />
              ) : null}
              <span className="font-heading font-bold text-white text-lg">
                Calculadora de pensión
              </span>
            </div>
            <span
              className="rounded-full px-3 py-1 text-xs font-semibold"
              style={{
                backgroundColor: HEX_RE.test(acento) ? acento : DEFAULT_ACENTO,
                color: HEX_RE.test(primario) ? primario : DEFAULT_PRIMARIO,
              }}
            >
              Perfil: Ley 73
            </span>
          </div>
        </div>
      </div>

      <Button type="submit" disabled={saving} className="w-fit">
        {saving ? "Guardando…" : "Guardar branding"}
      </Button>
    </form>
  )
}

function ColorField({
  id,
  label,
  value,
  onChange,
}: {
  id: string
  label: string
  value: string
  onChange: (v: string) => void
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={id}>{label}</Label>
      <div className="flex items-center gap-2">
        <input
          aria-label={`${label} (selector)`}
          type="color"
          value={HEX_RE.test(value) ? value : "#000000"}
          onChange={(e) => onChange(e.target.value)}
          className="h-9 w-12 shrink-0 cursor-pointer rounded-md border bg-background p-1"
        />
        <Input
          id={id}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="#000000"
          className="font-mono"
        />
      </div>
    </div>
  )
}
