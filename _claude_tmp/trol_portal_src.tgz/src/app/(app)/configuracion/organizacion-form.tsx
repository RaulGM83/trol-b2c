"use client"

import { useState } from "react"
import Link from "next/link"
import { toast } from "sonner"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export function OrganizacionForm({
  partnerId,
  name,
  contactEmail,
  balanceCredits,
}: {
  partnerId: string
  name: string
  contactEmail: string
  balanceCredits: number
}) {
  const [email, setEmail] = useState(contactEmail)
  const [saving, setSaving] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (saving) return

    const value = email.trim()
    if (value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      toast.error("El correo de contacto no es válido.")
      return
    }

    setSaving(true)
    const supabase = createClient()
    const { error } = await supabase
      .from("partners")
      .update({ contact_email: value || null })
      .eq("id", partnerId)
    setSaving(false)

    if (error) {
      toast.error(error.message)
      return
    }
    toast.success("Datos de la organización guardados.")
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-5">
      <div className="grid grid-cols-[140px_1fr] gap-x-4 gap-y-1 items-center text-sm">
        <span className="text-muted-foreground">Organización</span>
        <span className="font-medium">{name}</span>

        <span className="text-muted-foreground">Saldo de créditos</span>
        <span className="flex items-center gap-2">
          <span className="font-semibold tabular-nums">
            {balanceCredits.toLocaleString("es-MX")} créditos
          </span>
          <Link
            href="/saldo"
            className="text-[#0f172a] underline decoration-[#a3e635] decoration-2 underline-offset-2 hover:opacity-80"
          >
            Ver saldo
          </Link>
        </span>
      </div>

      <div className="flex flex-col gap-1.5 max-w-sm">
        <Label htmlFor="contact-email">Correo de contacto</Label>
        <Input
          id="contact-email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="contacto@tu-organizacion.mx"
        />
        <p className="text-xs text-muted-foreground">
          Usamos este correo para notificaciones y avisos de saldo.
        </p>
      </div>

      <Button type="submit" disabled={saving} className="w-fit">
        {saving ? "Guardando…" : "Guardar cambios"}
      </Button>
    </form>
  )
}
