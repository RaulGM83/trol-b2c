export const dynamic = "force-dynamic"

import { redirect } from "next/navigation"
import Link from "next/link"

import { createClient } from "@/lib/supabase/server"
import { isAdvisor } from "@/lib/auth/roles"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Ruteo de oportunidades",
  description: "Producto estrella por cliente, ordenado por prioridad.",
}

const PAGE_SIZE = 50

const PRODUCTOS: { code: string; label: string; tono: string }[] = [
  { code: "MODALIDAD_40", label: "Modalidad 40", tono: "bg-lime-400 text-slate-900" },
  { code: "GESTORIA_INFONAVIT", label: "Gestoría Infonavit", tono: "bg-lime-400/20 text-lime-700 dark:text-lime-300" },
  { code: "GESTORIA_IMSS", label: "Gestoría IMSS", tono: "bg-muted text-foreground" },
  { code: "PPR", label: "PPR · Ley 97", tono: "bg-muted text-muted-foreground" },
  { code: "ASESORIA", label: "Asesoría", tono: "bg-muted text-muted-foreground" },
]
const PRODUCTO_MAP = Object.fromEntries(PRODUCTOS.map((p) => [p.code, p]))

type RuteoRow = {
  cliente_id: string
  nombre: string | null
  apellidos: string | null
  ley: string | null
  semanas: number | null
  pension_base: string | null
  pension_maxima: string | null
  pension_mod40: string | null
  prioridad: number | null
  producto_estrella: string
  motivo: string | null
}

function dash(v: string | null | undefined) {
  const s = (v ?? "").toString().trim()
  return s.length ? s : "—"
}

export default async function RuteoPage({
  searchParams,
}: {
  searchParams: { p?: string; page?: string }
}) {
  const supabase = await createClient()
  if (!(await isAdvisor(supabase))) redirect("/dashboard")

  const producto = searchParams.p && PRODUCTO_MAP[searchParams.p] ? searchParams.p : ""
  const page = Math.max(0, parseInt(searchParams.page ?? "0", 10) || 0)
  const from = page * PAGE_SIZE
  const to = from + PAGE_SIZE - 1

  // Conteos por producto (chips de filtro).
  const counts: Record<string, number> = {}
  await Promise.all(
    PRODUCTOS.map(async (p) => {
      const { count } = await supabase
        .from("vista_ruteo")
        .select("cliente_id", { count: "exact", head: true })
        .eq("producto_estrella", p.code)
      counts[p.code] = count ?? 0
    }),
  )

  let query = supabase
    .from("vista_ruteo")
    .select(
      "cliente_id, nombre, apellidos, ley, semanas, pension_base, pension_maxima, pension_mod40, prioridad, producto_estrella, motivo",
      { count: "exact" },
    )
    .order("prioridad", { ascending: false, nullsFirst: false })
    .range(from, to)
  if (producto) query = query.eq("producto_estrella", producto)

  const { data, count } = await query
  const rows = (data ?? []) as RuteoRow[]
  const total = count ?? 0
  const hasPrev = page > 0
  const hasNext = from + rows.length < total

  const chipHref = (code: string) => (code ? `/ruteo?p=${code}` : "/ruteo")
  const pageHref = (p: number) => {
    const params = new URLSearchParams()
    if (producto) params.set("p", producto)
    if (p > 0) params.set("page", String(p))
    const qs = params.toString()
    return qs ? `/ruteo?${qs}` : "/ruteo"
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-medium flex items-center gap-2 text-slate-900 dark:text-slate-100">
          <span className="inline-block h-6 w-1 rounded-full bg-lime-400" />
          Ruteo de oportunidades
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Producto estrella por cliente según su perfil. Ordenado por prioridad (puntaje).
        </p>
      </div>

      {/* Chips de filtro por producto, con conteos */}
      <div className="flex flex-wrap gap-2">
        <Link
          href={chipHref("")}
          className={`rounded-full border px-3 py-1.5 text-sm font-medium ${producto === "" ? "border-lime-400 bg-lime-400/20" : "border-border"}`}
        >
          Todos
        </Link>
        {PRODUCTOS.map((p) => (
          <Link
            key={p.code}
            href={chipHref(p.code)}
            className={`rounded-full border px-3 py-1.5 text-sm font-medium ${producto === p.code ? "border-lime-400 bg-lime-400/20" : "border-border"}`}
          >
            {p.label}{" "}
            <span className="text-muted-foreground">· {counts[p.code]?.toLocaleString("es-MX") ?? 0}</span>
          </Link>
        ))}
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="px-4 py-3 font-medium">Cliente</th>
                  <th className="px-4 py-3 font-medium">Régimen</th>
                  <th className="px-4 py-3 font-medium text-right">Semanas</th>
                  <th className="px-4 py-3 font-medium">Producto estrella</th>
                  <th className="px-4 py-3 font-medium">Por qué</th>
                  <th className="px-4 py-3 font-medium text-right">Prioridad</th>
                </tr>
              </thead>
              <tbody>
                {rows.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">
                      Sin clientes para este filtro.
                    </td>
                  </tr>
                )}
                {rows.map((r) => {
                  const prod = PRODUCTO_MAP[r.producto_estrella]
                  return (
                    <tr key={r.cliente_id} className="border-b last:border-0 hover:bg-muted/40">
                      <td className="px-4 py-3">
                        <Link href={`/clientes/${r.cliente_id}`} className="font-medium hover:underline">
                          {dash([r.nombre, r.apellidos].filter(Boolean).join(" "))}
                        </Link>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{dash(r.ley)}</td>
                      <td className="px-4 py-3 text-right">{r.semanas?.toLocaleString("es-MX") ?? "—"}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-block rounded-full px-2.5 py-1 text-xs font-semibold ${prod?.tono ?? "bg-muted"}`}>
                          {prod?.label ?? r.producto_estrella}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground max-w-[24rem]">{dash(r.motivo)}</td>
                      <td className="px-4 py-3 text-right font-medium">{r.prioridad ?? "—"}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">
          {total.toLocaleString("es-MX")} clientes{producto ? ` · ${PRODUCTO_MAP[producto]?.label}` : ""}
        </span>
        <div className="flex gap-2">
          <Button asChild variant="outline" size="sm" disabled={!hasPrev}>
            <Link href={pageHref(page - 1)}>Anterior</Link>
          </Button>
          <Button asChild variant="outline" size="sm" disabled={!hasNext}>
            <Link href={pageHref(page + 1)}>Siguiente</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
