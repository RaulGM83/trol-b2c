export const dynamic = "force-dynamic"

import { redirect } from "next/navigation"
import Link from "next/link"
import { ReceiptText } from "lucide-react"

import { createClient } from "@/lib/supabase/server"
import { Separator } from "@/components/ui/separator"
import { Card, CardContent } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

import { SaldoHero } from "./saldo-hero"

import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Saldo",
  description: "Créditos disponibles y movimientos de tu cuenta.",
}

type WalletTxType = "topup" | "charge" | "refund" | "adjustment"

type WalletTransactionRow = {
  id: string
  created_at: string
  type: WalletTxType | string | null
  credits_delta: number | null
  balance_credits_after: number | null
  notes: string | null
  related_transaction_id: string | null
  mxn_paid_cents: number | null
  spei_reference: string | null
}

function formatFechaHora(iso: string) {
  const d = new Date(iso)
  const datePart = new Intl.DateTimeFormat("es-MX", {
    day: "numeric",
    month: "short",
    year: "numeric",
  })
    .format(d)
    .replace(/\./g, "")
  const timePart = new Intl.DateTimeFormat("es-MX", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(d)
  return `${datePart} ${timePart}`
}

function tipoBadge(type: WalletTransactionRow["type"]) {
  const map: Record<string, { label: string; cls: string }> = {
    topup: {
      label: "Recarga",
      cls: "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300",
    },
    charge: {
      label: "Cobro",
      cls: "bg-muted text-muted-foreground",
    },
    refund: {
      label: "Reembolso",
      cls: "bg-sky-100 text-sky-800 dark:bg-sky-500/15 dark:text-sky-300",
    },
    adjustment: {
      label: "Ajuste",
      cls: "bg-violet-100 text-violet-800 dark:bg-violet-500/15 dark:text-violet-300",
    },
  }
  const key = typeof type === "string" ? type : ""
  const entry = map[key]
  const label = entry?.label ?? key ?? "—"
  const cls = entry?.cls ?? "bg-muted text-muted-foreground"
  return (
    <span
      className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${cls}`}
    >
      {label}
    </span>
  )
}

function formatDelta(delta: number | null) {
  if (delta == null) return { text: "—", positive: false, zero: true }
  if (delta > 0) return { text: `+${delta}`, positive: true, zero: false }
  if (delta < 0) return { text: `${delta}`, positive: false, zero: false }
  return { text: "0", positive: false, zero: true }
}

function formatMxn(cents: number | null) {
  if (cents == null) return null
  const mxn = cents / 100
  return mxn.toLocaleString("es-MX", {
    style: "currency",
    currency: "MXN",
    minimumFractionDigits: mxn % 1 === 0 ? 0 : 2,
  })
}

export default async function SaldoPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: partner } = await supabase
    .from("partners")
    .select("id, balance_credits")
    .eq("auth_user_id", user.id)
    .single()

  if (!partner) {
    redirect("/login")
  }

  const { data: transactions } = await supabase
    .from("wallet_transactions")
    .select(
      "id, created_at, type, credits_delta, balance_credits_after, notes, related_transaction_id, mxn_paid_cents, spei_reference"
    )
    .eq("partner_id", partner.id)
    .order("created_at", { ascending: false })
    .limit(100)

  const rows = (transactions ?? []) as WalletTransactionRow[]
  const isEmpty = rows.length === 0

  return (
    <div className="max-w-[1080px] mx-auto px-4 py-6 flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-medium">Saldo</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Tu saldo de créditos y movimientos recientes
        </p>
      </div>

      <SaldoHero
        balance={partner.balance_credits ?? 0}
        partnerId={partner.id}
        clabe="012180001233553309"
        cuenta="0123355330"
        banco="BBVA"
        beneficiario="Trol Financiero"
        contactEmail="raul@trol.mx"
      />

      <Separator />

      <div className="flex flex-col gap-4">
        <h2 className="font-heading text-lg font-medium">
          Histórico de movimientos
        </h2>

        {isEmpty ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center text-center py-16 gap-4">
              <div className="rounded-full bg-muted p-4">
                <ReceiptText className="size-8 text-muted-foreground" />
              </div>
              <div className="flex flex-col gap-1">
                <h3 className="font-heading text-lg font-medium">
                  Sin movimientos todavía
                </h3>
                <p className="text-sm text-muted-foreground">
                  Cuando hagas tu primera consulta o recarga, los movimientos
                  aparecerán aquí
                </p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="px-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Cambio</TableHead>
                    <TableHead>Saldo después</TableHead>
                    <TableHead>Concepto</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((row) => {
                    const delta = formatDelta(row.credits_delta)
                    const mxn = formatMxn(row.mxn_paid_cents)
                    const deltaCls = delta.positive
                      ? "text-emerald-700 dark:text-emerald-400 font-medium"
                      : delta.zero
                      ? "text-muted-foreground"
                      : "text-muted-foreground font-medium"
                    return (
                      <TableRow key={row.id}>
                        <TableCell className="whitespace-nowrap text-muted-foreground">
                          {formatFechaHora(row.created_at)}
                        </TableCell>
                        <TableCell>{tipoBadge(row.type)}</TableCell>
                        <TableCell>
                          <div className={deltaCls}>{delta.text}</div>
                          {mxn && (
                            <div className="text-xs text-muted-foreground">
                              ({mxn} MXN)
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          {row.balance_credits_after ?? 0} créditos
                        </TableCell>
                        <TableCell className="whitespace-normal">
                          {row.notes ? (
                            <div className="text-sm">{row.notes}</div>
                          ) : (
                            <div className="text-sm text-muted-foreground">
                              —
                            </div>
                          )}
                          {row.related_transaction_id && (
                            <Link
                              href={`/consultas/${row.related_transaction_id}`}
                              className="text-xs text-primary hover:underline"
                            >
                              Ver consulta →
                            </Link>
                          )}
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
