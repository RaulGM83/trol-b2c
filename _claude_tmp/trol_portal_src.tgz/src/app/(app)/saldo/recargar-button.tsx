"use client"

import { useState } from "react"
import { toast } from "sonner"
import { Copy } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

type RecargarButtonProps = {
  partnerId: string
  clabe: string
  cuenta: string
  banco: string
  beneficiario: string
  contactEmail: string
}

export function RecargarButton({
  partnerId,
  clabe,
  cuenta,
  banco,
  beneficiario,
  contactEmail,
}: RecargarButtonProps) {
  const [open, setOpen] = useState(false)
  const reference = `TROL-${partnerId.slice(0, 8).toUpperCase()}`

  const handleCopy = async (value: string, label: string) => {
    try {
      await navigator.clipboard.writeText(value)
      toast.success(`${label} copiado`)
    } catch {
      toast.error("No pudimos copiar al portapapeles")
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg">Recargar saldo</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[520px]">
        <DialogHeader>
          <DialogTitle>Recarga vía SPEI</DialogTitle>
          <DialogDescription>
            Transfiere desde tu banco a la cuenta de El Trol. Una vez recibido,
            aplicamos tu saldo en &lt;24h hábiles.
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <span className="text-sm font-medium">Datos del depósito</span>
            <div className="flex flex-col gap-2 rounded-lg border p-4">
              <Row label="Banco" value={banco} />
              <Row label="Beneficiario" value={beneficiario} />
              <Row
                label="Cuenta"
                value={cuenta}
                mono
                onCopy={() => handleCopy(cuenta, "Cuenta")}
              />
              <Row
                label="CLABE"
                value={clabe}
                mono
                onCopy={() => handleCopy(clabe, "CLABE")}
              />
              <div className="flex flex-col gap-1 pt-1">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-sm text-muted-foreground">
                    Tu referencia
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-muted px-2 py-1 font-mono text-sm font-medium">
                      {reference}
                    </span>
                    <Button
                      variant="ghost"
                      className="h-8 w-8 p-0"
                      onClick={() => handleCopy(reference, "Referencia")}
                      aria-label="Copiar referencia"
                    >
                      <Copy />
                    </Button>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">
                  Incluye esta referencia para identificar tu depósito
                </span>
              </div>
            </div>
          </div>

          <Separator />

          <div className="flex flex-col gap-3">
            <span className="text-sm font-medium">Después del depósito</span>
            <p className="text-sm text-muted-foreground">
              Envía tu comprobante de SPEI a{" "}
              <span className="font-medium text-foreground">
                {contactEmail}
              </span>{" "}
              indicando tu referencia. Acreditamos tu saldo en menos de 24 horas
              hábiles.
            </p>
            <Button
              variant="outline"
              size="sm"
              className="self-start"
              onClick={() => handleCopy(contactEmail, "Correo de contacto")}
            >
              Copiar correo de contacto
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function Row({
  label,
  value,
  mono = false,
  onCopy,
}: {
  label: string
  value: string
  mono?: boolean
  onCopy?: () => void
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-sm text-muted-foreground">{label}</span>
      <div className="flex items-center gap-2">
        <span
          className={`text-sm font-medium ${mono ? "font-mono" : ""}`}
        >
          {value}
        </span>
        {onCopy && (
          <Button
            variant="ghost"
            className="h-8 w-8 p-0"
            onClick={onCopy}
            aria-label={`Copiar ${label.toLowerCase()}`}
          >
            <Copy />
          </Button>
        )}
      </div>
    </div>
  )
}
