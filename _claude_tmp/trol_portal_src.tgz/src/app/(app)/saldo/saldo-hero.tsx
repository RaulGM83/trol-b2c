"use client"

import { Card, CardContent } from "@/components/ui/card"

import { RecargarButton } from "./recargar-button"

type SaldoHeroProps = {
  balance: number
  partnerId: string
  clabe: string
  cuenta: string
  banco: string
  beneficiario: string
  contactEmail: string
}

export function SaldoHero({
  balance,
  partnerId,
  clabe,
  cuenta,
  banco,
  beneficiario,
  contactEmail,
}: SaldoHeroProps) {
  const mxnEquivalente = (balance * 20).toLocaleString("es-MX")

  return (
    <Card>
      <CardContent className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 p-8">
        <div className="flex flex-col gap-1">
          <span className="text-sm text-muted-foreground">Saldo actual</span>
          <div className="text-5xl font-bold tracking-tight">
            {balance} créditos
          </div>
          <span className="text-sm text-muted-foreground">
            ≈ ${mxnEquivalente} MXN al precio base
          </span>
        </div>

        <div className="flex-shrink-0">
          <RecargarButton
            partnerId={partnerId}
            clabe={clabe}
            cuenta={cuenta}
            banco={banco}
            beneficiario={beneficiario}
            contactEmail={contactEmail}
          />
        </div>
      </CardContent>
    </Card>
  )
}
