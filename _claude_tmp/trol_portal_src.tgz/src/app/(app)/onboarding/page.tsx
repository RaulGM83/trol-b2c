import { redirect } from "next/navigation"

import { createClient } from "@/lib/supabase/server"
import { isAdvisor } from "@/lib/auth/roles"
import { OnboardingForm } from "./onboarding-form"

import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Onboarding",
  description: "Completa los datos de tu organización para empezar.",
}

export default async function OnboardingPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: partner } = await supabase
    .from("partners")
    .select("*")
    .eq("auth_user_id", user.id)
    .maybeSingle()

  // El onboarding es solo para aliados. Asesores "puros" (sin partner) van a su
  // home; quien no es ni aliado ni asesor, a login.
  if (!partner) {
    if (await isAdvisor(supabase)) {
      redirect("/clientes")
    }
    redirect("/login")
  }

  if (partner.portal_status === "active") {
    redirect("/dashboard")
  }

  return (
    <OnboardingForm
      userId={user.id}
      defaults={{
        business_name: partner.business_name ?? "",
        rfc: partner.rfc ?? "",
        contact_name: partner.contact_name ?? "",
        phone: partner.phone ?? "",
      }}
    />
  )
}
