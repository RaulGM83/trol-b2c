"use client"

import { useRouter } from "next/navigation"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { toast } from "sonner"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const onboardingSchema = z.object({
  business_name: z.string().min(2, "Mínimo 2 caracteres"),
  rfc: z
    .string()
    .transform((v) => v.toUpperCase().trim())
    .pipe(
      z
        .string()
        .regex(
          /^[A-ZÑ&]{3,4}\d{6}[A-V1-9][A-Z1-9][\dA-Z]$/,
          "RFC inválido"
        )
    ),
  contact_name: z.string().min(2, "Mínimo 2 caracteres"),
  phone: z
    .string()
    .min(10, "Debe tener al menos 10 dígitos")
    .regex(/^\d+$/, "Solo dígitos"),
})

type OnboardingValues = z.infer<typeof onboardingSchema>

type Props = {
  userId: string
  defaults: {
    business_name: string
    rfc: string
    contact_name: string
    phone: string
  }
}

export function OnboardingForm({ userId, defaults }: Props) {
  const router = useRouter()
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<OnboardingValues>({
    resolver: zodResolver(onboardingSchema),
    defaultValues: defaults,
  })

  const onSubmit = async (values: OnboardingValues) => {
    const supabase = createClient()
    const { error } = await supabase
      .from("partners")
      .update({
        business_name: values.business_name,
        rfc: values.rfc,
        contact_name: values.contact_name,
        phone: values.phone,
        portal_status: "active",
      })
      .eq("auth_user_id", userId)

    if (error) {
      toast.error(error.message)
      return
    }

    toast.success("Información guardada")
    router.push("/dashboard")
    router.refresh()
  }

  return (
    <div className="flex justify-center">
      <Card className="w-full max-w-[520px]">
        <CardHeader>
          <CardTitle>Completa tu información</CardTitle>
          <CardDescription>
            Necesitamos algunos datos antes de que empieces a operar
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form
            onSubmit={handleSubmit(onSubmit)}
            className="flex flex-col gap-4"
          >
            <div className="flex flex-col gap-2">
              <Label htmlFor="business_name">Razón social</Label>
              <Input
                id="business_name"
                placeholder="Acme S.A. de C.V."
                {...register("business_name")}
              />
              {errors.business_name && (
                <p className="text-sm text-destructive mt-1">
                  {errors.business_name.message}
                </p>
              )}
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="rfc">RFC</Label>
              <Input
                id="rfc"
                placeholder="ABC010101AB1"
                className="uppercase"
                {...register("rfc")}
              />
              {errors.rfc && (
                <p className="text-sm text-destructive mt-1">
                  {errors.rfc.message}
                </p>
              )}
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="contact_name">
                Nombre del contacto principal
              </Label>
              <Input
                id="contact_name"
                placeholder="Juan Pérez"
                {...register("contact_name")}
              />
              {errors.contact_name && (
                <p className="text-sm text-destructive mt-1">
                  {errors.contact_name.message}
                </p>
              )}
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="phone">Teléfono</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="5512345678"
                {...register("phone")}
              />
              {errors.phone && (
                <p className="text-sm text-destructive mt-1">
                  {errors.phone.message}
                </p>
              )}
            </div>

            <Button type="submit" disabled={isSubmitting} className="mt-2">
              {isSubmitting ? "Cargando..." : "Guardar y continuar"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
