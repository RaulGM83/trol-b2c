"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { toast } from "sonner"
import {
  ChevronLeft,
  Copy,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileText,
  Download,
  Sparkles,
  HandHelping,
  UserCheck,
  ShieldCheck,
  Calculator,
  ArrowUpCircle,
  RefreshCw,
  Loader2,
} from "lucide-react"

import { createClient } from "@/lib/supabase/client"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  getStatusInfo,
  getStatusBadgeClasses,
  getSourceInfo,
  normalizeStatus,
  isErrorStatus,
  parseErrorDetail,
  DOC_PREVIO_STATUS,
  type StatusInfo,
} from "@/lib/consulta-status"
import { getSLADisplay } from "@/lib/consulta-sla"
import {
  ResumenCliente,
  type ResumenClienteData,
} from "@/components/resumen-cliente"
import {
  LiberadoBadge,
  LiberarDiagnosticoButton,
} from "@/components/liberar-diagnostico"

type ProductRef = {
  code: string | null
  name: string | null
  description: string | null
  delivery_mode: string | null
}

type Consulta = {
  id: string
  partner_id: string | null
  created_at: string
  updated_at: string | null
  completed_at: string | null
  due_at: string | null
  status: string | null
  source: string | null
  nombre: string | null
  apellidos: string | null
  curp: string | null
  asesor_canal: string | null
  price_credits: number | null
  vobo: boolean | null
  fecha_vobo: string | null
  documento_final_url: string | null
  documento_checkup_url: string | null
  documento_diagnostico_url: string | null
  documento_diagnostico_avanzado_url: string | null
  documento_sisec_url: string | null
  error_detail: string | null
  resultado: Record<string, unknown> | null
  resultado_resumen: ResumenClienteData | null
  datos_entrada: Record<string, unknown> | null
  calculo_pensional?: Record<string, unknown> | null
  calculadora_activada_at?: string | null
  upgraded_from_product_id: string | null
  upgraded_at: string | null
  datos_actualizados_at: string | null
  /** Validación de Trol: cuándo y quién liberó el Diagnóstico Avanzado. */
  doc_liberado_at: string | null
  doc_liberado_por: string | null
  products: ProductRef | ProductRef[] | null
}

type UpgradeTarget = {
  code: string
  name: string | null
  price_credits: number
  sla_minutes: number | null
  delivery_mode: string | null
}

/** La calculadora interactiva requiere semilla v2 (con secciones ricas). */
function tieneSemillaCalculadora(c: Consulta): boolean {
  const s = c.calculo_pensional as { meta?: { version_semilla?: string } } | null | undefined
  return !!s?.meta?.version_semilla?.startsWith("2")
}

function pickProduct(p: Consulta["products"]): ProductRef | null {
  if (!p) return null
  if (Array.isArray(p)) return p[0] ?? null
  return p
}

function formatDate(date: string | null | undefined): string {
  if (!date) return "—"
  const d = new Date(date)
  const datePart = new Intl.DateTimeFormat("es-MX", {
    day: "numeric",
    month: "short",
    year: "numeric",
  })
    .format(d)
    .replace(/\./g, "")
  const timePart = new Intl.DateTimeFormat("es-MX", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(d)
  return `${datePart} a las ${timePart}`
}

type Delegation = {
  id: string
  partner_transaction_id: string
  status: string | null
  reason: string | null
  cliente_email: string | null
  cliente_telefono: string | null
  notes: string | null
  created_at: string
}

type Props = {
  consulta: Consulta
  delegation?: Delegation | null
  isAdmin?: boolean
  isOwner?: boolean
  /** Asesor o admin del Trol: puede liberar el documento previo. */
  isAdvisor?: boolean
  /** El aliado (o Trol) puede ver el Diagnóstico Avanzado antes de la validación. */
  canPreviewAvanzado?: boolean
  upgradeTargets?: UpgradeTarget[]
  upgradedFromProduct?: { code: string | null; name: string | null } | null
}

const DELEGATION_STATUS_PILL: Record<
  string,
  { classes: string; label: string }
> = {
  requested: { classes: "bg-gray-100 text-gray-700", label: "Solicitada" },
  contacted: { classes: "bg-blue-100 text-blue-700", label: "Contactada" },
  in_progress: {
    classes: "bg-amber-100 text-amber-700",
    label: "En seguimiento",
  },
  closed_won: {
    classes: "bg-green-100 text-green-700",
    label: "Cerrada (ganada)",
  },
  closed_lost: {
    classes: "bg-red-100 text-red-700",
    label: "Cerrada (sin venta)",
  },
}

const MOTIVO_OPTIONS = [
  {
    value: "cliente_requiere_asesoria_experta",
    label: "Cliente requiere asesoría experta",
  },
  {
    value: "caso_complejo",
    label: "Caso complejo (Modalidad 40, retroactivos, etc.)",
  },
  {
    value: "producto_premium",
    label: "Producto premium / venta cruzada",
  },
  { value: "fuera_de_mi_expertise", label: "Fuera de mi expertise" },
  { value: "otro", label: "Otro (especifica en notas)" },
] as const

const MOTIVO_LABELS: Record<string, string> = MOTIVO_OPTIONS.reduce(
  (acc, opt) => {
    acc[opt.value] = opt.label
    return acc
  },
  {} as Record<string, string>
)

export function ConsultaDetalleClient({
  consulta,
  delegation,
  isAdmin = false,
  isOwner = false,
  isAdvisor = false,
  canPreviewAvanzado = false,
  upgradeTargets = [],
  upgradedFromProduct = null,
}: Props) {
  const product = pickProduct(consulta.products)
  const statusInfo = getStatusInfo(consulta.status ?? "")
  const statusBadgeClasses = getStatusBadgeClasses(statusInfo.variant)
  const statusKey = normalizeStatus(consulta.status)
  const isError = isErrorStatus(consulta.status)
  const errorMessage = isError ? parseErrorDetail(consulta.error_detail) : null
  const sourceInfo = getSourceInfo(consulta.source)

  const clienteNombre = [consulta.nombre, consulta.apellidos]
    .filter(Boolean)
    .join(" ")
    .trim() || "—"

  const datosEntrada = (consulta.datos_entrada ?? {}) as Record<string, unknown>
  const apellidoPaterno =
    (datosEntrada.apellido_paterno as string | undefined) ||
    consulta.apellidos ||
    "—"
  const apellidoMaterno =
    (datosEntrada.apellido_materno as string | undefined) || "—"

  const handleCopyId = async () => {
    try {
      await navigator.clipboard.writeText(consulta.id)
      toast.success("ID copiado")
    } catch {
      toast.error("No se pudo copiar")
    }
  }

  const priceCredits = consulta.price_credits ?? 0
  const priceMxn = priceCredits * 20

  const sla = getSLADisplay({
    created_at: consulta.created_at,
    due_at: consulta.due_at,
    completed_at: consulta.completed_at,
    updated_at: consulta.updated_at,
    status: consulta.status ?? "",
  })

  const slaDisplay = (() => {
    if (sla.type === "na") return null
    if (sla.type === "completed_on_time") {
      return (
        <span className="inline-flex items-center rounded-full bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300 px-3 py-1 text-sm font-medium">
          ✓ Cumplió SLA en {sla.label.replace("Completada en ", "")}
        </span>
      )
    }
    if (sla.type === "completed_late") {
      return (
        <span className="inline-flex items-center rounded-full bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300 px-3 py-1 text-sm font-medium">
          Completada fuera de SLA en {sla.label.replace("Completada en ", "")}
        </span>
      )
    }
    if (sla.type === "failed") {
      return (
        <span className="inline-flex items-center rounded-full bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300 px-3 py-1 text-sm font-medium">
          {sla.label}
        </span>
      )
    }
    if (sla.type === "overdue") {
      return (
        <span className="inline-flex items-center rounded-full bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300 px-3 py-1 text-sm font-medium">
          {sla.label}
        </span>
      )
    }
    return (
      <span className="text-sm">
        Te entregaremos en {sla.label.replace("Entrega en ", "")}
      </span>
    )
  })()

  const resumen = consulta.resultado_resumen

  const [delegateDialogOpen, setDelegateDialogOpen] = useState(false)
  const [ampliarDialogOpen, setAmpliarDialogOpen] = useState(false)
  const [actualizarDialogOpen, setActualizarDialogOpen] = useState(false)

  // --- Ampliar / Actualizar ---
  const productCode = product?.code ?? null
  const isDiagnosticoLine =
    productCode === "DIAGNOSTICO_AVANZADO" ||
    productCode === "DIAGNOSTICO_AVANZADO_SESION"
  const enProceso = statusKey === "received" || statusKey === "processing"

  // Destinos válidos: Checkup ofrece ambos; Avanzado solo "con sesión".
  // Solo se muestran los que cuestan más que la línea actual (diferencia > 0).
  const ampliarTargets = (() => {
    let allowed: string[] = []
    if (productCode === "CHECKUP") {
      allowed = ["DIAGNOSTICO_AVANZADO", "DIAGNOSTICO_AVANZADO_SESION"]
    } else if (productCode === "DIAGNOSTICO_AVANZADO") {
      allowed = ["DIAGNOSTICO_AVANZADO_SESION"]
    }
    return upgradeTargets
      .filter((t) => allowed.includes(t.code))
      .map((t) => ({
        ...t,
        diff: t.price_credits - (consulta.price_credits ?? 0),
      }))
      .filter((t) => t.diff > 0)
  })()

  const canAmpliar =
    isOwner &&
    tieneSemillaCalculadora(consulta) &&
    !enProceso &&
    ampliarTargets.length > 0

  const canActualizar =
    isOwner &&
    (productCode === "CHECKUP" || isDiagnosticoLine) &&
    (statusKey === "completed" || isError)

  // En error, el mismo flujo de "Actualizar información" es el reintento: se
  // muestra dentro del banner rojo, no en la barra de acciones.
  const canReintentar = canActualizar && isError

  const generandoAvanzado =
    !!consulta.upgraded_at && !consulta.documento_diagnostico_avanzado_url

  // n8n ya dejó el Diagnóstico Avanzado, falta la validación de Trol.
  const esDocPrevio = statusKey === normalizeStatus(DOC_PREVIO_STATUS)

  // Solo Trol (asesor/admin) libera el documento previo; el aliado nunca ve
  // este botón. La RPC revalida el rol en el servidor.
  const canLiberar = isAdvisor && esDocPrevio && !consulta.doc_liberado_at

  return (
    <div className="w-full max-w-[1200px] mx-auto py-6 px-4 flex flex-col gap-6">
      <div className="flex flex-col gap-4">
        <div>
          <Button asChild variant="ghost" size="sm">
            <Link href="/consultas">
              <ChevronLeft />
              Consultas
            </Link>
          </Button>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
          <div className="flex flex-col gap-2 min-w-0">
            <div className="flex flex-col gap-1">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                ConsultaID
              </span>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs text-muted-foreground truncate">
                  {consulta.id}
                </span>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon-xs"
                  onClick={handleCopyId}
                  aria-label="Copiar ID"
                >
                  <Copy />
                </Button>
              </div>
            </div>
            <h1 className="font-heading font-bold text-2xl">
              Consulta de {clienteNombre}
            </h1>
          </div>

          <div className="flex flex-col items-start sm:items-end gap-1.5">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span
                className={`inline-flex items-center rounded-full px-3 py-1 text-sm font-medium ${statusBadgeClasses}`}
              >
                {statusInfo.label}
              </span>
              <span
                className={`inline-flex items-center rounded px-2 py-0.5 text-xs font-semibold uppercase ${sourceInfo.classes}`}
              >
                Origen: {sourceInfo.label}
              </span>
              {consulta.upgraded_at && (
                <span
                  className="inline-flex items-center gap-1 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300 px-2.5 py-0.5 text-xs font-medium"
                  title={
                    upgradedFromProduct?.name
                      ? `Ampliada desde ${upgradedFromProduct.name} el ${formatDate(consulta.upgraded_at)}`
                      : `Ampliada el ${formatDate(consulta.upgraded_at)}`
                  }
                >
                  <ArrowUpCircle className="size-3" />
                  Ampliada
                </span>
              )}
              {consulta.doc_liberado_at && (
                <LiberadoBadge liberadoAt={consulta.doc_liberado_at} />
              )}
            </div>
            <span className="text-xs text-muted-foreground">
              Creada el {formatDate(consulta.created_at)}
            </span>
            <div className="flex items-center gap-1.5 flex-wrap">
              {canLiberar && (
                <LiberarDiagnosticoButton consultaId={consulta.id} />
              )}
              {tieneSemillaCalculadora(consulta) && (
                <Button type="button" variant="default" size="sm" asChild>
                  <Link href={`/consultas/${consulta.id}/calculadora`}>
                    <Sparkles />
                    Calculadora
                  </Link>
                </Button>
              )}
              {canAmpliar && (
                <Button
                  type="button"
                  variant="default"
                  size="sm"
                  onClick={() => setAmpliarDialogOpen(true)}
                >
                  <ArrowUpCircle />
                  Ampliar a Diagnóstico Avanzado
                </Button>
              )}
              {canActualizar && !canReintentar && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setActualizarDialogOpen(true)}
                >
                  <RefreshCw />
                  Actualizar información (1 crédito)
                </Button>
              )}
              {isOwner && !delegation && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setDelegateDialogOpen(true)}
                >
                  <HandHelping />
                  Delegar al Trol
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>

      {isError && (
        <div className="flex flex-col sm:flex-row sm:items-center gap-3 rounded-lg border border-red-200 dark:border-red-500/30 bg-red-50 dark:bg-red-500/10 px-4 py-3">
          <AlertCircle className="size-5 shrink-0 text-red-700 dark:text-red-300" />
          <div className="flex flex-col min-w-0 flex-1">
            <span className="text-sm font-medium text-red-900 dark:text-red-200">
              No pudimos completar esta consulta
            </span>
            <span className="text-xs text-red-900/75 dark:text-red-200/75 break-words">
              {errorMessage}
            </span>
          </div>
          {canReintentar && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="shrink-0 self-start sm:self-auto border-red-300 dark:border-red-500/40 bg-white/70 dark:bg-transparent hover:bg-white text-red-900 dark:text-red-200"
              onClick={() => setActualizarDialogOpen(true)}
            >
              <RefreshCw />
              Reintentar consulta (1 crédito)
            </Button>
          )}
        </div>
      )}

      {delegation && <DelegationBanner delegation={delegation} />}

      {isOwner && !delegation && (
        <DelegateDialog
          open={delegateDialogOpen}
          onOpenChange={setDelegateDialogOpen}
          consultaId={consulta.id}
        />
      )}

      {canAmpliar && (
        <AmpliarDialog
          open={ampliarDialogOpen}
          onOpenChange={setAmpliarDialogOpen}
          consultaId={consulta.id}
          targets={ampliarTargets}
        />
      )}

      {canActualizar && (
        <ActualizarDialog
          open={actualizarDialogOpen}
          onOpenChange={setActualizarDialogOpen}
          consultaId={consulta.id}
          isDiagnostico={isDiagnosticoLine}
          isRetry={canReintentar}
        />
      )}

      {generandoAvanzado && (
        <div className="flex items-center gap-3 rounded-lg border border-indigo-200 dark:border-indigo-500/30 bg-indigo-50 dark:bg-indigo-500/10 px-4 py-3">
          <Loader2 className="size-5 shrink-0 animate-spin text-indigo-700 dark:text-indigo-300" />
          <div className="flex flex-col">
            <span className="text-sm font-medium text-indigo-900 dark:text-indigo-200">
              Generando documento avanzado…
            </span>
            <span className="text-xs text-indigo-900/70 dark:text-indigo-200/70">
              Estamos preparando tu Diagnóstico Avanzado. Aparecerá en la pestaña
              Documentos en breve.
            </span>
          </div>
        </div>
      )}

      {isAdmin && (
        <AdminPanel
          consultaId={consulta.id}
          calculadoraActivada={!!consulta.calculadora_activada_at}
          tieneSemilla={tieneSemillaCalculadora(consulta)}
          sisecUrlInicial={consulta.documento_sisec_url}
        />
      )}

      <Separator />

      <Tabs defaultValue="resumen" className="flex-col w-full">
        <TabsList className="!h-8 p-0.5 w-fit">
          <TabsTrigger value="resumen" className="!px-3 !py-1 text-sm">Resumen</TabsTrigger>
          <TabsTrigger value="datos" className="!px-3 !py-1 text-sm">Datos</TabsTrigger>
          <TabsTrigger value="documentos" className="!px-3 !py-1 text-sm">Documentos</TabsTrigger>
          <TabsTrigger value="timeline" className="!px-3 !py-1 text-sm">Timeline</TabsTrigger>
        </TabsList>

        <TabsContent value="resumen" className="mt-2 w-full flex flex-col gap-4">
          <EstadoBanner
            statusInfo={statusInfo}
            status={consulta.status}
            errorDetail={consulta.error_detail}
            esDocPrevio={esDocPrevio}
            hideFailure={isError}
          />

          <Card>
            <CardHeader>
              <CardTitle>Producto</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              <div className="flex flex-col gap-1">
                <span className="text-base font-medium">
                  {product?.name ?? "—"}
                </span>
                {product?.description && (
                  <p className="text-sm text-muted-foreground">
                    {product.description}
                  </p>
                )}
              </div>
              <div className="text-sm">
                <span className="font-medium">{priceCredits} créditos</span>{" "}
                <span className="text-muted-foreground">
                  (≈${priceMxn} MXN)
                </span>
              </div>
              {slaDisplay && <div>{slaDisplay}</div>}
              <div className="text-xs text-muted-foreground">
                Información al{" "}
                {formatDate(
                  consulta.datos_actualizados_at ?? consulta.created_at
                )}
              </div>
              {product?.delivery_mode === "mixed_with_session" && (
                <div>
                  <span className="inline-flex items-center rounded-full bg-purple-100 text-purple-700 px-2.5 py-0.5 text-xs font-medium">
                    Incluye sesión con experto
                  </span>
                </div>
              )}
            </CardContent>
          </Card>

          {/* El resumen se muestra siempre que exista, sin importar el producto
              ni el status; los avisos de estado van arriba como banner. */}
          {resumen ? (
            <ResumenCliente
              resumen={resumen}
              calculoPensional={consulta.calculo_pensional}
            />
          ) : (
            <Card>
              <CardContent className="py-10 text-center text-sm text-muted-foreground">
                {statusInfo.isFailure
                  ? "No pudimos generar el resumen de esta consulta."
                  : "El resumen del cliente aparecerá aquí en cuanto esté listo."}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="datos" className="mt-2 w-full">
          <Card>
            <CardHeader>
              <CardTitle>Datos del cliente</CardTitle>
              <CardDescription>
                Información enviada al crear la consulta
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2">
                <KeyValue label="Nombre del cliente" value={consulta.nombre ?? "—"} />
                <KeyValue label="Apellido paterno" value={apellidoPaterno} />
                <KeyValue label="Apellido materno" value={apellidoMaterno} />
                <KeyValue
                  label="CURP"
                  value={consulta.curp ?? "—"}
                  mono
                />
                <KeyValue
                  label="Asesor o canal que atiende"
                  value={consulta.asesor_canal ?? "—"}
                />
                <KeyValue
                  label="Visto bueno del cliente"
                  value={
                    consulta.vobo
                      ? `✓ Confirmado el ${formatDate(consulta.fecha_vobo)}`
                      : "✗ No confirmado"
                  }
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documentos" className="mt-2 w-full">
          <DocumentosTab
            isSuccess={statusInfo.isSuccess}
            docPrevio={esDocPrevio}
            canPreviewAvanzado={canPreviewAvanzado}
            checkupUrl={consulta.documento_checkup_url}
            diagnosticoUrl={consulta.documento_diagnostico_url}
            avanzadoUrl={consulta.documento_diagnostico_avanzado_url}
            sisecUrl={consulta.documento_sisec_url}
          />
        </TabsContent>

        <TabsContent value="timeline" className="mt-2 w-full">
          <Card>
            <CardContent className="py-2">
              <ol className="flex flex-col">
                <TimelineEvent
                  icon={<Clock className="size-4" />}
                  title="Consulta creada"
                  timestamp={formatDate(consulta.created_at)}
                  description={`Solicitaste un ${product?.name ?? "producto"} para ${clienteNombre}`}
                />

                {consulta.updated_at &&
                  consulta.updated_at !== consulta.created_at && (
                    <TimelineEvent
                      icon={
                        statusInfo.isFailure ? (
                          <AlertCircle className="size-4" />
                        ) : (
                          <Clock className="size-4" />
                        )
                      }
                      title={`Estado actualizado a ${statusInfo.label}`}
                      timestamp={formatDate(consulta.updated_at)}
                    />
                  )}

                {consulta.completed_at && (
                  <TimelineEvent
                    icon={<CheckCircle2 className="size-4 text-green-600" />}
                    title="Consulta completada"
                    timestamp={formatDate(consulta.completed_at)}
                    description="El resultado está listo"
                    last={!consulta.upgraded_at && !consulta.datos_actualizados_at}
                  />
                )}

                {consulta.upgraded_at && (
                  <TimelineEvent
                    icon={<ArrowUpCircle className="size-4 text-indigo-600" />}
                    title={`Ampliada a ${product?.name ?? "Diagnóstico Avanzado"}`}
                    timestamp={formatDate(consulta.upgraded_at)}
                    description={
                      upgradedFromProduct?.name
                        ? `Desde ${upgradedFromProduct.name}`
                        : undefined
                    }
                    last={!consulta.datos_actualizados_at}
                  />
                )}

                {consulta.datos_actualizados_at && (
                  <TimelineEvent
                    icon={<RefreshCw className="size-4 text-blue-600" />}
                    title="Información actualizada"
                    timestamp={formatDate(consulta.datos_actualizados_at)}
                    description="Se volvió a consultar la información del cliente"
                    last
                  />
                )}
              </ol>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

/**
 * Aviso de estado del tab Resumen. Es un banner: acompaña al resumen del
 * cliente, nunca lo sustituye.
 */
function EstadoBanner({
  statusInfo,
  status,
  errorDetail,
  esDocPrevio,
  hideFailure = false,
}: {
  statusInfo: StatusInfo
  status: string | null
  errorDetail: string | null
  esDocPrevio: boolean
  /** El error ya se muestra en el banner rojo superior: no lo repetimos aquí. */
  hideFailure?: boolean
}) {
  const banner = (() => {
    if (statusInfo.isFailure) {
      if (hideFailure) return null
      return {
        tone: "rojo" as const,
        icon: <AlertCircle className="size-5 shrink-0" />,
        title: `Algo salió mal: ${statusInfo.label}`,
        detail: parseErrorDetail(errorDetail),
      }
    }
    if (normalizeStatus(status) === "delegated") {
      return {
        tone: "morado" as const,
        icon: <HandHelping className="size-5 shrink-0" />,
        title: "Consulta delegada al equipo Trol",
        detail: "El equipo Trol le da seguimiento manual a este caso.",
      }
    }
    if (esDocPrevio) {
      return {
        tone: "ambar" as const,
        icon: <ShieldCheck className="size-5 shrink-0" />,
        title: "Documento en validación por Trol",
        detail:
          "Los datos del cliente ya están disponibles; el documento final se libera al validarlo.",
      }
    }
    if (!statusInfo.isTerminal) {
      return {
        tone: "ambar" as const,
        icon: <Loader2 className="size-5 shrink-0 animate-spin" />,
        title: "Estamos procesando tu consulta",
        detail: "Te avisaremos por correo cuando esté lista.",
      }
    }
    return null
  })()

  if (!banner) return null

  const tones = {
    rojo: "border-red-200 dark:border-red-500/30 bg-red-50 dark:bg-red-500/10 text-red-900 dark:text-red-200",
    ambar:
      "border-amber-200 dark:border-amber-500/30 bg-amber-50 dark:bg-amber-500/10 text-amber-900 dark:text-amber-200",
    morado:
      "border-purple-200 dark:border-purple-500/30 bg-purple-50 dark:bg-purple-500/10 text-purple-900 dark:text-purple-200",
  }

  return (
    <div
      className={`flex items-center gap-3 rounded-lg border px-4 py-3 ${tones[banner.tone]}`}
    >
      {banner.icon}
      <div className="flex flex-col">
        <span className="text-sm font-medium">{banner.title}</span>
        <span className="text-xs opacity-75">{banner.detail}</span>
      </div>
    </div>
  )
}

function DocumentosTab({
  isSuccess,
  docPrevio,
  canPreviewAvanzado,
  checkupUrl,
  diagnosticoUrl,
  avanzadoUrl,
  sisecUrl,
}: {
  isSuccess: boolean
  docPrevio: boolean
  canPreviewAvanzado: boolean
  checkupUrl: string | null
  diagnosticoUrl: string | null
  avanzadoUrl: string | null
  sisecUrl: string | null
}) {
  // El historial Sisec lo puede subir Trol incluso antes de que termine el flujo,
  // así que la fila se muestra independientemente del status si existe la URL.
  const sisecRow = sisecUrl ? (
    <DocumentCard
      title="Historial Sisec"
      audience="documento oficial IMSS"
      description="PDF descargado del portal IMSS Digital con el historial laboral oficial del cliente."
      url={sisecUrl}
      downloadLabel="Descargar Sisec"
    />
  ) : null

  const avanzadoDescription =
    "Reporte completo: escenarios por edad, estrategia, gestorías, ISSSTE, Infonavit y ahorro — con la marca de tu despacho."

  // En "Doc previo listo" el documento ya existe pero Trol no lo ha validado:
  // los aliados con el flag lo ven marcado como previo; el resto solo ve que
  // está en validación (sin link).
  const avanzadoRow = docPrevio ? (
    canPreviewAvanzado && avanzadoUrl ? (
      <DocumentCard
        title="Diagnóstico Avanzado"
        audience="para el cliente"
        description={avanzadoDescription}
        url={avanzadoUrl}
        downloadLabel="Descargar Diagnóstico Avanzado"
        badge="Documento previo — pendiente de validación de Trol"
      />
    ) : (
      <DocumentCard
        title="Diagnóstico Avanzado"
        audience="para el cliente"
        description={avanzadoDescription}
        url={null}
        downloadLabel="Descargar Diagnóstico Avanzado"
        pendingLabel="Documento en validación por Trol"
      />
    )
  ) : avanzadoUrl ? (
    <DocumentCard
      title="Diagnóstico Avanzado"
      audience="para el cliente"
      description={avanzadoDescription}
      url={avanzadoUrl}
      downloadLabel="Descargar Diagnóstico Avanzado"
    />
  ) : null

  if (!isSuccess && !docPrevio) {
    return (
      <div className="flex flex-col gap-4">
        {sisecRow && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">{sisecRow}</div>
        )}
        <Card>
          <CardContent className="flex flex-col items-center text-center py-16 gap-4">
            <div className="rounded-full bg-muted p-4">
              <FileText className="size-8 text-muted-foreground" />
            </div>
            <div className="flex flex-col gap-1">
              <h3 className="font-heading text-lg font-medium">
                Aún no hay documentos finales
              </h3>
              <p className="text-sm text-muted-foreground">
                Cuando tu consulta esté lista, el documento aparecerá aquí para
                descarga
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!checkupUrl && !diagnosticoUrl && !avanzadoRow && !sisecRow) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center text-center py-16 gap-4">
          <div className="rounded-full bg-muted p-4">
            <FileText className="size-8 text-muted-foreground" />
          </div>
          <div className="flex flex-col gap-1">
            <h3 className="font-heading text-lg font-medium">
              Documentos en preparación
            </h3>
            <p className="text-sm text-muted-foreground">
              Tu Checkup y Diagnóstico están siendo generados. Estarán
              disponibles en breve.
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      {sisecRow}
      <DocumentCard
        title="Checkup Pensional"
        audience="para el asesor"
        description="Ficha de perfilamiento con datos crudos del IMSS para que prepares la conversación con tu cliente."
        url={checkupUrl}
        downloadLabel="Descargar Checkup"
      />
      <DocumentCard
        title="Diagnóstico Básico"
        audience="para el cliente"
        description="Reporte conversacional con narrativa personalizada, listo para compartir directamente con tu cliente."
        url={diagnosticoUrl}
        downloadLabel="Descargar Diagnóstico"
      />
      {avanzadoRow}
    </div>
  )
}

function DocumentCard({
  title,
  audience,
  description,
  url,
  downloadLabel,
  badge,
  pendingLabel = "En preparación",
}: {
  title: string
  audience: string
  description: string
  url: string | null
  downloadLabel: string
  /** Aviso ámbar sobre el documento (p. ej. "previo, pendiente de validación"). */
  badge?: string
  /** Texto del botón deshabilitado cuando aún no hay URL. */
  pendingLabel?: string
}) {
  return (
    <Card>
      <CardContent className="flex flex-col gap-4 py-6">
        <div className="flex items-start gap-3">
          <div className="rounded-full bg-muted p-3">
            <FileText className="size-5 text-muted-foreground" />
          </div>
          <div className="flex flex-col">
            <span className="font-heading font-medium">{title}</span>
            <span className="text-xs text-muted-foreground">{audience}</span>
          </div>
        </div>
        {badge && (
          <span className="inline-flex items-center gap-1.5 self-start rounded-full bg-amber-100 px-2.5 py-1 text-xs font-medium text-amber-700 dark:bg-amber-500/15 dark:text-amber-300">
            <AlertCircle className="size-3.5 shrink-0" />
            {badge}
          </span>
        )}
        <p className="text-sm text-muted-foreground">{description}</p>
        <div>
          {url ? (
            <Button asChild>
              <a href={url.trim()} target="_blank" rel="noopener noreferrer">
                <Download />
                {downloadLabel}
              </a>
            </Button>
          ) : (
            <Button disabled>{pendingLabel}</Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

function KeyValue({
  label,
  value,
  mono,
}: {
  label: string
  value: string
  mono?: boolean
}) {
  return (
    <div className="flex items-baseline justify-between gap-4 py-1">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span
        className={`text-sm font-medium text-right break-all ${
          mono ? "font-mono" : ""
        }`}
      >
        {value}
      </span>
    </div>
  )
}

function TimelineEvent({
  icon,
  title,
  timestamp,
  description,
  last,
}: {
  icon: React.ReactNode
  title: string
  timestamp: string
  description?: string
  last?: boolean
}) {
  return (
    <li className="flex gap-4 py-5">
      <div className="flex flex-col items-center">
        <div className="rounded-full bg-muted p-2 text-muted-foreground">
          {icon}
        </div>
        {!last && <div className="w-px flex-1 bg-border mt-2" />}
      </div>
      <div className="flex flex-col gap-1 pb-2 flex-1">
        <span className="font-medium text-sm">{title}</span>
        <span className="text-xs text-muted-foreground">{timestamp}</span>
        {description && (
          <p className="text-sm text-muted-foreground mt-1">{description}</p>
        )}
      </div>
    </li>
  )
}

function AdminPanel({
  consultaId,
  calculadoraActivada,
  tieneSemilla,
  sisecUrlInicial,
}: {
  consultaId: string
  calculadoraActivada: boolean
  tieneSemilla: boolean
  sisecUrlInicial: string | null
}) {
  const router = useRouter()
  const [cobrar, setCobrar] = useState(true)
  const [activando, setActivando] = useState(false)
  const [sisecUrl, setSisecUrl] = useState(sisecUrlInicial ?? "")
  const [guardandoSisec, setGuardandoSisec] = useState(false)

  async function activar() {
    setActivando(true)
    const supabase = createClient()
    const { error } = await supabase.rpc("admin_activar_calculadora", {
      p_consulta_id: consultaId,
      p_cobrar: cobrar,
    })
    if (error) {
      const hint = error.hint ?? ""
      if (hint === "not_admin") {
        toast.error("Acción solo disponible para admins")
      } else if (hint === "semilla_v2_missing") {
        toast.error("Esta consulta no tiene semilla v2; no se puede activar")
      } else if (hint === "insufficient_balance") {
        toast.error("El aliado no tiene saldo suficiente. Desmarca 'Cobrar al aliado' o recarga su saldo.")
      } else {
        toast.error(error.message)
      }
      setActivando(false)
      return
    }
    toast.success(
      cobrar ? "Calculadora activada y aliado cobrado" : "Calculadora activada (sin cobro)"
    )
    setActivando(false)
    router.refresh()
  }

  async function guardarSisec() {
    setGuardandoSisec(true)
    const supabase = createClient()
    const trimmed = sisecUrl.trim()
    const { error } = await supabase.rpc("admin_set_documento_sisec", {
      p_consulta_id: consultaId,
      p_url: trimmed.length > 0 ? trimmed : null,
    })
    if (error) {
      const hint = error.hint ?? ""
      if (hint === "not_admin") {
        toast.error("Acción solo disponible para admins")
      } else if (hint === "invalid_url") {
        toast.error("URL inválida — debe iniciar con https://")
      } else {
        toast.error(error.message)
      }
      setGuardandoSisec(false)
      return
    }
    toast.success(trimmed.length > 0 ? "URL Sisec guardada" : "URL Sisec eliminada")
    setGuardandoSisec(false)
    router.refresh()
  }

  return (
    <Card className="border-amber-300 dark:border-amber-500/40 bg-amber-50/60 dark:bg-amber-500/5">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="size-5 text-amber-700 dark:text-amber-300" />
          <CardTitle className="text-base text-amber-900 dark:text-amber-200">
            Admin
          </CardTitle>
        </div>
        <CardDescription className="text-amber-900/80 dark:text-amber-200/80">
          Acciones de operador Trol sobre la consulta de este aliado.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-2 text-sm font-semibold text-amber-900 dark:text-amber-200">
            <Calculator className="size-4" />
            Calculadora interactiva
          </div>
          {calculadoraActivada ? (
            <p className="text-sm text-amber-900/80 dark:text-amber-200/80">
              Ya está activada para esta consulta.
            </p>
          ) : !tieneSemilla ? (
            <p className="text-sm text-amber-900/80 dark:text-amber-200/80">
              Esta consulta aún no tiene semilla v2; espera al procesamiento de n8n.
            </p>
          ) : (
            <>
              <label className="flex items-center gap-2 text-sm cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={cobrar}
                  onChange={(e) => setCobrar(e.target.checked)}
                  className="size-4 accent-amber-600"
                />
                Cobrar al aliado (2 créditos)
              </label>
              <div>
                <Button
                  type="button"
                  size="sm"
                  onClick={activar}
                  disabled={activando}
                >
                  {activando ? "Activando…" : "Activar calculadora"}
                </Button>
              </div>
            </>
          )}
        </div>

        <Separator className="bg-amber-200 dark:bg-amber-500/30" />

        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 text-sm font-semibold text-amber-900 dark:text-amber-200">
            <FileText className="size-4" />
            URL Sisec (Drive)
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <Input
              type="url"
              placeholder="https://drive.google.com/…"
              value={sisecUrl}
              onChange={(e) => setSisecUrl(e.target.value)}
              className="bg-white dark:bg-background"
            />
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={guardarSisec}
              disabled={guardandoSisec}
            >
              {guardandoSisec ? "Guardando…" : "Guardar"}
            </Button>
          </div>
          <p className="text-xs text-amber-900/70 dark:text-amber-200/70">
            Deja vacío y guarda para borrar la URL.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

function DelegationBanner({ delegation }: { delegation: Delegation }) {
  const statusKey = delegation.status ?? "requested"
  const pill =
    DELEGATION_STATUS_PILL[statusKey] ?? DELEGATION_STATUS_PILL.requested

  return (
    <div className="bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/30 rounded-lg p-4 mb-4">
      <div className="flex items-center justify-between gap-3 flex-wrap mb-3">
        <div className="flex items-center gap-2">
          <UserCheck className="size-5 text-amber-900 dark:text-amber-200" />
          <span className="font-semibold text-amber-900 dark:text-amber-200">
            Delegada al equipo Trol
          </span>
        </div>
        <span
          className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-medium ${pill.classes}`}
        >
          {pill.label}
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="flex flex-col gap-3">
          <div className="flex flex-col gap-0.5">
            <span className="text-xs font-medium text-amber-900/70 dark:text-amber-200/70 uppercase tracking-wide">
              Motivo
            </span>
            <span className="text-sm text-amber-950 dark:text-amber-100">
              {delegation.reason ?? "—"}
            </span>
          </div>
          {delegation.notes && (
            <div className="flex flex-col gap-0.5">
              <span className="text-xs font-medium text-amber-900/70 dark:text-amber-200/70 uppercase tracking-wide">
                Notas
              </span>
              <blockquote className="text-sm text-amber-950 dark:text-amber-100 border-l-2 border-amber-300 dark:border-amber-500/40 pl-3 italic whitespace-pre-wrap">
                {delegation.notes}
              </blockquote>
            </div>
          )}
        </div>

        <div className="flex flex-col gap-3">
          <div className="flex flex-col gap-0.5">
            <span className="text-xs font-medium text-amber-900/70 dark:text-amber-200/70 uppercase tracking-wide">
              Email cliente
            </span>
            {delegation.cliente_email ? (
              <a
                href={`mailto:${delegation.cliente_email}`}
                className="text-sm text-amber-950 dark:text-amber-100 underline underline-offset-2 hover:text-amber-700 dark:hover:text-amber-300 break-all"
              >
                {delegation.cliente_email}
              </a>
            ) : (
              <span className="text-sm text-amber-950 dark:text-amber-100">—</span>
            )}
          </div>
          <div className="flex flex-col gap-0.5">
            <span className="text-xs font-medium text-amber-900/70 dark:text-amber-200/70 uppercase tracking-wide">
              Teléfono cliente
            </span>
            {delegation.cliente_telefono ? (
              <a
                href={`tel:${delegation.cliente_telefono.replace(/[^\d+]/g, "")}`}
                className="text-sm text-amber-950 dark:text-amber-100 underline underline-offset-2 hover:text-amber-700 dark:hover:text-amber-300"
              >
                {delegation.cliente_telefono}
              </a>
            ) : (
              <span className="text-sm text-amber-950 dark:text-amber-100">—</span>
            )}
          </div>
        </div>
      </div>

      <div className="mt-4 pt-3 border-t border-amber-200 dark:border-amber-500/30 flex flex-col gap-1">
        <span className="text-xs text-amber-900/80 dark:text-amber-200/80">
          Solicitada el {formatDate(delegation.created_at)}
        </span>
        <span className="text-sm text-amber-800/70 dark:text-amber-200/60">
          El equipo Trol se está poniendo en contacto con tu cliente. Tu
          atribución queda registrada permanentemente.
        </span>
      </div>
    </div>
  )
}

const delegateSchema = z.object({
  motivo: z.enum(
    [
      "cliente_requiere_asesoria_experta",
      "caso_complejo",
      "producto_premium",
      "fuera_de_mi_expertise",
      "otro",
    ],
    { errorMap: () => ({ message: "Selecciona un motivo" }) }
  ),
  cliente_email: z.string().email("Email inválido"),
  cliente_telefono: z
    .string()
    .min(10, "Mínimo 10 dígitos")
    .regex(/^[\d\s\-+()]+$/, "Solo números, espacios y + - ( )"),
  notes: z.string().optional(),
})

type DelegateValues = z.infer<typeof delegateSchema>

function DelegateDialog({
  open,
  onOpenChange,
  consultaId,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  consultaId: string
}) {
  const router = useRouter()
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<DelegateValues>({
    resolver: zodResolver(delegateSchema),
    mode: "onChange",
    defaultValues: {
      cliente_email: "",
      cliente_telefono: "",
      notes: "",
    },
  })

  const motivo = watch("motivo")

  const onSubmit = async (values: DelegateValues) => {
    const supabase = createClient()
    const { error } = await supabase.rpc("delegate_consulta", {
      p_consulta_id: consultaId,
      p_reason: MOTIVO_LABELS[values.motivo] ?? values.motivo,
      p_cliente_email: values.cliente_email,
      p_cliente_telefono: values.cliente_telefono,
      p_notes: values.notes && values.notes.length > 0 ? values.notes : null,
    })

    if (error) {
      if (error.code === "P0003") {
        toast.error("Esta consulta ya está delegada")
      } else if (error.code === "P0005") {
        toast.error("Email del cliente inválido")
      } else if (error.code === "P0006") {
        toast.error("Teléfono del cliente inválido (mínimo 10 dígitos)")
      } else {
        toast.error(error.message)
      }
      return
    }

    toast.success("Consulta delegada al equipo Trol")
    reset()
    onOpenChange(false)
    router.refresh()
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (!next) reset()
        onOpenChange(next)
      }}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Delegar al equipo Trol</DialogTitle>
          <DialogDescription>
            El equipo Trol contactará directamente a tu cliente para seguir el
            caso. Mantienes la atribución y comisión si la operación cierra.
          </DialogDescription>
        </DialogHeader>

        <form
          id="delegate-form"
          className="flex flex-col gap-4"
          onSubmit={handleSubmit(onSubmit)}
        >
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="motivo">Motivo</Label>
            <Select
              value={motivo}
              onValueChange={(v) =>
                setValue("motivo", v as DelegateValues["motivo"], {
                  shouldValidate: true,
                })
              }
            >
              <SelectTrigger id="motivo" className="w-full">
                <SelectValue placeholder="Selecciona un motivo" />
              </SelectTrigger>
              <SelectContent>
                {MOTIVO_OPTIONS.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.motivo && (
              <span className="text-xs text-destructive">
                {errors.motivo.message}
              </span>
            )}
          </div>

          <div className="flex flex-col gap-1.5">
            <Label htmlFor="cliente_email">Email del cliente</Label>
            <Input
              id="cliente_email"
              type="email"
              placeholder="cliente@email.com"
              {...register("cliente_email")}
            />
            {errors.cliente_email && (
              <span className="text-xs text-destructive">
                {errors.cliente_email.message}
              </span>
            )}
          </div>

          <div className="flex flex-col gap-1.5">
            <Label htmlFor="cliente_telefono">Teléfono del cliente</Label>
            <Input
              id="cliente_telefono"
              type="tel"
              placeholder="55 1234 5678"
              {...register("cliente_telefono")}
            />
            {errors.cliente_telefono && (
              <span className="text-xs text-destructive">
                {errors.cliente_telefono.message}
              </span>
            )}
          </div>

          <div className="flex flex-col gap-1.5">
            <Label htmlFor="notes">Notas adicionales</Label>
            <Textarea
              id="notes"
              rows={3}
              placeholder="Contexto que ayude al equipo Trol..."
              {...register("notes")}
            />
          </div>
        </form>

        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={isSubmitting}
          >
            Cancelar
          </Button>
          <Button type="submit" form="delegate-form" disabled={isSubmitting}>
            {isSubmitting ? "Delegando..." : "Delegar consulta"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

type AmpliarTarget = UpgradeTarget & { diff: number }

function AmpliarDialog({
  open,
  onOpenChange,
  consultaId,
  targets,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  consultaId: string
  targets: AmpliarTarget[]
}) {
  const router = useRouter()
  const [loadingCode, setLoadingCode] = useState<string | null>(null)

  async function ampliar(code: string) {
    setLoadingCode(code)
    const supabase = createClient()
    const { data, error } = await supabase.rpc("ampliar_consulta", {
      p_consulta_id: consultaId,
      p_product_code: code,
    })

    if (error) {
      const hint = error.hint ?? ""
      if (hint === "insufficient_balance") {
        toast.error("Saldo insuficiente, recarga créditos")
      } else if (hint === "semilla_v2_missing") {
        toast.error(
          "Esta consulta no tiene información disponible; usa Actualizar información"
        )
      } else if (hint === "not_an_upgrade") {
        toast.error("Esta consulta ya tiene ese nivel o uno mayor")
      } else if (hint === "consulta_in_flight") {
        toast.error("Espera a que termine el proceso actual")
      } else {
        toast.error(error.message)
      }
      setLoadingCode(null)
      return
    }

    const row = Array.isArray(data) ? data[0] : data
    const newBalance = row?.new_balance_credits
    toast.success(
      newBalance !== null && newBalance !== undefined
        ? `Consulta ampliada. Nuevo saldo: ${newBalance} créditos`
        : "Consulta ampliada"
    )
    setLoadingCode(null)
    onOpenChange(false)
    router.refresh()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Ampliar a Diagnóstico Avanzado</DialogTitle>
          <DialogDescription>
            Reutilizamos la información ya disponible del cliente y solo cobramos
            la diferencia de créditos. No es necesario volver a dar de alta al
            cliente.
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-3 py-2">
          {targets.map((t) => (
            <button
              key={t.code}
              type="button"
              disabled={loadingCode !== null}
              onClick={() => ampliar(t.code)}
              className="flex items-center justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3 text-left transition-colors hover:bg-accent disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <div className="flex flex-col">
                <span className="font-medium text-sm">
                  {t.name ?? t.code}
                </span>
                {t.delivery_mode === "mixed_with_session" && (
                  <span className="text-xs text-muted-foreground">
                    Incluye sesión con experto
                  </span>
                )}
              </div>
              <span className="inline-flex items-center rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300 px-3 py-1 text-sm font-semibold whitespace-nowrap">
                {loadingCode === t.code
                  ? "Ampliando…"
                  : `${t.diff} crédito${t.diff === 1 ? "" : "s"}`}
              </span>
            </button>
          ))}
        </div>

        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={loadingCode !== null}
          >
            Cancelar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function ActualizarDialog({
  open,
  onOpenChange,
  consultaId,
  isDiagnostico,
  isRetry = false,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  consultaId: string
  isDiagnostico: boolean
  /** La consulta quedó en error: el mismo flujo se presenta como reintento. */
  isRetry?: boolean
}) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)

  async function actualizar() {
    setLoading(true)
    const supabase = createClient()
    const { data, error } = await supabase.rpc("actualizar_consulta", {
      p_consulta_id: consultaId,
    })

    if (error) {
      const hint = error.hint ?? ""
      if (hint === "insufficient_balance") {
        toast.error("Saldo insuficiente, recarga créditos")
      } else if (hint === "consulta_in_flight") {
        toast.error("Espera a que termine el proceso actual")
      } else {
        toast.error(error.message)
      }
      setLoading(false)
      return
    }

    const row = Array.isArray(data) ? data[0] : data
    const newBalance = row?.new_balance_credits
    toast.success(
      newBalance !== null && newBalance !== undefined
        ? `Información actualizada. Nuevo saldo: ${newBalance} créditos`
        : "Información actualizada"
    )
    setLoading(false)
    onOpenChange(false)
    router.refresh()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {isRetry ? "Reintentar consulta" : "Actualizar información"}
          </DialogTitle>
          <DialogDescription>
            Se volverá a consultar la información del cliente (SISEC) y se
            recalculará todo. Costo: 1 crédito.
            {isDiagnostico && " El documento avanzado se regenerará."}
          </DialogDescription>
        </DialogHeader>

        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={loading}
          >
            Cancelar
          </Button>
          <Button type="button" onClick={actualizar} disabled={loading}>
            {loading
              ? isRetry
                ? "Reintentando…"
                : "Actualizando…"
              : isRetry
                ? "Reintentar (1 crédito)"
                : "Actualizar (1 crédito)"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
