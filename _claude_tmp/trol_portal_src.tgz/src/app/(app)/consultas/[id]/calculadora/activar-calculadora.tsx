"use client"

import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"

export function ActivarCalculadora({
  consultaId,
  precioCreditos,
  clienteNombre,
}: {
  consultaId: string
  precioCreditos: number
  clienteNombre: string
}) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)

  async function activar() {
    setLoading(true)
    const supabase = createClient()
    const { error } = await supabase.rpc("activar_calculadora", {
      p_consulta_id: consultaId,
    })
    if (error) {
      const msg =
        error.hint === "insufficient_balance"
          ? "Saldo insuficiente de créditos. Recarga en la página de Saldo."
          : error.message
      toast.error(msg)
      setLoading(false)
      return
    }
    toast.success("Calculadora activada")
    router.refresh()
  }

  return (
    <div className="flex flex-col gap-4 max-w-2xl">
      <Link
        href={`/consultas/${consultaId}`}
        className="text-sm text-muted-foreground hover:underline w-fit"
      >
        ← Volver a la consulta
      </Link>
      <Card>
        <CardContent className="pt-6 flex flex-col gap-4 text-center items-center">
          <h1 className="font-heading font-bold text-xl">
            Calculadora interactiva · {clienteNombre}
          </h1>
          <p className="text-sm text-muted-foreground max-w-md">
            Simula escenarios de pensión en vivo con los datos reales del cliente:
            edad de retiro, salario de cotización, Modalidad 40 retroactiva,
            recuperación de semanas y más.
          </p>
          <Button type="button" onClick={activar} disabled={loading}>
            {loading
              ? "Activando…"
              : `Activa la calculadora interactiva por ${precioCreditos} crédito${precioCreditos === 1 ? "" : "s"}`}
          </Button>
          <p className="text-xs text-muted-foreground">
            Se cobra una sola vez por consulta. Acceso permanente para esta consulta.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
