export const dynamic = "force-dynamic"

import type { Metadata } from "next"
import Link from "next/link"
import { notFound, redirect } from "next/navigation"

import { createClient } from "@/lib/supabase/server"
import { parseSemillaV2 } from "@/lib/imss/semilla"
import { ActivarCalculadora } from "./activar-calculadora"
import { CalculadoraClient, type SaldosCorregidos } from "./calculadora-client"
import type { ResumenClienteData } from "@/components/resumen-cliente"

export async function generateMetadata({
  params,
}: {
  params: { id: string }
}): Promise<Metadata> {
  const supabase = await createClient()
  const { data } = await supabase
    .from("partner_transactions")
    .select("nombre, apellidos")
    .eq("id", params.id)
    .maybeSingle()

  const nombre = [data?.nombre, data?.apellidos]
    .filter(Boolean)
    .join(" ")
    .trim()

  return { title: nombre || "Consulta" }
}

export default async function CalculadoraPage({
  params,
}: {
  params: { id: string }
}) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) redirect("/login")

  const { data: partner } = await supabase
    .from("partners")
    .select("id, is_admin")
    .eq("auth_user_id", user.id)
    .single()
  if (!partner) redirect("/login")

  let query = supabase
    .from("partner_transactions")
    .select(
      "id, partner_id, nombre, apellidos, curp, status, calculo_pensional, calculadora_activada_at, resultado_resumen, saldos_corregidos, products(code, name)"
    )
    .eq("id", params.id)
  if (!partner.is_admin) query = query.eq("partner_id", partner.id)

  const { data: consulta, error } = await query.single()
  if (!consulta || error) notFound()

  // Branding del aliado dueño de la consulta (no del usuario logueado).
  // NULL = paleta Trol por defecto.
  const { data: ownerPartner } = await supabase
    .from("partners")
    .select("branding")
    .eq("id", consulta.partner_id)
    .maybeSingle()

  const branding = parseBranding(ownerPartner?.branding ?? null)

  const semilla = parseSemillaV2(consulta.calculo_pensional)

  if (!semilla) {
    return (
      <div className="flex flex-col gap-4 max-w-2xl">
        <Link
          href={`/consultas/${params.id}`}
          className="text-sm text-muted-foreground hover:underline"
        >
          ← Volver a la consulta
        </Link>
        <div className="rounded-lg border bg-muted/40 p-8 text-center flex flex-col gap-2">
          <h1 className="font-heading font-bold text-xl">
            Calculadora no disponible para esta consulta
          </h1>
          <p className="text-sm text-muted-foreground">
            Esta consulta no tiene los datos de cálculo necesarios (semilla v2).
            Las consultas generadas a partir de junio 2026 (checkup, diagnóstico
            y diagnóstico avanzado) la incluyen automáticamente; para consultas
            anteriores, genera una consulta nueva.
          </p>
        </div>
      </div>
    )
  }

  const clienteNombre =
    [consulta.nombre, consulta.apellidos].filter(Boolean).join(" ") ||
    semilla.perfil.nombre

  // Add-on no activado: pantalla de activación (cobra créditos vía RPC)
  if (!consulta.calculadora_activada_at) {
    const { data: addon } = await supabase
      .from("products")
      .select("price_credits")
      .eq("code", "CALCULADORA_ADDON")
      .eq("active", true)
      .single()

    return (
      <ActivarCalculadora
        consultaId={consulta.id}
        precioCreditos={addon?.price_credits ?? 2}
        clienteNombre={clienteNombre}
      />
    )
  }

  // Mod 40 aplica si la consulta detectó alguna sub-oportunidad de Mod 40
  // retroactiva (hoy o futura); si no hay resumen, cae al flag de la semilla.
  const subs = (
    consulta.resultado_resumen as {
      sub_oportunidades?: {
        mod40_retroactiva_hoy?: boolean | null
        mod40_retroactiva_futura?: boolean | null
      } | null
    } | null
  )?.sub_oportunidades
  const mod40Aplica =
    subs?.mod40_retroactiva_hoy === true ||
    subs?.mod40_retroactiva_futura === true ||
    semilla.perfil.aplica_mod40 === true

  return (
    <CalculadoraClient
      consultaId={consulta.id}
      clienteNombre={clienteNombre}
      semilla={semilla}
      branding={branding}
      mod40Aplica={mod40Aplica}
      resumen={consulta.resultado_resumen as ResumenClienteData | null}
      calculoPensional={consulta.calculo_pensional}
      saldosCorregidos={consulta.saldos_corregidos as SaldosCorregidos | null}
      guardarScope="consulta"
    />
  )
}

type Branding = {
  colorPrimario: string
  colorAcento: string
  logoUrl: string | null
}

const TROL_BRANDING: Branding = {
  colorPrimario: "#0f172a",
  colorAcento: "#a3e635",
  logoUrl: null,
}

function parseBranding(raw: unknown): Branding {
  if (!raw || typeof raw !== "object") return TROL_BRANDING
  const b = raw as Record<string, unknown>
  const primario = typeof b.color_primario === "string" ? b.color_primario : null
  const acento = typeof b.color_acento === "string" ? b.color_acento : null
  const logo = typeof b.logo_url === "string" ? b.logo_url : null
  return {
    colorPrimario: isHexColor(primario) ? primario! : TROL_BRANDING.colorPrimario,
    colorAcento: isHexColor(acento) ? acento! : TROL_BRANDING.colorAcento,
    logoUrl: logo && logo.startsWith("https://") ? logo : null,
  }
}

function isHexColor(s: string | null): boolean {
  return !!s && /^#[0-9a-fA-F]{3,8}$/.test(s)
}
