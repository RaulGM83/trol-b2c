export const dynamic = "force-dynamic"

import type { Metadata } from "next"
import { redirect, notFound } from "next/navigation"

import { createClient } from "@/lib/supabase/server"
import { isAdvisor } from "@/lib/auth/roles"
import { ConsultaDetalleClient } from "./consulta-detalle-client"

export async function generateMetadata({
  params,
}: {
  params: { id: string }
}): Promise<Metadata> {
  const supabase = await createClient()
  const { data } = await supabase
    .from("partner_transactions")
    .select("nombre, apellidos")
    .eq("id", params.id)
    .maybeSingle()

  const nombre = [data?.nombre, data?.apellidos]
    .filter(Boolean)
    .join(" ")
    .trim()

  return { title: nombre || "Consulta" }
}

export default async function ConsultaDetallePage({
  params,
}: {
  params: { id: string }
}) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: partner } = await supabase
    .from("partners")
    .select("id, is_admin, preview_doc_avanzado")
    .eq("auth_user_id", user.id)
    .single()

  if (!partner) {
    redirect("/login")
  }

  const isAdmin = !!partner.is_admin
  const advisor = await isAdvisor(supabase)

  // Asesor/admin pueden ver cualquier consulta (RLS: partner_tx_select_advisor).
  // Un aliado regular solo las suyas.
  let consultaQuery = supabase
    .from("partner_transactions")
    .select(`*, products(code, name, description, delivery_mode)`)
    .eq("id", params.id)

  if (!advisor) {
    consultaQuery = consultaQuery.eq("partner_id", partner.id)
  }

  const { data: consulta, error } = await consultaQuery.single()

  if (!consulta || error) {
    notFound()
  }

  // Quien ve es dueño de la consulta. Las acciones de dueño (p. ej. Delegar)
  // se ocultan cuando un asesor/admin la ve en modo solo lectura.
  const isOwner = consulta.partner_id === partner.id

  // Vista previa del Diagnóstico Avanzado antes de que Trol valide (status
  // "Doc previo listo"): solo para aliados con el flag, y para Trol (admin /
  // asesor), que es justamente quien valida.
  const canPreviewAvanzado = !!partner.preview_doc_avanzado || isAdmin || advisor

  const { data: delegation } = await supabase
    .from("delegations")
    .select("*")
    .eq("partner_transaction_id", params.id)
    .not("status", "in", '("closed_won","closed_lost")')
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle()

  // Productos destino para "Ampliar" — sus precios permiten calcular la diferencia
  // de créditos en el cliente (precio_destino − price_credits de la línea).
  const { data: upgradeTargets } = await supabase
    .from("products")
    .select("code, name, price_credits, sla_minutes, delivery_mode")
    .in("code", ["DIAGNOSTICO_AVANZADO", "DIAGNOSTICO_AVANZADO_SESION"])
    .order("price_credits", { ascending: true })

  // Producto original de una línea ampliada (para el tooltip del badge "Ampliada").
  let upgradedFromProduct: { code: string | null; name: string | null } | null = null
  if (consulta.upgraded_from_product_id) {
    const { data: fromProd } = await supabase
      .from("products")
      .select("code, name")
      .eq("id", consulta.upgraded_from_product_id)
      .maybeSingle()
    upgradedFromProduct = fromProd ?? null
  }

  return (
    <ConsultaDetalleClient
      consulta={consulta}
      delegation={delegation}
      isAdmin={isAdmin}
      isOwner={isOwner}
      isAdvisor={advisor}
      canPreviewAvanzado={canPreviewAvanzado}
      upgradeTargets={upgradeTargets ?? []}
      upgradedFromProduct={upgradedFromProduct}
    />
  )
}
