"use client"

import { useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { toast } from "sonner"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import type { ProductoCatalogo } from "./page"

const consultaSchema = z.object({
  nombre_cliente: z.string().min(1, "Requerido"),
  apellido_paterno: z.string().min(1, "Requerido"),
  apellido_materno: z.string().min(1, "Requerido"),
  curp: z
    .string()
    .transform((v) => v.toUpperCase().trim())
    .pipe(z.string().length(18, "La CURP debe tener 18 caracteres")),
  asesor_canal: z.string().min(1, "Requerido"),
  consentimiento_cliente: z
    .boolean()
    .refine((v) => v === true, {
      message: "Debes confirmar el visto bueno del cliente",
    }),
})

type ConsultaValues = z.infer<typeof consultaSchema>

function formatSla(minutes: number | null) {
  if (!minutes || minutes <= 0) return "—"
  if (minutes < 60) return `${minutes} minutos`
  const hours = minutes / 60
  if (hours < 24) return `${Math.round(hours)} horas`
  const days = Math.round(hours / 24)
  return `${days} ${days === 1 ? "día" : "días"}`
}

type Props = {
  products: ProductoCatalogo[]
  balance: number
}

export function NuevaConsultaForm({ products, balance }: Props) {
  const router = useRouter()
  const [selectedId, setSelectedId] = useState<string | null>(null)

  const selectedProduct = useMemo(
    () => products.find((p) => p.id === selectedId) ?? null,
    [products, selectedId]
  )

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting, isValid },
    setValue,
    watch,
  } = useForm<ConsultaValues>({
    resolver: zodResolver(consultaSchema),
    mode: "onChange",
    defaultValues: {
      nombre_cliente: "",
      apellido_paterno: "",
      apellido_materno: "",
      curp: "",
      asesor_canal: "",
      consentimiento_cliente: false,
    },
  })

  const consentimiento = watch("consentimiento_cliente")

  const onSubmit = async (values: ConsultaValues) => {
    if (!selectedProduct) {
      toast.error("Selecciona un producto")
      return
    }

    const supabase = createClient()
    const { error } = await supabase.rpc("create_consulta", {
      p_product_code: selectedProduct.code,
      p_inputs: values,
    })

    if (error) {
      if (error.code === "P0003") {
        toast.error("Saldo insuficiente para este producto")
      } else if (error.code === "P0001") {
        toast.error("No se encontró tu cuenta")
      } else if (error.code === "P0002") {
        toast.error("Producto no disponible")
      } else {
        toast.error(error.message)
      }
      return
    }

    toast.success("Consulta creada. Te avisaremos cuando esté lista.")
    router.push("/consultas")
    router.refresh()
  }

  return (
    <div className="flex justify-center">
      <Card className="w-full max-w-[920px]">
        <CardContent className="flex flex-col gap-8 py-2">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h1 className="font-heading text-2xl font-medium">
                Nueva consulta
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Selecciona el producto y captura los datos del cliente
              </p>
            </div>
            <div className="text-xs text-muted-foreground whitespace-nowrap pt-2">
              Saldo:{" "}
              <span className="font-semibold text-foreground">
                {balance} créditos
              </span>
            </div>
          </div>

          <section className="flex flex-col gap-3">
            <h2 className="font-heading text-base font-medium">
              Selecciona el producto
            </h2>

            <div className="grid gap-4 lg:grid-cols-3">
              {products.map((product) => {
                const insufficient = balance < product.price_credits
                const isSelected = selectedId === product.id
                const mxn = product.price_credits * 20

                return (
                  <button
                    key={product.id}
                    type="button"
                    disabled={insufficient}
                    onClick={() => setSelectedId(product.id)}
                    className={[
                      "text-left rounded-3xl border-2 p-5 transition-all flex flex-col gap-3",
                      insufficient
                        ? "opacity-50 cursor-not-allowed border-border"
                        : "cursor-pointer hover:border-primary/40",
                      isSelected
                        ? "border-primary bg-primary/5"
                        : "border-border bg-card",
                    ].join(" ")}
                  >
                    <div className="flex flex-col gap-1">
                      <div className="font-semibold text-lg">
                        {product.name}
                      </div>
                      {product.description && (
                        <p className="text-sm text-muted-foreground">
                          {product.description}
                        </p>
                      )}
                    </div>

                    <div className="flex flex-col gap-0.5">
                      <div className="text-xl font-bold">
                        {product.price_credits} créditos
                      </div>
                      <div className="text-xs text-muted-foreground">
                        ≈ ${mxn.toLocaleString("es-MX")} MXN
                      </div>
                    </div>

                    <div className="text-sm text-muted-foreground">
                      Entrega en {formatSla(product.sla_minutes)}
                    </div>

                    {product.delivery_mode === "mixed_with_session" && (
                      <span className="inline-flex w-fit items-center rounded-full bg-violet-100 px-2 py-0.5 text-xs font-medium text-violet-800 dark:bg-violet-500/15 dark:text-violet-300">
                        Incluye sesión con experto
                      </span>
                    )}

                    {insufficient && (
                      <div className="text-xs font-medium text-destructive">
                        Saldo insuficiente
                      </div>
                    )}
                  </button>
                )
              })}
            </div>
          </section>

          {selectedProduct && (
            <section className="flex flex-col gap-4">
              <h2 className="font-heading text-base font-medium">
                Datos del cliente
              </h2>

              <form
                onSubmit={handleSubmit(onSubmit)}
                className="flex flex-col gap-4"
              >
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="flex flex-col gap-2">
                    <Label htmlFor="nombre_cliente">
                      Nombre(s) del cliente
                    </Label>
                    <Input
                      id="nombre_cliente"
                      placeholder="María"
                      {...register("nombre_cliente")}
                    />
                    {errors.nombre_cliente && (
                      <p className="text-sm text-destructive">
                        {errors.nombre_cliente.message}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col gap-2">
                    <Label htmlFor="apellido_paterno">Apellido paterno</Label>
                    <Input
                      id="apellido_paterno"
                      placeholder="González"
                      {...register("apellido_paterno")}
                    />
                    {errors.apellido_paterno && (
                      <p className="text-sm text-destructive">
                        {errors.apellido_paterno.message}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col gap-2">
                    <Label htmlFor="apellido_materno">Apellido materno</Label>
                    <Input
                      id="apellido_materno"
                      placeholder="López"
                      {...register("apellido_materno")}
                    />
                    {errors.apellido_materno && (
                      <p className="text-sm text-destructive">
                        {errors.apellido_materno.message}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col gap-2 sm:col-span-2">
                    <Label htmlFor="curp">CURP</Label>
                    <Input
                      id="curp"
                      placeholder="GOLM800101HDFLNS04"
                      maxLength={18}
                      className="uppercase font-mono"
                      {...register("curp")}
                    />
                    {errors.curp && (
                      <p className="text-sm text-destructive">
                        {errors.curp.message}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col gap-2">
                    <Label htmlFor="asesor_canal">
                      Asesor o canal que atiende
                    </Label>
                    <Input
                      id="asesor_canal"
                      placeholder="Sucursal Centro / Juan P."
                      {...register("asesor_canal")}
                    />
                    {errors.asesor_canal && (
                      <p className="text-sm text-destructive">
                        {errors.asesor_canal.message}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      className="mt-1 size-4 rounded border-border accent-primary"
                      checked={consentimiento}
                      onChange={(e) =>
                        setValue(
                          "consentimiento_cliente",
                          e.target.checked,
                          { shouldValidate: true }
                        )
                      }
                    />
                    <span className="text-sm">
                      Confirmo que el cliente está enterado y dio su visto
                      bueno para procesar esta consulta con sus datos.
                    </span>
                  </label>
                  {errors.consentimiento_cliente && (
                    <p className="text-sm text-destructive">
                      {errors.consentimiento_cliente.message}
                    </p>
                  )}
                </div>

                <div className="flex justify-end pt-2">
                  <Button
                    type="submit"
                    size="lg"
                    disabled={!selectedProduct || !isValid || isSubmitting}
                  >
                    {isSubmitting
                      ? "Creando..."
                      : `Crear consulta y cobrar ${selectedProduct.price_credits} créditos`}
                  </Button>
                </div>
              </form>
            </section>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
