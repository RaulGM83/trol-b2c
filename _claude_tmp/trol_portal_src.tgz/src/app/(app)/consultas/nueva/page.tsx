export const dynamic = "force-dynamic"

import { redirect } from "next/navigation"

import { createClient } from "@/lib/supabase/server"
import { NuevaConsultaForm } from "./nueva-consulta-form"

import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Nueva consulta",
  description: "Genera una consulta de diagnóstico pensional para un cliente.",
}

export type ProductoCatalogo = {
  id: string
  code: string
  name: string
  description: string | null
  price_credits: number
  sla_minutes: number | null
  delivery_mode: string | null
  active: boolean
}

export default async function NuevaConsultaPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: partner } = await supabase
    .from("partners")
    .select("id, balance_credits")
    .eq("auth_user_id", user.id)
    .single()

  if (!partner) {
    redirect("/login")
  }

  const { data: products } = await supabase
    .from("products")
    .select("id, code, name, description, price_credits, sla_minutes, delivery_mode, active")
    .eq("active", true)
    .neq("delivery_mode", "addon")
    .order("price_credits", { ascending: true })

  const balance = Number(partner.balance_credits ?? 0)

  return (
    <NuevaConsultaForm
      products={(products ?? []) as ProductoCatalogo[]}
      balance={balance}
    />
  )
}
