export const dynamic = "force-dynamic"

import { redirect } from "next/navigation"
import Link from "next/link"
import { ClipboardList, ArrowUpCircle, RefreshCw } from "lucide-react"

import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
} from "@/components/ui/card"
import {
  getStatusInfo,
  getStatusBadgeClasses,
  getSourceInfo,
  isErrorStatus,
  parseErrorDetail,
} from "@/lib/consulta-status"
import { getSLADisplay } from "@/lib/consulta-sla"
import { maskCurp } from "@/lib/curp"
import SearchBox from "./search-box"

import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Consultas",
  description: "Todas tus consultas de diagnóstico pensional.",
}

type ProductRef = {
  code: string | null
  name: string | null
}

type PartnerRef = {
  name: string | null
  business_name: string | null
}

type ConsultaRow = {
  id: string
  created_at: string
  updated_at: string | null
  completed_at: string | null
  status: string | null
  error_detail: string | null
  source: string | null
  nombre: string | null
  apellidos: string | null
  curp: string | null
  due_at: string | null
  price_credits: number | null
  product_id: string | null
  partner_id: string | null
  upgraded_at: string | null
  datos_actualizados_at: string | null
  products: ProductRef | ProductRef[] | null
  partners: PartnerRef | PartnerRef[] | null
}

function formatFecha(iso: string) {
  return new Intl.DateTimeFormat("es-MX", {
    day: "numeric",
    month: "short",
    year: "numeric",
  })
    .format(new Date(iso))
    .replace(/\./g, "")
}

function pickProduct(p: ConsultaRow["products"]): ProductRef | null {
  if (!p) return null
  if (Array.isArray(p)) return p[0] ?? null
  return p
}

function pickPartner(p: ConsultaRow["partners"]): PartnerRef | null {
  if (!p) return null
  if (Array.isArray(p)) return p[0] ?? null
  return p
}

function renderStatusBadge(status: string | null, errorDetail: string | null) {
  const info = getStatusInfo(status ?? "")
  const cls = getStatusBadgeClasses(info.variant)
  // En error el badge lleva el motivo como tooltip; así el aliado ve por qué
  // falló sin abrir el detalle.
  const motivo = isErrorStatus(status) ? parseErrorDetail(errorDetail) : null
  return (
    <span
      className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${cls}${
        motivo ? " cursor-help" : ""
      }`}
      title={motivo ?? undefined}
    >
      {info.label}
    </span>
  )
}

function renderSla(row: ConsultaRow) {
  const sla = getSLADisplay({
    created_at: row.created_at,
    due_at: row.due_at,
    completed_at: row.completed_at,
    updated_at: row.updated_at,
    status: row.status ?? "",
  })
  return (
    <div className="flex flex-col gap-0.5">
      <span className={sla.classes}>{sla.label}</span>
      {sla.badge && (
        <span className={`text-xs ${sla.classes}`}>{sla.badge}</span>
      )}
    </div>
  )
}

export default async function ConsultasPage({
  searchParams,
}: {
  searchParams: { q?: string }
}) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: partner } = await supabase
    .from("partners")
    .select("id, is_admin")
    .eq("auth_user_id", user.id)
    .single()

  if (!partner) {
    redirect("/login")
  }

  const isAdmin = !!partner.is_admin
  const q = (searchParams.q ?? "").trim()

  let query = supabase
    .from("partner_transactions")
    .select(
      "id, created_at, updated_at, completed_at, status, error_detail, source, nombre, apellidos, curp, due_at, price_credits, product_id, partner_id, upgraded_at, datos_actualizados_at, products(code, name), partners(name, business_name)"
    )
    .order("created_at", { ascending: false })
    .limit(isAdmin ? 200 : 50)

  // Solo filtramos por partner_id si NO es admin.
  // El admin ve todas las consultas de todos los aliados.
  if (!isAdmin) {
    query = query.eq("partner_id", partner.id)
  }

  if (q) {
    query = query.or(
      `curp.ilike.%${q}%,nombre.ilike.%${q}%,apellidos.ilike.%${q}%`
    )
  }

  const { data: consultas } = await query

  const rows = (consultas ?? []) as ConsultaRow[]
  const isEmpty = rows.length === 0
  const hasQuery = q.length > 0

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="font-heading text-2xl font-medium">
            Consultas
            {isAdmin && (
              <span className="ml-2 inline-flex items-center rounded-full bg-amber-100 text-amber-900 px-2 py-0.5 text-xs font-semibold uppercase tracking-wide align-middle">
                Admin
              </span>
            )}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {isAdmin
              ? "Vista de operador: todas las consultas de todos los aliados"
              : "Histórico de consultas que has solicitado al equipo Trol"}
          </p>
        </div>

        {(!isEmpty || hasQuery) && (
          <Button asChild>
            <Link href="/consultas/nueva">+ Nueva consulta</Link>
          </Button>
        )}
      </div>

      {(!isEmpty || hasQuery) && (
        <div className="mb-4">
          <SearchBox />
        </div>
      )}

      {isEmpty && !hasQuery ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center text-center py-16 gap-4">
            <div className="rounded-full bg-muted p-4">
              <ClipboardList className="size-8 text-muted-foreground" />
            </div>
            <div className="flex flex-col gap-1">
              <h2 className="font-heading text-lg font-medium">
                {isAdmin
                  ? "Aún no hay consultas en la plataforma"
                  : "Aún no has creado ninguna consulta"}
              </h2>
              <p className="text-sm text-muted-foreground">
                {isAdmin
                  ? "Cuando un aliado registre una consulta, aparecerá aquí"
                  : "Empieza creando una para tu primer cliente"}
              </p>
            </div>
            {!isAdmin && (
              <Button asChild size="lg" className="mt-2">
                <Link href="/consultas/nueva">+ Crear primera consulta</Link>
              </Button>
            )}
          </CardContent>
        </Card>
      ) : isEmpty && hasQuery ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center text-center py-16 gap-4">
            <div className="rounded-full bg-muted p-4">
              <ClipboardList className="size-8 text-muted-foreground" />
            </div>
            <div className="flex flex-col gap-1">
              <h2 className="font-heading text-lg font-medium">
                Sin resultados para «{q}»
              </h2>
              <p className="text-sm text-muted-foreground">
                Prueba con un CURP, nombre o apellido distinto
              </p>
            </div>
            <Button asChild variant="outline" size="lg" className="mt-2">
              <Link href="/consultas">Limpiar búsqueda</Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="px-0">
            {hasQuery && (
              <div className="px-6 pt-4 pb-2 text-xs text-muted-foreground">
                {rows.length} resultado{rows.length === 1 ? "" : "s"} para «{q}»
              </div>
            )}
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="px-6 py-3 font-medium">Fecha</th>
                    {isAdmin && (
                      <th className="px-6 py-3 font-medium">Aliado</th>
                    )}
                    <th className="px-6 py-3 font-medium">Cliente</th>
                    <th className="px-6 py-3 font-medium">CURP</th>
                    <th className="px-6 py-3 font-medium">Producto</th>
                    <th className="px-6 py-3 font-medium">Costo</th>
                    <th className="px-6 py-3 font-medium">Status</th>
                    <th className="px-6 py-3 font-medium">SLA</th>
                    <th className="px-6 py-3 font-medium text-right">
                      Acción
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => {
                    const product = pickProduct(row.products)
                    const partnerRef = pickPartner(row.partners)
                    const aliado =
                      partnerRef?.business_name ||
                      partnerRef?.name ||
                      "—"
                    const cliente = [row.nombre, row.apellidos]
                      .filter(Boolean)
                      .join(" ")
                      .trim()
                    const sourceInfo = getSourceInfo(row.source)
                    return (
                      <tr
                        key={row.id}
                        className="border-b last:border-b-0 hover:bg-muted/40 transition-colors"
                      >
                        <td className="px-6 py-3 whitespace-nowrap">
                          {formatFecha(row.created_at)}
                        </td>
                        {isAdmin && (
                          <td className="px-6 py-3 whitespace-nowrap">
                            <span className="font-medium">{aliado}</span>
                          </td>
                        )}
                        <td className="px-6 py-3">
                          <div className="flex flex-col gap-1">
                            <span className="font-medium">{cliente || "—"}</span>
                            <span
                              className={`inline-flex items-center self-start rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase ${sourceInfo.classes}`}
                            >
                              {sourceInfo.label}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-3 font-mono text-xs text-muted-foreground">
                          {maskCurp(row.curp)}
                        </td>
                        <td className="px-6 py-3">
                          <div className="flex items-center gap-1.5">
                            <span>{product?.name ?? product?.code ?? "—"}</span>
                            {row.upgraded_at && (
                              <ArrowUpCircle
                                className="size-3.5 shrink-0 text-indigo-600 dark:text-indigo-400"
                                aria-label="Ampliada"
                              />
                            )}
                            {row.datos_actualizados_at && (
                              <RefreshCw
                                className="size-3.5 shrink-0 text-blue-600 dark:text-blue-400"
                                aria-label="Información actualizada"
                              />
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-3 whitespace-nowrap">
                          {row.price_credits ?? 0} créditos
                        </td>
                        <td className="px-6 py-3">
                          {renderStatusBadge(row.status, row.error_detail)}
                        </td>
                        <td className="px-6 py-3 whitespace-nowrap text-xs">
                          {renderSla(row)}
                        </td>
                        <td className="px-6 py-3 text-right whitespace-nowrap">
                          <Link
                            href={`/consultas/${row.id}`}
                            className="text-primary hover:underline text-sm"
                          >
                            Ver detalle →
                          </Link>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
