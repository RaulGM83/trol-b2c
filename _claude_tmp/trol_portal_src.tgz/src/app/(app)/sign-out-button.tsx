"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"

import { DropdownMenuItem } from "@/components/ui/dropdown-menu"

export function SignOutButton() {
  const router = useRouter()
  const [pending, setPending] = useState(false)

  async function handleSignOut() {
    if (pending) return
    setPending(true)
    try {
      // POST to the route handler so the SSR session cookies are cleared via
      // Set-Cookie. The browser applies those headers even though we ignore the
      // redirected body here.
      await fetch("/api/auth/signout", { method: "POST" })
    } catch {
      // Ignore network errors; we still navigate away and refresh below.
    } finally {
      router.replace("/login")
      router.refresh()
    }
  }

  return (
    <DropdownMenuItem
      // Prevent Radix from closing/unmounting the menu before our handler runs,
      // which is what stopped the previous <form> submit from firing.
      onSelect={(event) => {
        event.preventDefault()
        void handleSignOut()
      }}
      disabled={pending}
    >
      {pending ? "Cerrando sesión…" : "Cerrar sesión"}
    </DropdownMenuItem>
  )
}
