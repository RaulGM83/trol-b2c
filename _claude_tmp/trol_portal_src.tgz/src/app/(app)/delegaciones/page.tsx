import { redirect } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { getDelegationStatusInfo } from '@/lib/delegation-status'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Users, ChevronRight } from 'lucide-react'

import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Delegaciones",
  description: "Casos delegados al equipo Trol y su seguimiento.",
}

export const dynamic = "force-dynamic"

type PartnerRef = {
  name: string | null
  business_name: string | null
}

type DelegationRow = {
  id: string
  reason: string
  notes: string | null
  status: string
  cliente_email: string
  cliente_telefono: string
  created_at: string
  updated_at: string
  contacted_at: string | null
  closed_at: string | null
  partner_id: string | null
  partner_transaction_id: string
  partners: PartnerRef | PartnerRef[] | null
  partner_transactions: {
    id: string
    nombre: string | null
    apellidos: string | null
    curp: string | null
    status: string
  } | null
}

function pickPartner(p: DelegationRow["partners"]): PartnerRef | null {
  if (!p) return null
  if (Array.isArray(p)) return p[0] ?? null
  return p
}

export default async function DelegacionesPage({
  searchParams,
}: {
  searchParams: { status?: string }
}) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const { data: partner } = await supabase
    .from('partners')
    .select('id, is_admin')
    .eq('auth_user_id', user.id)
    .single()
  if (!partner) redirect('/login')

  const isAdmin = !!partner.is_admin

  let query = supabase
    .from('delegations')
    .select(`
      id, reason, notes, status,
      cliente_email, cliente_telefono,
      created_at, updated_at, contacted_at, closed_at,
      partner_id, partner_transaction_id,
      partners ( name, business_name ),
      partner_transactions ( id, nombre, apellidos, curp, status )
    `)
    .order('created_at', { ascending: false })
    .limit(isAdmin ? 200 : 100)

  // Solo filtramos por partner_id si NO es admin. El admin ve todo.
  if (!isAdmin) {
    query = query.eq('partner_id', partner.id)
  }

  const statusFilter = searchParams.status
  if (statusFilter === 'open') {
    query = query.not('status', 'in', '("closed_won","closed_lost")')
  } else if (statusFilter === 'closed') {
    query = query.in('status', ['closed_won', 'closed_lost'])
  } else if (statusFilter && ['requested', 'contacted', 'in_progress', 'closed_won', 'closed_lost'].includes(statusFilter)) {
    query = query.eq('status', statusFilter)
  }

  const { data: delegations } = await query

  const list = (delegations ?? []) as unknown as DelegationRow[]

  return (
    <div className="w-full max-w-[1200px] mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">
            Delegaciones
            {isAdmin && (
              <span className="ml-2 inline-flex items-center rounded-full bg-amber-100 text-amber-900 px-2 py-0.5 text-xs font-semibold uppercase tracking-wide align-middle">
                Admin
              </span>
            )}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {isAdmin
              ? "Vista de operador: todas las delegaciones de todos los aliados"
              : "Clientes que escalaste al equipo Trol para seguimiento directo"}
          </p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        <FilterChip href="/delegaciones" current={statusFilter} value={undefined} label="Todas" />
        <FilterChip href="/delegaciones?status=open" current={statusFilter} value="open" label="Abiertas" />
        <FilterChip href="/delegaciones?status=requested" current={statusFilter} value="requested" label="Solicitadas" />
        <FilterChip href="/delegaciones?status=contacted" current={statusFilter} value="contacted" label="Contactadas" />
        <FilterChip href="/delegaciones?status=in_progress" current={statusFilter} value="in_progress" label="En seguimiento" />
        <FilterChip href="/delegaciones?status=closed" current={statusFilter} value="closed" label="Cerradas" />
      </div>

      {list.length === 0 ? (
        <div className="text-center py-16 border border-dashed rounded-lg">
          <Users className="size-12 mx-auto text-muted-foreground mb-3" />
          <h3 className="font-medium">Sin delegaciones</h3>
          <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">
            {isAdmin
              ? "Cuando un aliado delegue una consulta, aparecerá aquí."
              : "Cuando delegues una consulta al equipo Trol, aparecerá aquí con su seguimiento."}
          </p>
        </div>
      ) : (
        <div className="border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Fecha</TableHead>
                {isAdmin && <TableHead>Aliado</TableHead>}
                <TableHead>Cliente</TableHead>
                <TableHead>Contacto</TableHead>
                <TableHead>Motivo</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Acción</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {list.map((d: DelegationRow) => {
                const consulta = d.partner_transactions
                const statusInfo = getDelegationStatusInfo(d.status)
                const fechaFmt = new Intl.DateTimeFormat('es-MX', {
                  day: 'numeric', month: 'short', year: 'numeric'
                }).format(new Date(d.created_at))
                const nombreCompleto = [consulta?.nombre, consulta?.apellidos].filter(Boolean).join(' ').trim() || '—'
                const curpMask = consulta?.curp ? consulta.curp.slice(0, 6) + '…' + consulta.curp.slice(-2) : '—'
                const partnerRef = pickPartner(d.partners)
                const aliado = partnerRef?.business_name || partnerRef?.name || '—'

                return (
                  <TableRow key={d.id}>
                    <TableCell className="whitespace-nowrap text-sm">{fechaFmt}</TableCell>
                    {isAdmin && (
                      <TableCell className="whitespace-nowrap text-sm">
                        <span className="font-medium">{aliado}</span>
                      </TableCell>
                    )}
                    <TableCell>
                      <div className="font-medium">{nombreCompleto}</div>
                      <div className="text-xs text-muted-foreground font-mono mt-0.5">{curpMask}</div>
                    </TableCell>
                    <TableCell className="text-sm">
                      <div><a href={`mailto:${d.cliente_email}`} className="text-foreground hover:underline">{d.cliente_email}</a></div>
                      <div className="text-xs text-muted-foreground mt-0.5">{d.cliente_telefono}</div>
                    </TableCell>
                    <TableCell className="max-w-xs">
                      <div className="text-sm truncate" title={d.reason}>{d.reason}</div>
                      {d.notes && <div className="text-xs text-muted-foreground truncate mt-0.5" title={d.notes}>{d.notes}</div>}
                    </TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${statusInfo.classes}`}>
                        {statusInfo.label}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Link href={`/consultas/${d.partner_transaction_id}`} className="inline-flex items-center text-sm text-primary hover:underline">
                        Ver consulta <ChevronRight className="size-3 ml-0.5" />
                      </Link>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  )
}

function FilterChip({ href, current, value, label }: { href: string, current: string | undefined, value: string | undefined, label: string }) {
  const isActive = (current ?? undefined) === value
  return (
    <Link
      href={href}
      className={
        "inline-flex items-center rounded-full px-3 py-1.5 text-sm font-medium transition-colors " +
        (isActive
          ? "bg-foreground text-background"
          : "bg-muted text-muted-foreground hover:bg-muted/80")
      }
    >
      {label}
    </Link>
  )
}
