import type { Metadata } from "next"

// La página es un client component, así que el título vive en este layout.
export const metadata: Metadata = {
  title: "Iniciar sesión",
  description: "Accede al portal de aliados Trol.",
}

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
