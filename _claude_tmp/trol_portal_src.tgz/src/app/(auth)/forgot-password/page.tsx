"use client"

import { useState } from "react"
import Link from "next/link"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const schema = z.object({
  email: z.string().email("Correo inválido"),
})

type Values = z.infer<typeof schema>

export default function ForgotPasswordPage() {
  const [sent, setSent] = useState(false)
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<Values>({ resolver: zodResolver(schema) })

  const onSubmit = async ({ email }: Values) => {
    const supabase = createClient()
    // Ignoramos el error a propósito: siempre mostramos un mensaje neutro
    // para no revelar si el correo existe.
    await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    })
    setSent(true)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recuperar contraseña</CardTitle>
        <CardDescription>
          Te enviaremos un enlace para restablecerla
        </CardDescription>
      </CardHeader>
      <CardContent>
        {sent ? (
          <div className="flex flex-col gap-4">
            <p className="text-sm text-muted-foreground">
              Si el correo existe, te enviamos un enlace para restablecer tu
              contraseña. Revisa tu bandeja de entrada y la carpeta de spam.
            </p>
            <Button asChild variant="outline">
              <Link href="/login">Volver a iniciar sesión</Link>
            </Button>
          </div>
        ) : (
          <>
            <form
              onSubmit={handleSubmit(onSubmit)}
              className="flex flex-col gap-4"
            >
              <div className="flex flex-col gap-2">
                <Label htmlFor="email">Correo electrónico</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="tu@empresa.com"
                  autoComplete="email"
                  {...register("email")}
                />
                {errors.email && (
                  <p className="text-sm text-destructive mt-1">
                    {errors.email.message}
                  </p>
                )}
              </div>

              <Button type="submit" disabled={isSubmitting} className="mt-2">
                {isSubmitting ? "Enviando..." : "Enviar enlace"}
              </Button>
            </form>

            <p className="text-sm text-center mt-6">
              <Link
                href="/login"
                className="text-muted-foreground hover:text-foreground hover:underline"
              >
                Volver a iniciar sesión
              </Link>
            </p>
          </>
        )}
      </CardContent>
    </Card>
  )
}
