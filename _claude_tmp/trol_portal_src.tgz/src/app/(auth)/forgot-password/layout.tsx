import type { Metadata } from "next"

// La página es un client component, así que el título vive en este layout.
export const metadata: Metadata = {
  title: "Recuperar contraseña",
  description: "Te enviamos un enlace para restablecer tu contraseña.",
}

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
