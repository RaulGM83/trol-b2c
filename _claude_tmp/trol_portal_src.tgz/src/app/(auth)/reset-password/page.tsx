"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { toast } from "sonner"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const schema = z
  .object({
    password: z.string().min(8, "Mínimo 8 caracteres"),
    confirm: z.string().min(8, "Mínimo 8 caracteres"),
  })
  .refine((v) => v.password === v.confirm, {
    message: "Las contraseñas no coinciden",
    path: ["confirm"],
  })

type Values = z.infer<typeof schema>

type Status = "checking" | "ready" | "expired"

export default function ResetPasswordPage() {
  const router = useRouter()
  const [status, setStatus] = useState<Status>("checking")
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<Values>({ resolver: zodResolver(schema) })

  useEffect(() => {
    const supabase = createClient()
    let resolved = false

    // El cliente del navegador detecta el token de recuperación en la URL
    // (hash o ?code=) y dispara PASSWORD_RECOVERY / establece la sesión.
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY" || session) {
        resolved = true
        setStatus("ready")
      }
    })

    // Respaldo: si ya hay sesión cargada al montar.
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) {
        resolved = true
        setStatus("ready")
      }
    })

    // Si tras unos segundos no se estableció sesión, el enlace expiró/es inválido.
    const timer = setTimeout(() => {
      if (!resolved) setStatus("expired")
    }, 4000)

    return () => {
      subscription.unsubscribe()
      clearTimeout(timer)
    }
  }, [])

  const onSubmit = async ({ password }: Values) => {
    const supabase = createClient()
    const { error } = await supabase.auth.updateUser({ password })
    if (error) {
      toast.error(error.message)
      return
    }
    toast.success("Contraseña actualizada")
    router.push("/dashboard")
    router.refresh()
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Nueva contraseña</CardTitle>
        <CardDescription>
          {status === "ready"
            ? "Elige una contraseña nueva para tu cuenta"
            : "Restablece el acceso a tu cuenta"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {status === "checking" && (
          <p className="text-sm text-muted-foreground">Validando enlace...</p>
        )}

        {status === "expired" && (
          <div className="flex flex-col gap-4">
            <p className="text-sm text-destructive">
              El enlace de recuperación no es válido o ya expiró. Solicita uno
              nuevo.
            </p>
            <Button asChild variant="outline">
              <Link href="/forgot-password">Solicitar nuevo enlace</Link>
            </Button>
          </div>
        )}

        {status === "ready" && (
          <form
            onSubmit={handleSubmit(onSubmit)}
            className="flex flex-col gap-4"
          >
            <div className="flex flex-col gap-2">
              <Label htmlFor="password">Nueva contraseña</Label>
              <Input
                id="password"
                type="password"
                autoComplete="new-password"
                {...register("password")}
              />
              {errors.password && (
                <p className="text-sm text-destructive mt-1">
                  {errors.password.message}
                </p>
              )}
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="confirm">Confirmar contraseña</Label>
              <Input
                id="confirm"
                type="password"
                autoComplete="new-password"
                {...register("confirm")}
              />
              {errors.confirm && (
                <p className="text-sm text-destructive mt-1">
                  {errors.confirm.message}
                </p>
              )}
            </div>

            <Button type="submit" disabled={isSubmitting} className="mt-2">
              {isSubmitting ? "Guardando..." : "Guardar contraseña"}
            </Button>
          </form>
        )}
      </CardContent>
    </Card>
  )
}
