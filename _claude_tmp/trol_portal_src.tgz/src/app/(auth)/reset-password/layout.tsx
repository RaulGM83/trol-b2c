import type { Metadata } from "next"

// La página es un client component, así que el título vive en este layout.
export const metadata: Metadata = {
  title: "Nueva contraseña",
  description: "Define una nueva contraseña para tu cuenta.",
}

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
