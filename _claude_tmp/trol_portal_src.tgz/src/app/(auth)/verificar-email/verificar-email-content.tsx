"use client"

import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { useState } from "react"
import { toast } from "sonner"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

export default function VerificarEmailContent() {
  const searchParams = useSearchParams()
  const email = searchParams.get("email") ?? ""
  const [isResending, setIsResending] = useState(false)

  const handleResend = async () => {
    if (!email) {
      toast.error("No encontramos tu correo. Regresa al registro.")
      return
    }

    setIsResending(true)
    const supabase = createClient()
    const { error } = await supabase.auth.resend({
      type: "signup",
      email,
    })
    setIsResending(false)

    if (error) {
      toast.error(error.message)
      return
    }

    toast.success("Correo reenviado")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Verifica tu correo</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <p className="text-sm">
          Te enviamos un correo a{" "}
          <span className="font-medium text-foreground">
            {email || "tu dirección"}
          </span>
          . Haz click en el link de verificación para activar tu cuenta y entrar
          al portal.
        </p>
        <p className="text-sm text-muted-foreground">
          Si no lo encuentras, revisa tu carpeta de spam.
        </p>

        <Button
          type="button"
          onClick={handleResend}
          disabled={isResending}
          className="mt-2"
        >
          {isResending ? "Cargando..." : "Reenviar correo"}
        </Button>

        <p className="text-sm text-center mt-2">
          <Link href="/login" className="text-primary hover:underline">
            Regresar a inicio de sesión
          </Link>
        </p>
      </CardContent>
    </Card>
  )
}
