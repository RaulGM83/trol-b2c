import { Suspense } from "react"
import VerificarEmailContent from "./verificar-email-content"

import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Verifica tu correo",
  description: "Confirma tu dirección de correo para activar tu cuenta.",
}

export default function VerificarEmailPage() {
  return (
    <Suspense fallback={null}>
      <VerificarEmailContent />
    </Suspense>
  )
}
