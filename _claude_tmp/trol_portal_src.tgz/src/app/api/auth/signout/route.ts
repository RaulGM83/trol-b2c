import { createServerClient } from "@supabase/ssr"
import { NextResponse, type NextRequest } from "next/server"

export async function POST(request: NextRequest) {
  // Build the redirect response up front so the Supabase server client can
  // attach the session-cookie deletions (Set-Cookie) directly to it. Writing
  // cookies via next/headers from a route handler does not reliably merge onto
  // a manually constructed NextResponse, which is why the SSR session survived.
  const response = NextResponse.redirect(new URL("/login", request.url), {
    status: 303,
  })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll()
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value, options }) =>
            response.cookies.set(name, value, options)
          )
        },
      },
    }
  )

  await supabase.auth.signOut()

  return response
}
