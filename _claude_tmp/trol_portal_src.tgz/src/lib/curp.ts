/** Enmascara una CURP para listados (deja prefijo y sufijo visibles). */
export function maskCurp(curp: string | null | undefined): string {
  if (!curp) return "—"
  if (curp.length <= 8) return curp
  return `${curp.slice(0, 6)}…${curp.slice(-2)}`
}
