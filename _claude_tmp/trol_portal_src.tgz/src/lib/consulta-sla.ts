import { getStatusInfo } from './consulta-status'

type ConsultaSLAInput = {
  created_at: string | Date
  due_at: string | Date | null
  completed_at?: string | Date | null
  updated_at?: string | Date | null
  status: string
}

export type SLADisplay = {
  type: 'pending' | 'overdue' | 'completed_on_time' | 'completed_late' | 'failed' | 'na'
  label: string
  badge?: string
  classes: string
}

export function formatDuration(ms: number): string {
  if (ms < 0) ms = Math.abs(ms)
  const totalSeconds = Math.floor(ms / 1000)
  const hours = Math.floor(totalSeconds / 3600)
  const minutes = Math.floor((totalSeconds % 3600) / 60)
  const seconds = totalSeconds % 60
  if (hours > 0) return `${hours}h ${minutes}m`
  if (minutes > 0) return `${minutes}m ${seconds}s`
  return `${seconds}s`
}

export function getSLADisplay(consulta: ConsultaSLAInput): SLADisplay {
  const statusInfo = getStatusInfo(consulta.status)
  const dueAt = consulta.due_at ? new Date(consulta.due_at).getTime() : null
  const createdAt = new Date(consulta.created_at).getTime()
  const now = Date.now()

  if (statusInfo.isTerminal) {
    const completionRaw = consulta.completed_at ?? consulta.updated_at
    if (!completionRaw) {
      return { type: 'na', label: '—', classes: 'text-muted-foreground' }
    }
    const completedAt = new Date(completionRaw).getTime()
    const duration = completedAt - createdAt

    if (statusInfo.isFailure) {
      return {
        type: 'failed',
        label: `Falló en ${formatDuration(duration)}`,
        classes: 'text-red-600 dark:text-red-400'
      }
    }

    // Sin due_at (consultas legacy/API sin SLA definido): no hay SLA que medir,
    // solo mostramos que se completó (sin badge de cumplimiento).
    if (!dueAt) {
      return {
        type: 'completed_on_time',
        label: `Completada en ${formatDuration(duration)}`,
        classes: 'text-green-700 dark:text-green-400'
      }
    }

    if (completedAt <= dueAt) {
      return {
        type: 'completed_on_time',
        label: `Completada en ${formatDuration(duration)}`,
        badge: '✓ Cumplió SLA',
        classes: 'text-green-700 dark:text-green-400'
      }
    } else {
      return {
        type: 'completed_late',
        label: `Completada en ${formatDuration(duration)}`,
        badge: '⚠ Fuera de SLA',
        classes: 'text-amber-700 dark:text-amber-400'
      }
    }
  }

  if (!dueAt) {
    return { type: 'na', label: '—', classes: 'text-muted-foreground' }
  }

  const remaining = dueAt - now
  if (remaining > 0) {
    return {
      type: 'pending',
      label: `Entrega en ${formatDuration(remaining)}`,
      classes: 'text-muted-foreground'
    }
  } else {
    return {
      type: 'overdue',
      label: `Vencida hace ${formatDuration(-remaining)}`,
      classes: 'text-red-600 dark:text-red-400'
    }
  }
}
