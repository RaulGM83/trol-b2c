export type DelegationStatusVariant = 'gris' | 'azul' | 'ambar' | 'verde' | 'rojo'

export type DelegationStatusInfo = {
  label: string
  variant: DelegationStatusVariant
  classes: string
  isClosed: boolean
}

export function getDelegationStatusInfo(status: string): DelegationStatusInfo {
  switch (status) {
    case 'requested':
      return { label: 'Solicitada', variant: 'gris', classes: 'bg-gray-100 text-gray-700 dark:bg-gray-500/15 dark:text-gray-300', isClosed: false }
    case 'contacted':
      return { label: 'Contactada', variant: 'azul', classes: 'bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300', isClosed: false }
    case 'in_progress':
      return { label: 'En seguimiento', variant: 'ambar', classes: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300', isClosed: false }
    case 'closed_won':
      return { label: 'Cerrada (ganada)', variant: 'verde', classes: 'bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300', isClosed: true }
    case 'closed_lost':
      return { label: 'Cerrada (sin venta)', variant: 'rojo', classes: 'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300', isClosed: true }
    default:
      return { label: status || 'Desconocido', variant: 'gris', classes: 'bg-gray-100 text-gray-500', isClosed: false }
  }
}
