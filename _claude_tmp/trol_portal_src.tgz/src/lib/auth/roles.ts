import type { SupabaseClient } from "@supabase/supabase-js"

/**
 * True si el usuario es admin o asesor activo del Trol.
 * Los admins son asesores implícitos. Se apoya en la RPC `is_advisor_user`
 * (definida en Supabase) que ya contempla RLS y la tabla `asesores`.
 */
export async function isAdvisor(supabase: SupabaseClient): Promise<boolean> {
  const { data } = await supabase.rpc("is_advisor_user")
  return data === true
}
