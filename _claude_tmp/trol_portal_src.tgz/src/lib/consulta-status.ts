export type StatusVariant = 'gris' | 'ambar' | 'verde' | 'rojo' | 'morado'

/**
 * Status que deja n8n al generar el Diagnóstico Avanzado: el documento ya está
 * en `documento_diagnostico_avanzado_url`, pero falta la validación de Trol
 * (que lo pasa a `completed`).
 */
export const DOC_PREVIO_STATUS = 'Doc previo listo'

export type StatusInfo = {
  label: string
  variant: StatusVariant
  isTerminal: boolean
  isSuccess: boolean
  isFailure: boolean
}

/**
 * Los status llegan de fuentes distintas (portal, API, n8n) y con variaciones
 * de espacios/mayúsculas. Normalizamos siempre antes de comparar para que, por
 * ejemplo, "Error", " error " o "ERROR" caigan en el mismo caso.
 */
export function normalizeStatus(status: string | null | undefined): string {
  return (status ?? '').trim().toLowerCase()
}

export function isErrorStatus(status: string | null | undefined): boolean {
  return normalizeStatus(status) === 'error'
}

export function getStatusInfo(status: string): StatusInfo {
  switch (normalizeStatus(status)) {
    case 'received':
      return { label: 'Recibida', variant: 'gris', isTerminal: false, isSuccess: false, isFailure: false }
    case 'processing':
    case 'waiting_jordan':
      return { label: 'En proceso', variant: 'ambar', isTerminal: false, isSuccess: false, isFailure: false }
    case 'completed':
    case 'envío exitoso':
      return { label: 'Completada', variant: 'verde', isTerminal: true, isSuccess: true, isFailure: false }
    case 'doc prev listo':
      // Documento previo generado: el asesor ya tiene acceso a datos y al doc; pendiente su revisión.
      return { label: 'Listo · revisión del asesor', variant: 'verde', isTerminal: true, isSuccess: true, isFailure: false }
    case normalizeStatus(DOC_PREVIO_STATUS):
      // n8n ya generó el Diagnóstico Avanzado, pero Trol aún no lo valida.
      // El doc solo se muestra a los aliados con partners.preview_doc_avanzado.
      return { label: 'En validación', variant: 'ambar', isTerminal: false, isSuccess: false, isFailure: false }
    case 'error':
    case 'failed':
    case 'error- nss':
      return {
        label:
          normalizeStatus(status) === 'error- nss'
            ? 'Error: NSS'
            : normalizeStatus(status) === 'error'
              ? 'Error'
              : 'Falló',
        variant: 'rojo',
        isTerminal: true,
        isSuccess: false,
        isFailure: true,
      }
    case 'delegated':
      return { label: 'Delegada', variant: 'morado', isTerminal: true, isSuccess: false, isFailure: false }
    default:
      return { label: status || 'Desconocido', variant: 'gris', isTerminal: false, isSuccess: false, isFailure: false }
  }
}

export function getStatusBadgeClasses(variant: StatusVariant): string {
  switch (variant) {
    case 'gris': return 'bg-gray-100 text-gray-700 dark:bg-gray-500/15 dark:text-gray-300'
    case 'ambar': return 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300'
    case 'verde': return 'bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300'
    case 'rojo': return 'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300'
    case 'morado': return 'bg-purple-100 text-purple-700 dark:bg-purple-500/15 dark:text-purple-300'
  }
}

export const ERROR_DETAIL_FALLBACK = 'Ocurrió un error al procesar la consulta'

const ERROR_DETAIL_MAX_LENGTH = 200

function truncate(text: string, max = ERROR_DETAIL_MAX_LENGTH): string {
  const clean = text.trim()
  return clean.length > max ? `${clean.slice(0, max - 1).trimEnd()}…` : clean
}

/** Saca el mensaje de un valor ya parseado: string directo u objeto con message. */
function messageFromValue(value: unknown): string | null {
  if (typeof value === 'string' && value.trim()) return value
  if (value && typeof value === 'object') {
    const message = (value as { message?: unknown }).message
    if (typeof message === 'string' && message.trim()) return message
  }
  return null
}

/** Busca la llave "error" en cualquier JSON que se logre parsear del texto. */
function errorFromJson(text: string): string | null {
  try {
    const parsed: unknown = JSON.parse(text)
    // Doble encodeo: el JSON contenía otro JSON como string.
    if (typeof parsed === 'string') return errorFromJson(parsed) ?? parsed
    if (parsed && typeof parsed === 'object') {
      return messageFromValue((parsed as { error?: unknown }).error)
    }
  } catch {
    /* no era JSON válido */
  }
  return null
}

/**
 * Convierte el `error_detail` crudo en un mensaje legible para el aliado.
 *
 * Los detalles llegan en formatos muy distintos:
 *   - `400 - "{\"error\":\"CURP con inconsistencias en los datos del IMSS\"}"`
 *   - `{"error":{"message":"..."}}`
 *   - texto plano como `Invalid source header`
 *
 * Si encuentra un JSON embebido con llave `error` (aunque venga escapado)
 * devuelve ese mensaje; si no, el texto recortado a 200 caracteres; y si no
 * hay nada, un mensaje genérico.
 */
export function parseErrorDetail(raw: string | null): string {
  const text = (raw ?? '').trim()
  if (!text) return ERROR_DETAIL_FALLBACK

  const candidates = [text]

  // Prefijos tipo `400 - {...}` o `400 - "{...}"`: nos quedamos con el bloque
  // entre la primera llave y la última.
  const start = text.indexOf('{')
  const end = text.lastIndexOf('}')
  if (start !== -1 && end > start) {
    const block = text.slice(start, end + 1)
    candidates.push(block)
    // El JSON puede venir escapado dentro de un string (\" en vez de ").
    if (block.includes('\\"')) {
      candidates.push(block.replace(/\\"/g, '"').replace(/\\\\/g, '\\'))
    }
  }

  for (const candidate of candidates) {
    const message = errorFromJson(candidate)
    if (message) return truncate(message)
  }

  // Último recurso: extraer la llave "error" con regex por si el JSON está mal
  // formado (comillas sueltas, texto pegado al final, etc.).
  for (const candidate of candidates) {
    const match = candidate.match(/\\?"error\\?"\s*:\s*\\?"((?:[^"\\]|\\.)*?)\\?"/)
    if (match?.[1]?.trim()) {
      return truncate(match[1].replace(/\\"/g, '"').replace(/\\n/g, ' '))
    }
  }

  return truncate(text)
}

export type SourceVariant = 'portal' | 'api' | 'manual' | 'unknown'

export type SourceInfo = {
  label: string
  variant: SourceVariant
  classes: string
}

export function getSourceInfo(source: string | null | undefined): SourceInfo {
  switch (source) {
    case 'portal':
      return {
        label: 'Portal',
        variant: 'portal',
        classes: 'bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300',
      }
    case 'api':
      return {
        label: 'API',
        variant: 'api',
        classes: 'bg-gray-100 text-gray-700 dark:bg-gray-500/15 dark:text-gray-300',
      }
    case 'manual':
      return {
        label: 'Manual',
        variant: 'manual',
        classes: 'bg-purple-100 text-purple-700 dark:bg-purple-500/15 dark:text-purple-300',
      }
    default:
      return {
        label: source || 'Desconocido',
        variant: 'unknown',
        classes: 'bg-gray-100 text-gray-500 dark:bg-gray-500/15 dark:text-gray-400',
      }
  }
}
