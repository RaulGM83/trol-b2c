// ============================================================================
// Componentes de presentación reutilizables para fichas pensionales (Trol).
// Generalizados a partir del detalle de consulta B2B para que sirvan también
// con datos de clientes B2C. Solo presentación: reciben props serializables.
// Paleta Trol: navy (slate-900) + lima (lime-400).
// ============================================================================

import type { ReactNode } from "react"
import { Download, ExternalLink, FileText, Sparkles } from "lucide-react"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const mxnFormatter = new Intl.NumberFormat("es-MX", {
  style: "currency",
  currency: "MXN",
  maximumFractionDigits: 0,
})

/** Formatea texto/número a MXN; "—" si no es numérico. */
export function pesos(v: string | number | null | undefined): string {
  if (v === null || v === undefined) return "—"
  const n =
    typeof v === "number" ? v : parseFloat(String(v).replace(/[^0-9.-]/g, ""))
  if (!Number.isFinite(n)) return "—"
  return mxnFormatter.format(n)
}

export function dash(v: unknown): string {
  if (v === null || v === undefined) return "—"
  const s = String(v).trim()
  return s.length ? s : "—"
}

/** Encabezado de tarjeta estilo Trol: barra de acento lima + título en navy. */
export function SectionTitle({
  children,
  count,
}: {
  children: ReactNode
  count?: number
}) {
  return (
    <div className="flex items-center gap-2 font-heading text-base font-medium text-slate-900 dark:text-slate-100">
      <span className="inline-block h-5 w-1 rounded-full bg-lime-400" />
      {children}
      {count !== undefined && (
        <span className="ml-1 inline-flex items-center rounded-full bg-lime-400/20 px-2 py-0.5 text-xs font-semibold text-lime-700 dark:text-lime-300">
          {count}
        </span>
      )}
    </div>
  )
}

export function Stat({
  label,
  value,
  highlight,
}: {
  label: string
  value: ReactNode
  highlight?: boolean
}) {
  return (
    <div
      className={`flex flex-col gap-1 ${
        highlight ? "rounded-xl bg-lime-400/10 px-3 py-2 ring-1 ring-lime-400/30" : ""
      }`}
    >
      <span className="text-xs uppercase tracking-wide text-muted-foreground">
        {label}
      </span>
      <span className="text-base font-medium text-slate-900 dark:text-slate-100">
        {value}
      </span>
    </div>
  )
}

/** Tarjeta destacada de oportunidad principal. `alto` la resalta en lima. */
export function OportunidadCard({
  label,
  alto,
}: {
  label: string
  alto?: boolean
}) {
  return (
    <Card
      className={
        alto ? "border-lime-400/60 bg-lime-400/[0.06]" : "border-border"
      }
    >
      <CardContent className="flex flex-col gap-2 py-6">
        <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-lime-700 dark:text-lime-300">
          <Sparkles className="size-4" />
          Oportunidad principal
        </div>
        <h2 className="font-heading text-2xl font-bold leading-tight text-slate-900 dark:text-slate-100">
          {label}
        </h2>
        <p className="text-sm text-muted-foreground">
          Conversa con tu cliente sobre esta vía como primer paso.
        </p>
      </CardContent>
    </Card>
  )
}

/** Tarjeta de escenario de pensión. `highlight` la pinta en navy con acento lima. */
export function EscenarioCard({
  title,
  subtitle,
  monto,
  edad,
  semanas,
  etiqueta,
  highlight,
}: {
  title: string
  subtitle: string
  monto: string
  edad?: string
  semanas?: string
  etiqueta?: string
  highlight?: boolean
}) {
  return (
    <div
      className={`flex flex-col gap-3 rounded-2xl p-5 ${
        highlight
          ? "bg-slate-900 text-slate-100 ring-1 ring-lime-400/40"
          : "bg-muted/40"
      }`}
    >
      <div>
        <div
          className={`text-xs font-medium uppercase tracking-wide ${
            highlight ? "text-lime-400" : "text-muted-foreground"
          }`}
        >
          {title}
        </div>
        <div
          className={`text-sm ${highlight ? "text-slate-300" : "text-muted-foreground"}`}
        >
          {subtitle}
        </div>
      </div>
      <div
        className={`font-heading text-3xl font-bold ${
          highlight ? "text-lime-400" : "text-slate-900 dark:text-slate-100"
        }`}
      >
        {monto}
      </div>
      <div
        className={`flex flex-col gap-1 text-xs ${
          highlight ? "text-slate-300" : "text-muted-foreground"
        }`}
      >
        {edad && edad !== "—" && (
          <div>
            <span className="opacity-70">Edad: </span>
            <span className="font-medium">{edad} años</span>
          </div>
        )}
        {semanas && semanas !== "—" && (
          <div>
            <span className="opacity-70">Semanas: </span>
            <span className="font-medium">{semanas}</span>
          </div>
        )}
        {etiqueta && (
          <div className="pt-1">
            <span
              className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${
                highlight
                  ? "bg-lime-400/20 text-lime-300"
                  : "bg-lime-400/20 text-lime-700 dark:text-lime-300"
              }`}
            >
              {etiqueta}
            </span>
          </div>
        )}
      </div>
    </div>
  )
}

/** Tarjeta de documento con acción de descarga o de apertura en visor. */
export function DocumentCard({
  title,
  audience,
  description,
  url,
  label,
  mode,
}: {
  title: string
  audience: string
  description: string
  url: string
  label: string
  mode: "download" | "open"
}) {
  const isDownload = mode === "download"
  return (
    <Card>
      <CardContent className="flex flex-col gap-4 py-6">
        <div className="flex items-start gap-3">
          <div className="rounded-full bg-lime-400/15 p-3">
            <FileText className="size-5 text-lime-700 dark:text-lime-300" />
          </div>
          <div className="flex flex-col">
            <span className="font-heading font-medium text-slate-900 dark:text-slate-100">
              {title}
            </span>
            <span className="text-xs text-muted-foreground">{audience}</span>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">{description}</p>
        <div>
          <Button asChild>
            <a
              href={url}
              {...(isDownload
                ? { download: "" }
                : { target: "_blank", rel: "noopener noreferrer" })}
            >
              {isDownload ? <Download /> : <ExternalLink />}
              {label}
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
