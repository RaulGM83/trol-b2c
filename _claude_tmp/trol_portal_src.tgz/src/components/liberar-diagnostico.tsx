"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { BadgeCheck, ShieldCheck } from "lucide-react"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

function formatLiberado(iso: string): string {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  return new Intl.DateTimeFormat("es-MX", {
    day: "numeric",
    month: "short",
    year: "numeric",
    timeZone: "America/Mexico_City",
  })
    .format(d)
    .replace(/\./g, "")
}

/** Sello de "documento liberado por Trol" con la fecha de liberación. */
export function LiberadoBadge({
  liberadoAt,
  className = "",
}: {
  liberadoAt: string
  className?: string
}) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300 px-2.5 py-0.5 text-xs font-medium ${className}`}
      title={`Documento liberado al aliado el ${formatLiberado(liberadoAt)}`}
    >
      <BadgeCheck className="size-3" />
      Liberado · {formatLiberado(liberadoAt)}
    </span>
  )
}

/**
 * Acción de asesor/admin sobre una consulta en "Doc previo listo": valida el
 * Diagnóstico Avanzado y lo libera al aliado (status → completed).
 *
 * Solo debe renderizarse para asesores/admins; la RPC igual lo valida en el
 * servidor y devuelve HINT `not_advisor`.
 */
export function LiberarDiagnosticoButton({
  consultaId,
  size = "sm",
  variant = "default",
  label = "Marcar como revisado y liberar",
}: {
  consultaId: string
  size?: "sm" | "default"
  variant?: "default" | "outline"
  label?: string
}) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)

  async function liberar() {
    setLoading(true)
    const supabase = createClient()
    const { error } = await supabase.rpc("liberar_diagnostico", {
      p_consulta_id: consultaId,
    })

    if (error) {
      const hint = error.hint ?? ""
      if (hint === "not_advisor") {
        toast.error("No tienes permiso")
      } else if (hint === "doc_missing") {
        toast.error("Aún no se genera el documento")
      } else if (hint === "consulta_not_found") {
        toast.error("Consulta no encontrada")
      } else {
        toast.error(error.message)
      }
      setLoading(false)
      return
    }

    toast.success("Diagnóstico liberado al aliado")
    setLoading(false)
    setOpen(false)
    router.refresh()
  }

  return (
    <>
      <Button
        type="button"
        size={size}
        variant={variant}
        onClick={() => setOpen(true)}
      >
        <ShieldCheck />
        {label}
      </Button>

      <Dialog open={open} onOpenChange={(next) => !loading && setOpen(next)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Liberar el Diagnóstico Avanzado</DialogTitle>
            <DialogDescription>
              El aliado verá el documento como final. La consulta pasará a
              &quot;Completada&quot; y quedará registrado quién la liberó.
            </DialogDescription>
          </DialogHeader>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button type="button" onClick={liberar} disabled={loading}>
              {loading ? "Liberando…" : "Marcar como revisado y liberar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
