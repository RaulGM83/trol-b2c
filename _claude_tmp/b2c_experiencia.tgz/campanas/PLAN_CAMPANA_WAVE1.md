# Campaña Compara Afore — Wave 1: qué está listo y qué falta

**El Trol Financiero** · 19 de julio de 2026
Plan afinado con los aprendizajes del motor contrafactual (v1.5) y del batch sobre la base real.

---

## 1. Lo que YA está listo

| Pieza | Estado |
|---|---|
| Motor contrafactual v1.5 (pension-core + edge function) | ✅ 36 tests, corriendo en producción |
| Cálculo por cliente (`calculo_pensional.contrafactual`) | 🔄 Batch en curso, termina hoy (~8:15am); 0 errores desde el fix de IO |
| Canastas por generación (top-3 / mediana / bottom-3, solo precios) | ✅ Congeladas por corte jun-2026 |
| Precios CONSAR a jun-2026 + refresh mensual (XLS por hoja) + caché de series | ✅ (recordar refrescar caché tras cada ingesta) |
| Universo dimensionado (wave 1: 1,741 con ≥$500k y teléfono) | ✅ |
| Plataforma de envío (Tako) + reglas Meta + buenas prácticas de calidad del número | ✅ (PLANTILLAS_WHATSAPP_TAKO.md) |
| Magic links + atribución (`b2c_magic_tokens`, `links_campania`, `envios_wa` con gating) | ✅ probados en lotes previos (apertura 33-40%) |
| KPIs con metas calibradas | ✅ (VALIDACION_COMPARA_AFORE.md §5) |
| Curva salarial propia + fuentes de historia por cliente | ✅ (dato de calidad por cliente: `fuente_historia`, `cobertura_historia`) |

## 2. Afinaciones al gancho — lo que los cálculos nos enseñaron

1. **El mensaje usa SOLO números del motor** (decisión v1.5): canasta superior y mediana simuladas con la historia laboral del cliente. Nada de estimados viejos; el saldo real entra hasta el unlock. El gancho natural quedó: *"en una de las mejores AFOREs tu ahorro rondaría $X; en el promedio del sistema, $Y — ¿sabes cuánto tienes tú?"* — la pregunta final ES la invitación al unlock, porque el cliente sí conoce (o puede conocer) su saldo.
2. **"Rondar" y redondeo a miles, siempre** (frescura SISEC hasta 2 años + regla Meta de no prometer montos). Nunca nombrar AFOREs en el mensaje; el IRN oficial y las AFOREs viven dentro del reporte.
3. **Tres variantes según los datos del cliente** (el batch nos da el semáforo por adelantado):
   - **A. Publicable (~94%):** mensaje con cifras (plantilla `compara_afore_w1`).
   - **B. No publicable (~6%, cobertura <0.7 o >1.3):** genérico sin cifras (plantilla `compara_afore_generico`). No los perdemos; solo no les inventamos un número.
   - **C. Sin historia (~25% de la base total, pero mucho menor en wave 1):** fuera de esta campaña; candidatos a refresh SISEC.
4. **Priorización DENTRO de wave 1 por `brecha_top_vs_baja`** (decisión #9 adaptada a números internos): se contacta primero a quien más dinero tiene en juego entre estar en una top y una del fondo. En la muestra ≥$100k la brecha top-vs-mediana mediana fue ~$28k y p75 ~$41k; en wave 1 (≥$500k) esperamos 3-5× eso.
5. **El reporte post-unlock desglosa RCV-97 y SAR-92 por separado** — "cuadra con tu estado de cuenta línea por línea" es el momento de confianza. Y para el ~⅓ cuyo saldo real supere la mediana simulada: mensaje "vas bien — no te muevas" + oferta de aportación voluntaria (puente a F2/Millas). Estar bien también es un resultado vendible: valida que el diagnóstico es honesto.

## 3. Plantillas Meta (borrador, formato Tako)

### `compara_afore_w1` — variante A (con cifras)

**Categoría:** Marketing · **Idioma:** Español (MEX) · **Encabezado:** *(vacío)*

**Cuerpo:**
```
Hola {{1}} 👋 Te saludamos de El Trol, donde hace un tiempo calculaste tu pensión. Hicimos números con tu historia laboral: en una de las mejores AFOREs de tu generación, tu ahorro para el retiro rondaría {{2}}. En el promedio del sistema, rondaría {{3}}. ¿Sabes en cuál está el tuyo? Compara tu AFORE aquí:
{{4}}
Cualquier duda, contéstanos por este chat. 🙌
```

**Muestras:** `{{1}} → Juan` · `{{2}} → $980 mil` · `{{3}} → $905 mil` · `{{4}} → https://app.trol.mx/e/<token>?c=comparaafore_w1`
**Pie:** `Responde BAJA para no recibir más mensajes.`

*Notas Meta:* no abre ni cierra con variable ✓, sin variables juntas ✓, sin "garantizado" ✓, dominio propio ✓. Los montos van como texto pre-formateado ("$980 mil") — redondeo a decenas de miles refuerza el "rondaría".

### `compara_afore_generico` — variante B (sin cifras)

**Cuerpo:**
```
Hola {{1}} 👋 Te saludamos de El Trol, donde hace un tiempo calculaste tu pensión. ¿Sabías que 9 de 10 AFOREs cobran lo mismo pero no rinden lo mismo? Preparamos tu comparativo personalizado para que veas si la tuya está entre las mejores de tu generación. Míralo aquí:
{{2}}
Cualquier duda, contéstanos por este chat. 🙌
```

## 4. Flujo operativo wave 1

1. **Export desde Supabase** (al terminar el batch + auditoría):
   ```sql
   select c.nombre, c.telefono,
     (c.calculo_pensional->'contrafactual'->'canasta_superior'->>'promedio')::numeric monto_top,
     (c.calculo_pensional->'contrafactual'->>'mediana_sistema')::numeric monto_mediana,
     (c.calculo_pensional->'contrafactual'->>'brecha_top_vs_baja')::numeric prioridad,
     (c.calculo_pensional->'contrafactual'->>'flag_publicable')::bool publicable
   from clientes c
   where replace(replace(c.rcv97,'$',''),',','')::numeric >= 500000
     and c.calculo_pensional->'contrafactual' is not null
   order by prioridad desc;   -- ~1,741; formatear montos a "$XXX mil" en el CSV
   ```
2. **Piloto: 200 de mayor brecha, lunes AM** (mismo playbook de lotes previos: medir apertura 24-48h en `links_campania` con `c=comparaafore_w1`, vigilar calidad del número en WhatsApp Manager, honrar BAJA).
3. **Ampliación por lotes diarios** al ritmo que el equipo pueda contestar (regla de capacidad de Tako, seguimiento +1h sin respuesta).
4. **Embudo instrumentado:** enviado (`campania_enviados`) → apertura (`links_campania`) → unlock (evento nuevo al subir estado de cuenta) → comparativo visto → handoff a agente (tarea manual + registro) → traspaso iniciado (seguimiento con SURA).

## 5. Pendientes críticos antes de disparar (en orden)

1. **Cierre del batch + auditoría** (hoy AM — ya agendado).
2. **Experiencia del comparativo en la app:** render del bloque `contrafactual` (canastas, mediana, desglose RCV/SAR-92, IRN oficial citado, panel ñoño colapsado) sobre `ComparadorView` existente. *Dev: 1-2 días.*
3. **Unlock estado de cuenta v1:** subir foto/PDF + consentimiento explícito + aviso de privacidad ARCO (dato financiero sensible). Captura del saldo **manual por el equipo** en v1 (el parser automático es F2) — no bloquear el lanzamiento por un OCR.
4. **Aprobación Meta** de las 2 plantillas (enviar con anticipación; horas-días).
5. **Acuerdo SURA:** el handoff debe cerrar con agente promotor registrado (flag regulatorio); confirmar el canal operativo con ellos antes del piloto. Dato para la mesa: $2,343M en saldos ≥$250k.
6. **Operativo:** refrescar `siefore_series_cache` tras cada ingesta de precios; lista de exclusión BAJA activa en Tako.

## 6. Metas del piloto (de la validación, sin cambios)

Apertura ≥35% · unlock ≥8% de aperturas · comparativo ≥70% de unlocks · ≥15 traspasos iniciados en wave 1 · baseline del panel ñoño. Métrica nueva de calidad: distribución de `fuente_historia` y `cobertura_historia` del universo contactado (la trae el batch).
