# Plan de lanzamiento B2C — lunes 29 jun 2026

**Objetivo del lunes:** salir con campañas de la experiencia B2C (app.trol.mx) en dos canales —
**email masivo (HubSpot)** y **WhatsApp (Tako)**— con dos metas comerciales:
1. **Venta / desbloqueo de la calculadora–actualización** (la "mejor jugada" interactiva, $100 o gánala con puntos).
2. **Reactivación a otros productos** (Mod 40, gestoría IMSS/Infonavit, PPR) ruteando cada perfil a su mejor jugada.

Tenemos **sábado y domingo** para construir lo que falte, diseñar y probar.

---

## Estado de implementación (27 jun) — iniciada

Hecho en esta sesión (en el repo `trol-b2c`, pendiente de push/deploy salvo donde se indique):
- ✅ **Fix trigger SISEC** aplicado en `app/api/pago/webhook/route.ts`: el refresh Jordan ahora se decide por **`última_fecha_sisec`** (dato real), no por `calculo_pensional_at`. (Verificado: 84% de la base lo necesita.)
- ✅ **OpenGraph** agregado en `app/layout.tsx` (título, descripción, `og:image`, twitter card) → links de referido/`/calcula` se ven como tarjeta al compartir. **Falta:** subir `public/og.png` (1200×630).
- ✅ **CSV piloto Mod 40** generado: `campanas/tako_piloto_mod40.csv` (201 contactos con nombre, teléfono, link `/e/`, ley) — listo para cargar en Tako.
- ✅ **Verificado:** `NEXT_PUBLIC_WHATSAPP_TROL` ya está configurada en Vercel; tarjeta in-page (MP Bricks) ya en producción; desbloqueo = **100 puntos** (1 punto = 1 peso = $100 calculadora).

- ✅ **Puntos→Jordan cableado:** nueva ruta `app/api/refrescar/route.ts` (server) que dispara el refresh Jordan con `origen:'b2c_puntos'`; `Checkout.tsx` la llama tras el desbloqueo por puntos. Typecheck en verde. (Pendiente push/deploy.)
- ✅ **Puntos precargados (PRODUCCIÓN):** 100 pts a **4,531** leads con CURP y sin semilla (`motivo='cortesia_activacion'`, 453,100 pts, caducan 27-dic-2026). Insert idempotente. Ya pueden activar su calculadora gratis en cuanto se despliegue el cableado anterior.

---

## 1. Estado del producto (qué tenemos LISTO)

Verificado contra Supabase, los docs del proyecto y la app en producción:

- **app.trol.mx LIVE** (Vercel): login teléfono+OTP (Twilio Verify por **SMS**), diagnóstico, mejor jugada, checkout.
- **Pago SPEI validado en producción** (transferencia real → webhook MP → orden cumplida + cashback 10% + desbloqueo). **Tarjeta in-page (MP Bricks) ya lista** + Checkout Pro como respaldo.
- **Desbloqueo por puntos** real (RPCs `saldo_puntos` / `desbloquear_con_puntos`).
- **Rutas ya en la app:** además de `/diagnostico`, `/mejor-jugada`, `/checkout`, `/calcula`, `/referidos`, `/r`, `/e` → existen `/comparador` (AFOREs), `/encuesta`, `/asesoria`, `/calculadora`.
- **Referidos construidos:** link personal `/r/<cliente_id>` → `/calcula`; recompensa +100 pts al que refiere y +50 al referido cuando llega a su diagnóstico. Página `/referidos` para compartir y ver stats.
- **Links Tako listos:** `/e/<cliente_id>?c=…` (reactivación con semilla, prellena teléfono), `/calcula?ref=…` (frío sin CURP). Tabla `links_campania` (atribución) + vista `vista_links_reactivacion` (7,966 filas listas con su link).
- **Ruteo Llave 3 LIVE:** `vista_ruteo` clasifica cada cliente con semilla en producto estrella + prioridad (página `/ruteo` para asesores).

## 2. La base real (verificada hoy en Supabase)

| Métrica | Valor |
|---|---|
| Clientes totales | **13,619** (14,755 contactos en HubSpot) |
| Con teléfono | 13,583 |
| **Email real** (no placeholder) | **12,490** ✅ email masivo viable |
| Email placeholder `@trol.mx` | 1,106 ⚠️ excluir (rebotan) |
| Sin email | 23 |
| **Con diagnóstico listo (semilla)** | **7,967** |
| Vinculados a la app (login) | 1 (la base aún no entra → de eso se trata el lanzamiento) |

**Por ley (con semilla):** Ley 73 = 6,976 · Ley 97 = 978 · sin ley (leads crudos) = 13.

**Frescura — corrección clave (la semilla es fresca, los DATOS no):** las semillas se recalcularon el 13–25 jun, pero corren sobre **datos del IMSS (SISEC) que pueden ser muy viejos**. De 7,953 con fecha SISEC:

| Antigüedad del dato SISEC | Clientes | % |
|---|---|---|
| Más de 1 mes | 6,714 | 84% |
| Más de 6 meses | 3,540 | 44% |
| Más de 1 año | 853 | 11% |
| Más viejo registrado | 24-dic-2023 | — |

→ Dos implicaciones:
1. **Fix de producto (pendiente §5):** el disparador de actualización (refresh Jordan) hoy compara contra `calculo_pensional_at` (fecha de la semilla, siempre fresca) → **nunca se dispara**. Debe comparar contra **`última_fecha_sisec`** (fecha real del dato). Así el "actualiza tus datos" funciona para el 84% que lo necesita.
2. **Gancho de campaña fuerte y honesto:** *"ahora puedes actualizar tu información del IMSS cuando quieras y recalcular tu pensión al instante"* — relevante para la mayoría de la base, y es justo lo que justifica el producto de $100.

**Ruteo por producto estrella (7,194 scoreados) — define el mensaje de reactivación:**

| Producto estrella | Clientes | Prioridad alta (≥80) | Ángulo de campaña |
|---|---|---|---|
| Gestoría IMSS | ~3,622 | ~1,150 | Listo/cerca de pensionarte: te acompañamos en el trámite |
| Asesoría | ~2,406 | ~390 | Tienes palanca, falta plan: agenda tu sesión |
| Gestoría Infonavit | ~900 | ~775 | Recupera tu subcuenta de vivienda / Infonavit |
| **Modalidad 40** | ~201 | ~164 | **Mayor palanca:** "de $X a $Y" — premium, empezar AQUÍ |
| PPR | ~65 | bajo | Ley 97 con ingreso: horizonte/ahorro |

## 3. Segmentación de campañas

**Macro-segmento A — Reactivación con diagnóstico listo (7,966).** Tienen pensión calculada y link `/e/`.
Sub-segmentar por **producto estrella** (mensaje distinto, mismo link). Arrancar por **Modalidad 40 (~200)** como piloto: mayor "wow" del "de $X a $Y" y mayor ticket.

**Macro-segmento B — Leads sin diagnóstico (~5,652).** Ojo: **no es que les faltara hacer algo a ellos** — llegaron antes de que guardáramos los JSON y/o la consulta de Belvo no fue exitosa (solo 17 tienen `json_belvo`). Son **candidatos válidos**: **4,531 (80%) tienen CURP válido** → **Jordan puede activar su cálculo** (Jordan siempre trae datos de hoy, donde Belvo falló). 5,066 con email real, 5,617 con teléfono.

**Mecánica propuesta (más económica que correr Jordan en todos):** en vez de refrescar los 4,531 por adelantado en Jordan (costoso), **precargar los puntos necesarios** en estos contactos para que **ellos disparen su propia actualización** desde la app. Así solo consume Jordan quien se interesa (autoselección), y el costo se gasta solo donde hay intención. Mensaje: *"activa tu cálculo gratis — ya tienes puntos para actualizar tu información del IMSS y ver tu pensión"*. Los 1,121 sin CURP siguen el camino de captura/`calcula`.

**Corte por ley (para el copy de la calculadora):** Ley 73 (8,557) = palanca semanas/salario + Mod 40; Ley 97 (1,632) = AFORE/PPR/horizonte.

**Lever transversal — Referidos (aprovechar el pipeline ya construido):** en TODA campaña de reactivación, ofrecer *"gánala gratis: invita a un amigo (+100 pts) y desbloquea tu calculadora sin pagar"*. Une reactivación + monetización + viralidad con cero build nuevo.

## 4. Reparto por canal (revisado: email a toda la base, WhatsApp piloto pausado)

**Email = canal masivo principal.** Costo ~marginal, 12,490 emails reales. Va a **toda la base segmentada** como una **serie programada en el tiempo** (HubSpot permite calendarizar la secuencia desde que entran a la campaña). Sin aprobación previa → arranca el lunes. Excluir placeholders `@trol.mx`, rebotados y no-marketing.

**WhatsApp (Tako) = piloto de medición, repartido en varios días.** Dos razones para NO hacer blast masivo:
1. **Costo:** el mensaje de marketing en México ronda **~$0.03 USD base + markup del BSP** (~$0.60–0.80 MXN c/u); a 13k = caro vs. email.
2. **Capacidad del equipo:** cada envío **abre una conversación** que el equipo debe atender en vivo para aprovecharla. Hay que dosificar el volumen diario a lo que el equipo pueda contestar.

→ **Diseño del piloto WhatsApp:** lotes diarios dimensionados por capacidad (ej. 150–300/día), empezando por **mayor palanca**: Modalidad 40 (~200) → Ley 97 (~977) → resto por prioridad. Medir eficiencia (apertura, respuesta, conversión, costo por reactivación) contra el email para decidir si escala.

**Secuencia:** Email lunes a toda la base (tronco común, §abajo) + WhatsApp piloto Mod 40 el mismo lunes en lote chico. Comparar resultados antes de ampliar WhatsApp.

**Sugerencia de lotes WhatsApp (ajustar a capacidad real del equipo):**

| Día | Lote | Volumen aprox. | Quién contesta |
|---|---|---|---|
| Lun | Modalidad 40 (prioridad alta) | ~165 | Equipo asesores |
| Mar | Ley 97 / PPR | ~250 | " |
| Mié | Gestoría Infonavit (prioridad alta) | ~250 | " |
| Jue–Vie | Gestoría IMSS por prioridad | ~250/día | " |

## 5. Pendientes a construir/configurar este fin de semana

**Bloqueadores reales del lanzamiento (en orden):**

1. **Plantillas WhatsApp → enviar a aprobación de Meta (sábado AM).** Sin esto no hay blast el lunes. (Ver `PLANTILLAS_WHATSAPP_TAKO.md`.)
2. **Export de la base de reactivación para Tako.** `select nombre, telefono, url_herramienta, ley from vista_links_reactivacion` → CSV. Empezar con piloto Mod 40 (~200) y los ~977 Ley 97.
3. **Listas/segmentos en HubSpot** para el email (por producto estrella / por ley / sin semilla), excluyendo placeholders y no-marketing.
4. **Emails en HubSpot** (3–4 piezas, copy ya redactado en `CAMPANAS_EMAIL_HUBSPOT.md`) — construir en el editor y probar render + links.
5. **Env vars en Vercel** (si se quiere encender captura de frío y agendado):
   - `NEXT_PUBLIC_WHATSAPP_TROL` ✅ ya configurada.
   - `NEXT_PUBLIC_BOOKING_URL` (link de HubSpot Meetings para "+sesión") — pendiente.
   - `LEAD_WEBHOOK_URL` ya definido (reusa webhook Tako).
   - Subir `public/og.png` (1200×630) para la tarjeta de preview de links.
6. **n8n — rama Switch `calculadora_web`** en el workflow "Nuevo cliente Booster Asesoria": para que los leads de `/calcula` creen contacto en HubSpot. Sin esto, el tráfico frío de email/WhatsApp que cae en `/calcula` no se registra como contacto.
7. **n8n — agregar `url_herramienta`** al workflow "Envío de información" (clientes nuevos reciben el link interactivo junto al PDF). No bloquea el blast, pero conviene para clientes nuevos del lunes en adelante.

8. **Fix del trigger de actualización (§2):** cambiar la comparación de `calculo_pensional_at` → **`última_fecha_sisec`** para que el refresh Jordan se dispare según la antigüedad real del dato (84% lo necesita). Habilita el gancho "actualiza tus datos cuando quieras" de forma honesta. Verificar que la UI muestre "datos al DD/MM/AAAA" tomando `última_fecha_sisec`.
9. **Activación de leads sin diagnóstico (Segmento B):** (a) cablear el **refresh Jordan en la ruta de desbloqueo por puntos** (hoy el trigger vive solo en `webhook/route.ts` del pago; el desbloqueo por puntos NO lo dispara) → al desbloquear con puntos y no haber semilla, llamar al mismo `N8N_FULFILLMENT_URL` con `{curp, cliente_id, origen:'b2c_puntos'}`; (b) **precargar 100 puntos** (insert en `puntos_movimientos`, `tipo='credito'`, `motivo='cortesia_activacion'`, `expira_at = now()+6m`) a los 4,531 con CURP válido, para que la activación les salga gratis. **Orden:** primero (a), luego (b) — si no, desbloquearían sin obtener datos. Validar costo unitario de Jordan antes del blast. *(SQL de precarga preparado; ejecutar tras confirmar.)*

**Dejar listo para salir (no para el lunes, sí esta semana):**
- **Comparador de AFOREs** — ya existe la ruta `/comparador` y datos cargados (10 AFOREs, 100 filas IRN, vista `vista_comparador_afore`). Para publicarlo falta: (a) verificar IRN/comisiones al corte vigente con su fecha + disclaimers obligatorios (no somos CONSAR, IRN oficial, no tramitamos traspasos); (b) confirmar que filtra IRN por generación según año de nacimiento; (c) validar que `afore_mercado` (hoy 10 filas) tenga datos reales para la columna Fuga; (d) QA visual. Es un **gancho gratis** para futura campaña (SEO/tibios), no se mezcla con el blast del lunes.

**No bloqueantes (después):** calculadora de costo de retiro (pospuesta), pipeline CONSAR automático mensual, ISSSTE.

## 6. Cronograma sábado–domingo

**Sábado**
- AM: Finalizar y **enviar plantillas WhatsApp a Meta** (aprobación). Definir listas/segmentos en HubSpot.
- AM: Export CSV de reactivación (piloto Mod 40 + Ley 97) para Tako.
- PM: Construir los emails en HubSpot (pegar copy, links de atribución, probar render en móvil/desktop).
- PM: Setear env vars en Vercel; abrir rama Switch `calculadora_web` en n8n.

**Domingo**
- AM: **QA end-to-end** (checklist §7) con un número/cliente de prueba.
- AM: Verificar que las plantillas WhatsApp quedaron aprobadas; cargar en Tako con el CSV piloto.
- PM: Prueba de envío real a 5–10 contactos internos (email + WhatsApp), medir aperturas en `links_campania`.
- PM: Ajustes finales de copy; preparar el blast del lunes (programar email en HubSpot).

**Lunes (lanzamiento)**
- AM: Blast WhatsApp piloto Mod 40 (~200) → medir 1–2 h → si OK, ampliar a Gestoría IMSS/Infonavit.
- Mediodía: Email masivo segmentado (HubSpot).
- PM: Email de respaldo a no-abiertos; revisar métricas.

## 7. Checklist de QA (antes del lunes)

- [ ] `app.trol.mx/e/<cliente_id_prueba>?c=reactivacion_jun30` → prellena teléfono, registra apertura en `links_campania`, manda a OTP.
- [ ] OTP llega por SMS (Twilio Verify) y entra al diagnóstico real del cliente de prueba.
- [ ] Pantalla **Mejor jugada** muestra "de $X a $Y" correcto para un caso Mod 40.
- [ ] Desbloqueo **por puntos** funciona (saldo baja, orden creada).
- [ ] Pago **SPEI $100** → webhook → orden cumplida + cashback + calculadora desbloqueada.
- [ ] **Referidos:** `/r/<id>` cae en `/calcula` con cookie; `/referidos` muestra link y stats.
- [ ] `/calcula?ref=tako` (frío sin CURP) calcula y el CTA crea lead → **llega a HubSpot** (rama n8n).
- [ ] Email de prueba: render OK en Gmail/Outlook/móvil, todos los links con UTM correctos, sin placeholders rotos.
- [ ] Plantilla WhatsApp **aprobada por Meta** y enviando con variables correctas.
- [ ] Exclusiones aplicadas: placeholders `@trol.mx`, rebotados, no-marketing.
- [ ] Atribución medible: query de aperturas/reactivados de `LINKS_TAKO.md` corre y devuelve datos.

## 8. Métricas a vigilar (post-lanzamiento)

- Aperturas por campaña: `select campania, evento, count(*), count(distinct cliente_id) from links_campania group by 1,2`.
- Reactivados (abrieron + iniciaron sesión después): query en `LINKS_TAKO.md`.
- Email (HubSpot): open rate, CTR al link `/e/`, rebotes.
- Conversión: órdenes en `ordenes_b2c` (pago vs puntos), referidos nuevos en `referidos`.

---

**Entregables que acompañan este plan:**
- `CAMPANAS_EMAIL_HUBSPOT.md` — copys y estructura de los emails por segmento.
- `PLANTILLAS_WHATSAPP_TAKO.md` — plantillas para enviar a aprobación de Meta + envío en Tako.
