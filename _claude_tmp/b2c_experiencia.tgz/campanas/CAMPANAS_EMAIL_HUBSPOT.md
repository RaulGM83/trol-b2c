# Campañas de email — HubSpot (B2C, lanzamiento lunes)

Copys listos para pegar en el editor de email de HubSpot. La marca: gris #26282b, lima #d1f069, blanco; tipografía Hanken Grotesk. Tono El Trol: claro, sin promesas garantizadas, "el trámite IMSS es gratis, sin anticipos".

**Nota técnica:** el MCP de HubSpot no crea emails de marketing directo; estos copys se construyen en el editor (Marketing → Email). Cada link de cliente usa su token: en HubSpot usar token de personalización para `cliente_id` (propiedad `id_hubspot`/`cliente_id`) en la URL, o enviar vía workflow que arme `app.trol.mx/e/{{cliente_id}}?c=…`.

**Exclusiones obligatorias en todas las listas:** email contiene `@trol.mx` (placeholder) · rebotados · sin consentimiento de marketing.

**Atribución:** sufijo `?c=reactivacion_jun30_email` (o el segmento) + UTMs de HubSpot.

---

## Estructura: serie programada (tronco común → segmento)

El email va a **toda la base** como una secuencia calendarizada en HubSpot. Primero un **tronco común** (mismo mensaje para todos los que tienen diagnóstico), y a partir del 3.º correo se **abre por segmento** (producto estrella / ley). Los leads sin diagnóstico corren su propia mini-serie (Segmento B).

**Tres mensajes nuevos para 2026, según las aclaraciones:** (1) ya hay herramienta interactiva, (2) **ahora puedes actualizar tus datos del IMSS cuando quieras** (relevante para el 84% con SISEC viejo), (3) refiere y gánala.

| # | Día | Audiencia | Tema | CTA |
|---|---|---|---|---|
| **E0** | Lun (lanzamiento) | Tronco común (con semilla) | "Tu pensión ahora es interactiva" | Ver mi diagnóstico → `/e/` |
| **E1** | +3 días | Tronco común (no convertidos) | "¿Tus datos del IMSS están al día? Actualízalos cuando quieras" | Actualizar y recalcular → `/e/` |
| **E2** | +7 días | **Ramifica por segmento** (A1–A5) | Mejor jugada por producto estrella | Ver mi mejor jugada → `/e/` |
| **E3** | +12 días | No convertidos | "Gánala gratis: refiere a un amigo" | Mi link de referidos → `/r/` |
| **B0/B1** | Lun / +4 días | Segmento B (sin semilla) | "Termina tu diagnóstico" | Calcular → `/calcula` |

Regla de salida: si el cliente desbloquea la calculadora (paga o por puntos), sale de la serie de venta. Si abre pero no convierte, sigue al siguiente correo.

---

## TRONCO COMÚN

### E0 — Lanzamiento (todos con semilla)

- **Asunto:** {{ contact.firstname }}, tu pensión ahora es interactiva
- **Preview:** Mueve edad, semanas y ahorro y mira en vivo cómo cambia. Tus datos ya cargados.
- **Cuerpo:**

> Hola {{ contact.firstname }},
>
> Estrenamos algo que te va a gustar: tu pensión, **interactiva**. Mueve tu edad de retiro, semanas y ahorro y mira **en vivo** cómo cambia tu pensión — con tu información del IMSS ya cargada.
>
> **[Ver mi diagnóstico →]** (`app.trol.mx/e/{{cliente_id}}?c=lanzamiento_email`)
>
> Te pedimos solo un código por SMS para entrar de forma segura a tu información.
>
> Es una estimación con cifra puntual y su aclaración, para que decidas con números claros. — El Trol

### E1 — Actualiza tus datos (no convertidos del E0)

- **Asunto:** {{ contact.firstname }}, ¿tu información del IMSS está al día?
- **Preview:** Ahora puedes actualizarla cuando quieras y recalcular tu pensión al instante.
- **Cuerpo:**

> Hola {{ contact.firstname }},
>
> Tu pensión cambia con tus últimas semanas cotizadas. Por eso ahora puedes **actualizar tu información del IMSS cuando quieras** desde tu diagnóstico, y ver tu pensión recalculada al instante con los datos de hoy.
>
> **[Actualizar y recalcular →]** (`app.trol.mx/e/{{cliente_id}}?c=actualiza_email`)
>
> Si tus datos tienen meses (o años), esta es la forma de ver tu número real. — El Trol

*(Nota: este correo asume el fix del trigger por `última_fecha_sisec`. Mostrar en la app "datos al DD/MM/AAAA" refuerza el mensaje.)*

---

## E2 — RAMIFICACIÓN POR SEGMENTO

A partir de aquí cada segmento recibe su mejor jugada. Copys abajo (A1–A5).

---

## Segmento A1 — Modalidad 40 (piloto, ~200 · prioridad alta)

**Lista HubSpot:** `producto_estrella = MODALIDAD_40` (o cruce con export de `vista_ruteo`), con semilla, email real.
**Objetivo:** mostrar el "de $X a $Y" → desbloquear calculadora (puntos o $100).

- **Asunto:** {{ contact.firstname }}, tu pensión puede valer varias veces más — míralo en vivo
- **Preview:** Ya recalculamos tu caso. Mueve edad, semanas y ahorro y mira tu mejor jugada.
- **Cuerpo:**

> Hola {{ contact.firstname }},
>
> Revisamos tu historia laboral en el IMSS y tu caso tiene una de las palancas más fuertes que vemos: con **Modalidad 40** tu pensión puede multiplicarse.
>
> Estrenamos una **calculadora interactiva**: mueve tu edad de retiro, semanas y ahorro, y mira en vivo cómo cambia tu pensión — con tus datos ya cargados. Sin promesas: es tu estimación con cifra puntual y su aclaración.
>
> **[Ver mi mejor jugada →]** (botón lima → `app.trol.mx/e/{{cliente_id}}?c=reactivacion_jun30_email`)
>
> Te pedimos solo un código por SMS para entrar a tu información de forma segura.
>
> ¿Prefieres no pagar? **Gánala con puntos:** invita a un amigo y desbloquéala gratis.
>
> — El Trol

---

## Segmento A2 — Gestoría IMSS (~3,622)

**Lista:** `producto_estrella = GESTORIA_IMSS`, con semilla, email real.
**Objetivo:** "ya casi/listo para pensionarte" → diagnóstico interactivo + acompañamiento.

- **Asunto:** {{ contact.firstname }}, ya tienes lo necesario para pensionarte — revisa tu número
- **Preview:** Tu diagnóstico está listo. Velo interactivo y mira cuándo te conviene.
- **Cuerpo:**

> Hola {{ contact.firstname }},
>
> Según tu historial del IMSS, estás cerca (o ya listo) para tramitar tu pensión. Preparamos tu **diagnóstico interactivo**: ajusta tu edad de retiro y mira en vivo cuánto te quedaría y cuándo te conviene salir.
>
> **[Ver mi diagnóstico →]** (`app.trol.mx/e/{{cliente_id}}?c=reactivacion_jun30_email`)
>
> Si decides tramitar, te acompañamos paso a paso.
>
> — El Trol

---

## Segmento A3 — Gestoría Infonavit (~900 · muchos prioridad alta)

**Lista:** `producto_estrella = GESTORIA_INFONAVIT`, con semilla, email real.

- **Asunto:** {{ contact.firstname }}, ¿ya revisaste tu subcuenta de vivienda?
- **Preview:** Tu dinero de Infonavit puede sumar a tu retiro. Velo en tu diagnóstico.
- **Cuerpo:**

> Hola {{ contact.firstname }},
>
> Además de tu pensión IMSS, tienes saldo en **Infonavit** que puede sumar a tu retiro. En tu **diagnóstico interactivo** lo verás integrado a tu mejor jugada.
>
> **[Ver mi diagnóstico →]** (`app.trol.mx/e/{{cliente_id}}?c=reactivacion_jun30_email`)
>
> Te ayudamos a revisar lo que te corresponde. — El Trol

---

## Segmento A4 — Asesoría (~2,406)

**Lista:** `producto_estrella = ASESORIA`, con semilla, email real.

- **Asunto:** {{ contact.firstname }}, tu pensión tiene margen — armemos tu plan
- **Preview:** Tienes palanca; falta el plan. Mira tu diagnóstico y agenda.
- **Cuerpo:**

> Hola {{ contact.firstname }},
>
> Tu caso tiene margen de mejora, pero conviene definir el plan correcto. Empieza por tu **diagnóstico interactivo** y, si quieres, agenda una sesión para revisar tus opciones.
>
> **[Ver mi diagnóstico →]** (`app.trol.mx/e/{{cliente_id}}?c=reactivacion_jun30_email`)
>
> — El Trol

---

## Segmento A5 — Ley 97 / PPR (~978 con semilla)

**Lista:** `ley = Ley97` (o `producto_estrella = PPR`), con semilla, email real.
**Objetivo:** horizonte/ahorro — Ley 97 depende del saldo AFORE.

- **Asunto:** {{ contact.firstname }}, tu pensión depende de tu ahorro — mira cómo mejorarla
- **Preview:** Eres Ley 97. Simula cuánto sube tu pensión si ahorras un poco más.
- **Cuerpo:**

> Hola {{ contact.firstname }},
>
> Como cotizas bajo la **Ley 97**, tu pensión depende del saldo en tu AFORE. En tu **calculadora interactiva** puedes simular cuánto sube si aportas un poco más cada mes (PPR) y ver tu horizonte.
>
> **[Simular mi pensión →]** (`app.trol.mx/e/{{cliente_id}}?c=reactivacion_jun30_email`)
>
> — El Trol

---

## Segmento B — Leads sin diagnóstico (~5,652)

**Contexto (no es culpa del cliente):** llegaron antes de que guardáramos los JSON y/o la consulta de Belvo no fue exitosa. **4,531 tienen CURP válido** → Jordan puede activar su cálculo. NO usar tono de "te faltó un paso".

### B0 — Con CURP (4,531): activar cálculo con puntos precargados

**Lista:** sin semilla + CURP válido, con email real. **Requiere:** puntos precargados (pendiente §5.9 del plan).
**Objetivo:** que disparen su actualización en Jordan y se active su calculadora.

- **Asunto:** {{ contact.firstname }}, tu pensión está lista para activarse
- **Preview:** Ya tienes puntos para actualizar tu información del IMSS y ver tu número.
- **Cuerpo:**

> Hola {{ contact.firstname }},
>
> Tenemos todo para calcular tu pensión, solo falta traer tu información más reciente del IMSS. Te dejamos **puntos de cortesía** para que lo hagas sin costo: actualiza tus datos y tu calculadora se activa al instante.
>
> **[Activar mi cálculo →]** (`app.trol.mx/e/{{cliente_id}}?c=activar_email`)
>
> Entras con un código por SMS; nosotros traemos tus datos al día y te mostramos tu pensión. — El Trol

### B1 — Sin CURP (1,121): estimación abierta

**Lista:** sin semilla + sin CURP válido, con email real.

- **Asunto:** {{ contact.firstname }}, calcula tu pensión en 1 minuto
- **Preview:** Una estimación rápida, sin dar tu CURP.
- **Cuerpo:**

> Hola {{ contact.firstname }},
>
> Puedes obtener una estimación de tu pensión en **1 minuto, sin dar tu CURP**:
>
> **[Calcular mi pensión →]** (`app.trol.mx/calcula?ref=email_jun30`)
>
> Si después quieres tu número exacto del IMSS, desde ahí te guiamos. — El Trol

---

## Email de respaldo (no-abiertos) — opcional martes

Reenvío con asunto alterno a quien no abrió el primer email:
- **Asunto A1:** ¿Viste cuánto puede subir tu pensión, {{ contact.firstname }}?
- **Asunto B:** Tu cálculo de pensión sigue disponible

## Notas de construcción en HubSpot

1. Crear **listas activas** por `producto_estrella` (importar de `vista_ruteo` si la propiedad no existe en HubSpot) y por `ley`, con los filtros de exclusión.
2. Botón CTA en lima #d1f069, texto gris #26282b. Un solo CTA por email.
3. Pie con dirección física, link de baja (requisito legal) y "El Trol Financiero".
4. Programar el envío del lunes; activar A/B en asunto si el volumen lo permite.
5. Medir CTR contra `links_campania` (Supabase) además de las métricas de HubSpot.
