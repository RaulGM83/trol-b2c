# Checklist domingo — para arrancar envíos el lunes temprano

## ✅ Ya listo (no tocar)
- Deploy de `trol-b2c` en producción (fix SISEC, OG tags, `/api/refrescar` puntos→Jordan).
- Plantillas WhatsApp **aprobadas**: `reactivacion_calculadora3` y `reactivacion_mod40v3`.
- CSVs piloto: `campanas/tako_piloto_300.csv` (300, todos los segmentos menos Mod 40) y `campanas/tako_piloto_mod40.csv` (201 Mod 40).
- 4,531 leads con 100 pts precargados (activación Segmento B).

---

## 🔴 Pendiente HOY (bloqueadores para enviar)

### A. WhatsApp piloto en Tako
- [ ] Subir `tako_piloto_300.csv` a Tako.
- [ ] Mapear columnas: `telefono` = destinatario, `nombre` → `{{1}}`, `url_herramienta` → `{{2}}`.
- [ ] Seleccionar la plantilla **`reactivacion_calculadora3`** (la genérica; la base es mixta).
- [ ] Configurar **lista de exclusión / opt-out**: que un "BAJA" saque al contacto y no reciba más. (Clave para la calidad del número.)
- [ ] Programar el envío para mañana AM (o dejarlo listo para mandar manual). Empezar con los 300, no más.

### B. Email (HubSpot) — solo si quieres que salga también el lunes
- [ ] Crear la **lista** (toda la base con semilla) excluyendo: emails `@trol.mx`, rebotados, no-marketing.
- [ ] Montar el correo **E0 / tronco común** (copy en `CAMPANAS_EMAIL_HUBSPOT.md`), con el link `/e/` y UTMs.
- [ ] Probar render en móvil + desktop y que los links abran bien.
- [ ] Programar envío (mediodía lunes, después de ver el piloto WhatsApp).
- *Nota:* si no da tiempo hoy, el email puede salir el lunes/martes sin problema; el piloto WhatsApp es lo que arranca temprano.

### C. Imagen OG (para que los links se vean como tarjeta)
- [ ] Subir `trol-b2c/public/og.png` (1200×630) y redeploy. *(No bloquea el envío, pero mejora el CTR de los links compartidos.)*

---

## 🟡 Verificar HOY (config que ya debería estar)
- [ ] **Vercel:** que `N8N_FULFILLMENT_URL` esté puesta (habilita la activación por puntos del Segmento B). El piloto de 300 NO la necesita (ya tienen semilla), pero conviene confirmarla.
- [ ] **WhatsApp Manager:** número con calidad "Verde/Alta" y verificado (OBA), listo para enviar.

---

## 🧪 QA end-to-end (20–30 min, con un contacto del CSV o el de prueba)
- [ ] Abrir un link `/e/<token>?c=reactivacion` del CSV → prellena teléfono → pide OTP por SMS.
- [ ] Entrar con el OTP → carga el **diagnóstico real** del cliente.
- [ ] Pantalla **Mejor jugada** muestra cifras correctas.
- [ ] (Opcional) Desbloqueo por puntos con un lead del Segmento B → marca `sisec_refresh_solicitado_at` (confirma que dispara Jordan).
- [ ] La apertura quedó registrada en `links_campania` (atribución).

---

## 👥 Operación / equipo (para mañana)
- [ ] Equipo listo para **contestar WhatsApp** desde temprano (el piloto abre conversaciones que hay que aprovechar en vivo).
- [ ] Acordar quién atiende y en qué horario.
- [ ] Tener a la mano la respuesta a dudas frecuentes (cómo entrar, qué es el código SMS, qué incluye la calculadora).

---

## 🚀 Orden de arranque lunes
1. **AM temprano:** enviar piloto WhatsApp (300) con `reactivacion_calculadora3`.
2. **+1–2 h:** revisar entregas, respuestas y aperturas en `links_campania`; vigilar calidad del número en WhatsApp Manager.
3. **Mediodía:** si todo bien → lanzar email masivo (si quedó listo) y/o preparar el siguiente lote WhatsApp.
4. **PM:** medir conversión (órdenes en `ordenes_b2c`, desbloqueos por puntos) y decidir si se amplía.

> Métricas rápidas (Supabase):
> `select campania, evento, count(*) , count(distinct cliente_id) from links_campania group by 1,2;`
