# Campaña Mod 40 — sale HOY (20-jul-2026)

Audiencia lista: **1,115 candidatos Mod 40** (60+, Ley 73, regla de vigencia cumplida),
**363 en zona ideal CDMX/EdoMex** que van primero. Top de la lista: 60-62 años, 1,600-2,100
semanas, saldos simulados de $3-4M — el cliente ideal del proyecto retroactivo.

## ✅ Ya está hecho (Supabase)

1. **`no_contactar`** — lista única de BAJA para TODAS las campañas (AFORE y Mod 40).
   - RPC `registrar_baja(p_telefono, p_detalle)`: normaliza a 10 dígitos, liga al cliente,
     upsert idempotente. Probada.
   - **Las 4 vistas de campaña ya la excluyen automáticamente**: quien pida BAJA no vuelve
     a aparecer en NINGÚN export (AFORE w1/todas, pensión 60+, Mod 40).
2. **`vista_campania_mod40`** — export directo formato Tako, ya ordenada
   (zona ideal → mayor saldo) y con el magic link armado.

## Checklist para disparar HOY (en orden)

### 1. Importar la lista BAJA existente de Tako (5 min) — ANTES del primer envío
Si ya tienen bajas acumuladas de campañas anteriores en Tako, expórtenlas y córranlas:
```sql
-- una línea por teléfono (acepta cualquier formato, se normaliza solo):
select registrar_baja(t) from unnest(array[
  '5512345678', '+52 55 8765 4321'  -- ← pegar aquí la lista de Tako
]) t;
```

### 2. Conectar el flujo BAJA (10 min)
Importar `baja_no_contactar_workflow.n8n.json` en n8n:
- Apuntar el webhook de **mensajes entrantes** de Tako al webhook del flujo (o colgar el
  nodo "¿Dice BAJA?" del flujo que ya recibe respuestas).
- Pegar el service_role key en el nodo HTTP.
- Mientras el webhook queda: **respaldo manual** — las asesoras corren
  `select registrar_baja('<telefono>');` en el SQL editor al ver un BAJA. Cero excusas de
  cumplimiento desde el minuto uno.

### 3. Plantilla (la decisión que define si sale hoy)
- **Camino A (sale HOY): reusar `reactivacion_mod40`** — ya existe de la campaña anterior;
  si sigue APROBADA en WhatsApp Manager, se puede disparar de inmediato. El copy aplica
  perfecto a esta audiencia ("Con Modalidad 40 tu pensión del IMSS puede multiplicarse…
  con tus datos ya cargados").
- **Camino B (en paralelo, para la siguiente ola): registrar `mod40_pension_retro`** —
  más afilada para 60+ que ya pueden pensionarse:

  **Nombre:** `mod40_pension_retro` · **Categoría:** Marketing · **Idioma:** Español (MEX)
  **Encabezado:** *(vacío)*
  **Cuerpo:**
  ```
  Hola {{1}} 👋 Te saludamos de El Trol, donde hace un tiempo calculaste tu pensión. Revisamos tu caso: por tus semanas cotizadas y tu edad, hay estrategias como Modalidad 40 que podrían subir tu pensión del IMSS de forma importante. Mira tus números actualizados aquí:
  {{2}}
  Cualquier duda, contéstanos por este chat. 🙌
  ```
  **Muestras:** `{{1}} → Juan` · `{{2}} → https://app.trol.mx/e/5b00d32b-88d6-4276-b6b8-bf818fcc3b4c?c=mod40retro`
  **Pie:** `Responde BAJA para no recibir más mensajes.`
  *Reglas Meta ✓: no abre/cierra con variable, sin variables juntas, sin "garantizado", dominio propio.*

### 4. Export del CSV (2 min)
Supabase → SQL editor → Download CSV:
```sql
-- PILOTO HOY (200): zona ideal, mayor saldo primero
select nombre, telefono, url_herramienta from vista_campania_mod40 limit 200;

-- resto (después de validar el piloto 24-48h):
select nombre, telefono, url_herramienta from vista_campania_mod40 offset 200;
```
Mapear en Tako: `nombre → {{1}}`, `url_herramienta → {{2}}`.

### 5. Disparo y vigilancia (playbook de siempre)
- Piloto 200 hoy → apertura en `links_campania` con `c=mod40retro` (1-2h) → calidad del
  número en WhatsApp Manager 24-48h → si Verde, ampliar por lotes diarios que el equipo
  pueda contestar (seguimiento +1h sin respuesta).
- El link aterriza en el diagnóstico con la **mejor jugada Mod 40 ya calculada** (de/a,
  multiplicador, costos con actualización y recargos) — la conversión es el WhatsApp de
  asesoría desde ahí.

## Nota de cumplimiento
La regla operativa queda: **ningún CSV de campaña se genera fuera de las vistas** —
así el BAJA se respeta solo, sin depender de memoria de nadie. Los 60+ NO reciben
mensajes de cambio de AFORE (decisión 20-jul); esta campaña habla de SU pensión.
