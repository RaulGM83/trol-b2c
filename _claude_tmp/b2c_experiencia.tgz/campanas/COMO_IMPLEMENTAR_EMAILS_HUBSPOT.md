# Cómo implementar los correos en HubSpot (paso a paso)

Tienes 3 correos listos como HTML, con encabezado de marca El Trol y dos botones (calculadora web + WhatsApp):

- `email_reactivacion.html` — "Tu pensión ahora es interactiva"
- `email_actualiza.html` — "Actualiza tu información del IMSS"
- `email_infonavit.html` — "No dejes ese dinero en la mesa" (segmento Infonavit)

WhatsApp ya prellenado: **525588974500** · CTA web: `app.trol.mx/calcula?ref=email…`

---

## La forma más fácil: pegar el HTML en un módulo de texto enriquecido

1. En HubSpot: **Marketing → Correo electrónico → Crear correo → Normal (regular)**.
2. Elige una plantilla **sencilla** (una columna) o "Empezar desde cero".
3. Arrastra un módulo **"Texto enriquecido" (Rich text)** al cuerpo.
4. Haz clic en el módulo → en la barra de herramientas abre el icono de **código fuente** `</>` (a veces bajo "Más" / "Advanced").
5. **Borra lo que haya** y **pega el contenido del archivo .html** completo. Aplica / Guardar.
6. Repite para cada correo (uno por email).

> Si tu editor no muestra el icono `</>`, usa la opción **"Crear correo → HTML/coded email"** (si tu plan la tiene) y pega ahí el archivo completo. Es aún más directo.

---

## Nombre, imagen y baja (3 detalles)

- **Nombre del contacto:** el HTML trae `{{ contact.firstname }}`. HubSpot lo reemplaza solo. Si tu editor lo borra al pegar, inserta el **token de personalización** "Nombre" donde dice "Hola".
- **Imagen de encabezado (opcional):** el encabezado ya se ve con la marca en texto. Si quieres la **imagen**: **Marketing → Archivos**, sube `email_header_trol.png`, copia su URL, y en el HTML reemplaza el bloque del encabezado por:
  `<img src="PEGA_LA_URL_AQUI" width="600" alt="El Trol" style="display:block;width:100%;">`
- **Baja / unsubscribe:** el HTML ya incluye `{{ unsubscribe_link }}`. Si prefieres, borra esa línea y deja el **pie estándar de HubSpot** (que ya trae la baja obligatoria). HubSpot no te deja enviar sin baja.

---

## Asuntos sugeridos (subject + preview)

| Correo | Asunto | Vista previa |
|---|---|---|
| Reactivación | {{ contact.firstname }}, tu pensión ahora es interactiva | Mueve edad, semanas y ahorro y mira tu número en vivo. |
| Actualiza | {{ contact.firstname }}, ¿tu información del IMSS está al día? | Actualízala cuando quieras y recalcula al instante. |
| Infonavit | {{ contact.firstname }}, tienes dinero que puede sumar a tu retiro | Revisa tu saldo de Infonavit en 1 minuto. |

---

## Antes de enviar

1. **Lista/segmento:** elige tu lista (ej. base con diagnóstico, o segmento Infonavit). Excluye correos `@trol.mx` (placeholder) y rebotados.
2. **Remitente y responder-a:** tu dominio verificado.
3. **Enviar prueba** a tu correo y revisa en móvil (los botones deben verse grandes y separados).
4. Programa el envío.

---

## El link del botón web (ya personalizado)

Verificamos HubSpot: la propiedad **`link_experiencia_app`** está poblada en **~13,612 contactos** (casi toda la base) con el link `/e/<cliente_id>` de cada persona. Por eso el botón web ya manda a **cada quien a su propia experiencia con datos cargados** (convierte mejor que la calculadora genérica).

Como el valor viene guardado con basura alrededor —`url_herramienta (https://app.trol.mx/e/...?c=nuevo) `— el `href` ya trae un **filtro de HubSpot que lo limpia** y, si el contacto no tiene la propiedad, usa la calculadora genérica como respaldo:

```
{{ contact.link_experiencia_app|replace('url_herramienta (','')|replace(')','')|trim|default('https://app.trol.mx/calcula?ref=email', true) }}
```

- **No tienes que tocar nada:** ya está en los 3 HTML. Solo **manda una prueba** y verifica que el botón abra `app.trol.mx/e/...` (no la calculadora genérica) para un contacto que sí tenga la propiedad.
- **Recomendado (limpieza):** el prefijo `url_herramienta (…)` lo agrega el nodo de n8n que escribe la propiedad. Si lo corriges para guardar **solo la URL limpia**, luego puedes simplificar el `href` a `{{ contact.link_experiencia_app }}`.
- **Atribución:** el link personalizado trae `?c=nuevo`; si quieres medir estos correos aparte en el dashboard, pide que n8n use `?c=email` (o quédate con el genérico `?ref=email` para esos casos).

> Si al pegar en un módulo de texto enriquecido HubSpot te escapa el filtro y no funciona, usa la opción **"HTML/coded email"** (ahí el HubL siempre se procesa), o pídeme la versión con el link genérico.
